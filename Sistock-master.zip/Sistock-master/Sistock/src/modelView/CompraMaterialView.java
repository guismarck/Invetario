/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelView;

import Constructores.Material;
import Constructores.Proveedor;
import com.jfoenix.controls.JFXCheckBox;
import com.jfoenix.controls.JFXDatePicker;
import com.jfoenix.controls.JFXTextField;

/**
 *
 * @author josue
 */
public class CompraMaterialView {
    private JFXCheckBox check;
    private Material material;
    private Proveedor proveedor;
    private JFXDatePicker vence;
    private JFXTextField cantidad;
    private JFXTextField precio;

    public CompraMaterialView() {
    }

    public CompraMaterialView(JFXCheckBox check, Material material, Proveedor proveedor, JFXDatePicker date, JFXTextField cantidad, JFXTextField precio) {
        this.check = check;
        this.material = material;
        this.proveedor = proveedor;
        this.vence = date;
        this.cantidad = cantidad;
        this.precio = precio;
    }

    public JFXCheckBox getCheck() {
        return check;
    }

    public void setCheck(JFXCheckBox check) {
        this.check = check;
    }

    public Material getMaterial() {
        return material;
    }

    public void setMaterial(Material material) {
        this.material = material;
    }

    public Proveedor getProveedor() {
        return proveedor;
    }

    public void setProveedor(Proveedor proveedor) {
        this.proveedor = proveedor;
    }

    public JFXDatePicker getVence() {
        return vence;
    }

    public void setVence(JFXDatePicker date) {
        this.vence = date;
    }

    public JFXTextField getCantidad() {
        return cantidad;
    }

    public void setCantidad(JFXTextField cantidad) {
        this.cantidad = cantidad;
    }

    public JFXTextField getPrecio() {
        return precio;
    }

    public void setPrecio(JFXTextField precio) {
        this.precio = precio;
    }
    
    
}
