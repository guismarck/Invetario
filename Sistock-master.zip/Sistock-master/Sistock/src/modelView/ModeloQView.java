/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelView;

/**
 *
 * @author josue
 */
public class ModeloQView {
    private double demanda ,costoPedir, costoAlmacenar, costoProducto, tasaAlmacen, StockSegu, plazoEnt;
    private int id;
    private byte[] foto;
    String nombre;

    public ModeloQView() {
    }

    public ModeloQView(double demanda, double costoPedir, double costoAlmacenar, double costoProducto, double tasaAlmacen, double StockSegu, double plazoEnt, int id, String nombre, byte[] foto) {
        this.demanda = demanda;
        this.costoPedir = costoPedir;
        this.costoAlmacenar = costoAlmacenar;
        this.costoProducto = costoProducto;
        this.tasaAlmacen = tasaAlmacen;
        this.StockSegu = StockSegu;
        this.plazoEnt = plazoEnt;
        this.id = id;
        this.nombre = nombre;
        this.foto = foto;
    }

    public double getDemanda() {
        return demanda;
    }

    public void setDemanda(double demanda) {
        this.demanda = demanda;
    }

    public double getCostoPedir() {
        return costoPedir;
    }

    public void setCostoPedir(double costoPedir) {
        this.costoPedir = costoPedir;
    }

    public double getCostoAlmacenar() {
        return costoAlmacenar;
    }

    public void setCostoAlmacenar(double costoAlmacenar) {
        this.costoAlmacenar = costoAlmacenar;
    }

    public double getCostoProducto() {
        return costoProducto;
    }

    public void setCostoProducto(double costoProducto) {
        this.costoProducto = costoProducto;
    }

    public double getTasaAlmacen() {
        return tasaAlmacen;
    }

    public void setTasaAlmacen(double tasaAlmacen) {
        this.tasaAlmacen = tasaAlmacen;
    }

    public double getStockSegu() {
        return StockSegu;
    }

    public void setStockSegu(double StockSegu) {
        this.StockSegu = StockSegu;
    }

    public double getPlazoEnt() {
        return plazoEnt;
    }

    public void setPlazoEnt(double plazoEnt) {
        this.plazoEnt = plazoEnt;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public byte[] getFoto() {
        return foto;
    }

    public void setFoto(byte[] foto) {
        this.foto = foto;
    }
    
    
}
