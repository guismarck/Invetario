/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Util;

import sis.Gestion.Compras.FXMLProveedoresController;
import sis.Gestion.Inventario.FXMLGestionInventarioController;
import Util.JFXOptionPane;
import com.jfoenix.controls.JFXButton;
import java.awt.event.MouseEvent;
import java.net.URL;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import javafx.scene.image.ImageView;
import javafx.scene.layout.HBox;
import javax.swing.JOptionPane;
import produccion3.BDProducto;
import produccion3.DBProveedor;

/**
 * FXML Controller class
 *
 * @author josue
 */
public class JFXOptionPaneController implements Initializable {

    @FXML
    private ImageView img;
    @FXML
    private Label lbMessage;
    @FXML
    private Label lbDeta;
    @FXML
    private HBox actionParent;
    @FXML
    private JFXButton btnCancel;
    @FXML
    private HBox okParent;
    @FXML
    private JFXButton btnOk;

    public enum Eliminar_Tabla{Producto, Materiales, Proveedor};
    public static Eliminar_Tabla tabla;
    
    /**
     * Initializes the controller class.
     */
    
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        btnOk.addEventHandler(javafx.scene.input.MouseEvent.MOUSE_PRESSED, (e) ->{
//            if (tabla != null) {
//                switch(tabla){
//                    case Producto:{
//                        BDProducto.delete(FXMLGestionInventarioController.currentProducto);
//                        break;
//                    }
//                    case Materiales:{
//                        break;
//                    }
//                    case Proveedor:{
//                        DBProveedor.deleteProveedor(FXMLProveedoresController.currentObject);
//                        break;
//                    }
//                }
//                tabla = null;
//            }
            JFXOptionPane.isOk = 1;
            JFXOptionPane.stage.close();
        });
        
        btnCancel.addEventHandler(javafx.scene.input.MouseEvent.MOUSE_PRESSED, (e) ->{
            JFXOptionPane.isOk = 0;
            JFXOptionPane.stage.close();
        });
    }    
    
}
