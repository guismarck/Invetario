/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Util;

import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Pane;
import javafx.scene.layout.VBox;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.stage.StageStyle;

/**
 *
 * @author josue
 */
public class JFXOptionPane {
    private static Pane pane;
    public static Stage stage;
    public static int isOk = 0;
    public static enum MessageType {OK, ERROR, INFO};
    private static MessagePopUp message;
    
    public static int showMessageDialog(String title, String detail, MessageType messageType){
        int value = 0;
        if (message == null) {
            message = new MessagePopUp();
        }
        try {
            value= message.showMessageDialog(title, detail, messageType);
        } catch (InterruptedException ex) {
            Logger.getLogger(JFXOptionPane.class.getName()).log(Level.SEVERE, null, ex);
        }
        return value;
    }
    
    
    static class MessagePopUp{
        
        public  int showMessageDialog(String title, String detail, MessageType messageType) throws InterruptedException{
            String icon = "";
            isOk = 0;
            switch(messageType){
                case OK:{
                    icon = "icons8-checkmark-50.png";
                    break;
                }
                case ERROR:{
                    icon = "icons8-error-50.png";
                    break;
                }
                case INFO:{
                    icon = "icons8-box-important-50.png";
                    break;
                }
            }
            try {
                FXMLLoader loader = new FXMLLoader(getClass().getResource("/Util/JFXOptionPane.fxml"));
                pane = (Pane)loader.load();
                JFXOptionPaneController con = (JFXOptionPaneController)loader.<JFXOptionPaneController>getController();
                if(messageType != null) ((ImageView)pane.getChildren().get(0)).setImage(new Image("/img/"+icon));
                if(title != null && title.trim().length() > 0) ((Label)((VBox)pane.getChildren().get(1)).getChildren().get(0)).setText(title);
                if(detail != null && detail.trim().length() > 0) ((Label)((VBox)pane.getChildren().get(1)).getChildren().get(1)).setText(detail);

                stage = new Stage();
                stage.setScene(new Scene(pane));
                stage.setTitle(title);
                stage.initStyle(StageStyle.UTILITY);
                stage.initModality(Modality.APPLICATION_MODAL);
                stage.showAndWait();
//                this.wait();
            } catch (IOException ex) {
                Logger.getLogger(JFXOptionPane.class.getName()).log(Level.SEVERE, null, ex);
            }
            return isOk;
        }
    }
}
