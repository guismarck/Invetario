/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Util;

import com.jfoenix.controls.JFXTextField;
import java.util.function.UnaryOperator;
import javafx.scene.control.TextField;
import javafx.scene.control.TextFormatter;

/**
 *
 * @author josue
 */
public class Validacion {
    
    public static void ValidacionNumérica(JFXTextField node){
        node.focusedProperty().addListener((evt, Old, New) -> {
            if(New && node.getText().equals("0"))
                node.clear();
            
            if(!New){
                if(node.getText().isEmpty()) node.setText("0");
                if(node.getText().matches("[0-9]*\\.")) node.setText(node.getText().replace(".", ""));
            }
        });
        

        UnaryOperator<TextFormatter.Change> integerFilter = change -> {
            String newText = change.getText(); // Se obtiene el valor ingresado
            int textControlLength = ((TextField)change.getControl()).getText().length();
            
            if(newText.equals("0.")){
                return change;
                
            }else if(newText.equals(".") && !change.getControlText().contains(".")){
                if(textControlLength==0){
                    ((TextField)change.getControl()).setText("0.");
                    ((TextField)change.getControl()).end();
                    return null;
                }else
                    return change;
                
            }else if(newText.matches("[0-9]*") || newText.matches("[0-9]{1,}\\.[0-9]*")){
                return change;
            }
            
            // Si el valor ingresado no cumple con niguna de las reglas de validacion 
            // se retorna null ignorando el valor ingresado
            return null;
        };
        node.setTextFormatter(new TextFormatter<String>(integerFilter));
    }
}
