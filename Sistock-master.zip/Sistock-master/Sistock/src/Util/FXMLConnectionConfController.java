/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Util;

import Conexion.conexionbd;
import Constructores.Usuario;
import Inventario_Optiomo.ViewModel;
import Util.JFXOptionPane.MessageType;
import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXPasswordField;
import com.jfoenix.controls.JFXTextField;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.Pane;
import security.LoginServer;

/**
 * FXML Controller class
 *
 * @author josue
 */
public class FXMLConnectionConfController implements Initializable {

    @FXML
    private Pane pnMessage;
    @FXML
    private Label lbMessage;
    @FXML
    private JFXTextField txtUser;
    @FXML
    private JFXPasswordField txtPass;
    @FXML
    private JFXButton btnConectar;
    @FXML
    private JFXButton btnPredeterminar;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        //Eventos textos
        //----------------------------------------------------------------------
        txtUser.addEventHandler(KeyEvent.KEY_RELEASED, (e) -> {
             isEmpty();
        });
        
        txtPass.addEventHandler(KeyEvent.KEY_RELEASED, (e) -> {
             isEmpty();
        });
        
        //----------------------------------------------------------------------
        
        //Eventos de los botonoes
        //----------------------------------------------------------------------
        btnConectar.setOnAction(new EventHandler(){
            @Override
            public void handle(Event event) {
                Usuario us = getUser();
                if (us != null) {
                    Object obj = conexionbd.conectar(
                            us.getName(), 
                            us.getPasString()
                    );
                    String msg = "";
                    if (obj != null) {
                        msg = "Autentificación exitosa.";
                        btnPredeterminar.setVisible(true);
                    }else{
                        msg = "Usuario o contraseña invalido.";
                        btnPredeterminar.setVisible(false);
                    }
                    ViewModel.MessageTransitio(
                                221,1000,
                                msg, 
                                lbMessage, pnMessage
                        );
                }
            }
        });
        
        btnPredeterminar.setOnAction(new EventHandler(){
            @Override
            public void handle(Event event) {
                btnPredeterminar.setDisable(true);
                Usuario us = getUser();
                LoginServer log = new LoginServer();
                
                if (log.insertar(us)) 
                    JFXOptionPane.showMessageDialog(
                        "Se ha predeterminado el login del servidor", 
                        "Correcto.\nSe todo ha salido bien. Puede continuar.", 
                        MessageType.OK);
                else
                    JFXOptionPane.showMessageDialog(
                        "Error al predeterminar el usuario administador", 
                        "Ha ocurrido un error al predeterminar el LoginServer", 
                        MessageType.ERROR);
            }
        });
        //----------------------------------------------------------------------
    }    

    private void isEmpty() {
        if (txtUser.getText().isEmpty() || txtPass.getText().isEmpty() )
            btnConectar.setDisable(true);
        else
            btnConectar.setDisable(false);
    }
    
    private Usuario getUser(){
        Usuario us = null;
        if (!txtUser.getText().isEmpty() && !txtPass.getText().isEmpty()){
            us = new Usuario(txtUser.getText(), txtPass.getText());
        }else{
            JFXOptionPane.showMessageDialog(
                    "Falta llenar los campos", 
                    "Debe llenar todos los campos", 
                    MessageType.INFO);
        }
        return us;
    }
}
