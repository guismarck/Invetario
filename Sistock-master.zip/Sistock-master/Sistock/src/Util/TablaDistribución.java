/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Util;

import java.text.DecimalFormat;

/**
 *
 * @author josue
 */
public class TablaDistribución {
    
    /**
     * Obtiene la probabilidad de la tabla de distribución de frecuencia
     * @param nivelServicio
     *  Nivel de confianza alpha 
     * @return 
     *  Probabilidad de ocurrencia
     * 
     **/
    public static double distribuciónNormal(double nivelServicio){ 
        int neg = (nivelServicio < 0d) ? 1 : 0; 
        if (neg == 1) 
         nivelServicio *= -1d; 

        double k = (1d/(1d + 0.2316419 * nivelServicio)); 
        double y = ((((1.330274429 * k - 1.821255978) * k + 1.781477937) * 
            k - 0.356563782) * k + 0.319381530) * k; 
        y = 1.0 - 0.398942280401 * Math.exp(-0.5 * nivelServicio * nivelServicio) * y; 

        return (1d - neg) * y + neg * (1d - y); 
    }
    
    public static double getZNormal(double nivelServicio){
        DecimalFormat format = new DecimalFormat("#.0000");
        double p=0.00, z=0.00, pPrevius, pTruncado = 0.00;
        int length = ("" + nivelServicio).length();
        
        for(double i=0.0; i<= 3.10; i+=0.1){
            for(double j=0.00; j<= 0.09; j+=0.01){
                pPrevius = (i==0.0 && j == 0.00)? 0 : p;
                z = i + j;
                p = Double.parseDouble(format.format(distribuciónNormal(z)));
                pTruncado = Double.parseDouble((p + "").substring(0, ((length> (p + "").length())? length -1 : length)));
                if (pTruncado == nivelServicio) {
//                    System.out.println("Nivel: " + nivelServicio
//                            + "P: " + p + ""
//                            + "\nP Previus: " + pPrevius);
                    if (Math.abs((nivelServicio - p)) > Math.abs((nivelServicio - pPrevius))) {
                        if (j == 0.00) {
                            z = (i - 0.1) + (0.09);
                        }else{
                            z = (i) + (j - 0.01);
                        }
                        
                    }
//                    System.out.println("\n\nSe encontró z = " + z +"\n con p = " + p);
                    return z;
                }
            }
        }
        return z;
    }
}
