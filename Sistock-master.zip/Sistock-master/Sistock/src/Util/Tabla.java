/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Util;

import java.io.IOException;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.collections.ObservableList;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.TableView;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;

/**
 *
 * @author josue
 * @param <T>
 * Clase generica 
 */
public abstract class Tabla<T> implements EventHandler{
        
    public Tabla(){}
    
    protected TableView<T> tableView;
    
    public void initTable(HBox pnContainer){
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource(
                    "/Util/FXMLTabla.fxml"));
            tableView = (TableView<T>) loader.load();
            tableView.setOnMouseClicked(this);
            FXMLTablaController cont = loader.<FXMLTablaController>getController();
            cont.setCells(tableHeaders());
            ObservableList data = dataTable();
            cont.setData(data);
            
            pnContainer.getChildren().add(tableView);
            HBox.setHgrow(tableView, Priority.ALWAYS);
        } catch (IOException ex) {
            Logger.getLogger(Tabla.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public abstract List<String> tableHeaders();
    
    public abstract ObservableList<T> dataTable();

    @Override
    public void handle(Event event){}   
    
}
