package Util;

import Conexion.conexionbd;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.control.ComboBox;
import javax.swing.JOptionPane;

/**
 *
 * @author nesto
 */
public class Cargarcombo {

    private PreparedStatement pst = null;
    private ResultSet rs = null;

    private ObservableList<String> dato = FXCollections.observableArrayList();

    public void consultar_proveedor(ComboBox cbox_paises) throws Exception {
        //Creamos objeto tipo Connection    

        //Creamos la Consulta SQL
        String SSQL = "SELECT Nombre FROM Proveedor ORDER BY Nombre ASC";

//Establecemos bloque try-catch-finally
        try {

            //Preparamos la consulta SQL
            pst = conexionbd.getSql().prepareStatement(SSQL);
            //Ejecutamos la consulta
            rs = pst.executeQuery();

            cbox_paises.setPromptText("Seleccionar");

            //LLenamos lal lista
            while (rs.next()) {

                dato.add(rs.getString("Nombre"));

            }

            // llenamos el combo
            cbox_paises.setItems(dato);

        } catch (SQLException e) {

            JOptionPane.showMessageDialog(null, e);

        } finally {

            if (conexionbd.isConnected) {

                try {

                    rs.close();

                    rs = null;

                } catch (SQLException ex) {

                    JOptionPane.showMessageDialog(null, ex);

                }

            }

        }
    }

    public void consultar_producto(ComboBox cbox_producto) throws Exception {
        //Creamos objeto tipo Connection    

        //Creamos la Consulta SQL
        String SSQL = "SELECT Nombre FROM Producto ORDER BY Nombre ASC";

//Establecemos bloque try-catch-finally
        try {

            //Preparamos la consulta SQL
            pst = conexionbd.getSql().prepareStatement(SSQL);
            //Ejecutamos la consulta
            rs = pst.executeQuery();

            cbox_producto.setPromptText("Seleccionar");

            //LLenamos lal lista
            while (rs.next()) {

                dato.add(rs.getString("Nombre"));

            }

            // llenamos el combo
            cbox_producto.setItems(dato);

        } catch (SQLException e) {

            JOptionPane.showMessageDialog(null, e);

        } finally {

            if (conexionbd.isConnected) {

                try {
                    rs.close();
                    rs = null;

                } catch (SQLException ex) {

                    JOptionPane.showMessageDialog(null, ex);

                }

            }

        }
    }
}
