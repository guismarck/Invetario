package Main;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Pane;
import javax.swing.JOptionPane;

/**
 * FXML Controller class
 *
 * @author josue
 */
public class FXMLItemButtonController implements Initializable {

    @FXML
    private ImageView img;
    @FXML
    private Label lbTittle, lbDescription;
    @FXML
    private Pane pnPrincipal;
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        //Evento de click sobre el item
//        pnPrincipal.addEventHandler(MouseEvent.MOUSE_PRESSED, (e) ->{
//            
//            switch(lbTittle.getText()){
//                case "Inventario de productos terminados":{
//                    JOptionPane.showMessageDialog(null,lbTittle.getText());
//                    break;
//                }
//                case "Inventario de productos en proceso":{
//                    JOptionPane.showMessageDialog(null,lbTittle.getText());
//                    break;
//                }
//                case "Inventario de materiales":{
//                    JOptionPane.showMessageDialog(null,lbTittle.getText());
//                    break;
//                }
//                case "Inventario Óptimo":{
//                    JOptionPane.showMessageDialog(null,lbTittle.getText());
//                    break;
//                }
//                case "Costo de inventario":{
//                    JOptionPane.showMessageDialog(null,lbTittle.getText());
//                    break;
//                }
//                case "Diagramas":{
//                    JOptionPane.showMessageDialog(null,lbTittle.getText());
//                    break;
//                }
//            }
//        });
    }    
    
    /**
     * Método que llena los campos del item
     * @param image
     *  Imgen del Item
     * @param title
     *  Titulo del Item
     * @param description 
     *  Breve descripción
     */
    public void setContent(Image image, String title, String description){
        img.setImage(image); lbTittle.setText(title); lbDescription.setText(description);
    }
}
