package Main;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import Util.JFXOptionPane;
import Constructores.Contrabajador;
import com.jfoenix.controls.JFXHamburger;
import com.jfoenix.transitions.hamburger.HamburgerBackArrowBasicTransition;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.animation.Interpolator;
import javafx.animation.KeyFrame;
import javafx.animation.KeyValue;
import javafx.animation.Timeline;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.layout.Priority;
import javafx.scene.layout.VBox;
import javafx.util.Duration;
import produccion3.DBEmpleado;

/**
 * FXML Controller class
 *
 * @author josue
 */
public class FXMLMainController implements Initializable {

    @FXML
    private Pane paneMenu;
    @FXML
    private JFXHamburger hamburger;
    @FXML
    private ImageView imgHome, imgUser, imgUsers, imgBuys, imgSells, imgAbout, 
            imgExit;
    @FXML
    private VBox pnCatalog;
    @FXML
    private  VBox pnMain;
    
    private boolean isOpen = false;
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        ObservableList<Contrabajador> emps = DBEmpleado.loadTrabajadores();
        if (emps != null && emps.size() > 0) {
            DBEmpleado.loadCurrentEmployee();
        }

        // Cargan las iconos de los elementos del catálogo
        loadIcons();
        
        //Se selecciona por defecto el Inicio
        ((Pane)((HBox)pnCatalog.getChildren().get(1)).getChildren().get(0)
                ).setStyle("-fx-background-color: #3498DB;");
        
        //Se establece que inicialmente el catálogo estara cerrado o comprimido.
        paneMenu.prefWidthProperty().set(50);
        
        //Botón de menú que genera el desplazamiento del catálogo
        HamburgerBackArrowBasicTransition burgerTask =  new HamburgerBackArrowBasicTransition(hamburger);
        burgerTask.setRate(-1);
        
        //Evento que realiza la trancición del catálogo de izquierda a derecha o de derecha a izquierda
        hamburger.addEventHandler(MouseEvent.MOUSE_PRESSED, (e) -> {
            burgerTask.setRate(burgerTask.getRate() * -1);
            burgerTask.play();

            if (!isOpen){
                PaneTransition(200,300);isOpen = true;
            }else{
                PaneTransition(50, 200);isOpen = false;
            }
        });
        
//        Evento de click sobre el botón del catálogo: Inicio
        catalogItemClikedEvent(1);
        //Evento de click sobre el botón del catálogo: Usuario
        catalogItemClikedEvent(2);
        //Evento de click sobre el botón del catálogo: Usuarios
        catalogItemClikedEvent(3);
        //Evento de click sobre el botón del catálogo: Compras
        catalogItemClikedEvent(4);
        //Evento de click sobre el botón del catálogo: Ventas
        catalogItemClikedEvent(5);
        //Evento de click sobre el botón del catálogo: Acerca de
        catalogItemClikedEvent(6);
        //Evento de click sobre el botón del catálogo: Salir
        catalogItemClikedEvent(7);
//        
        loadHome();
        
    }    

    /**
     * Método que realiza una animación de trancición vertical, de izquierda a derecha.
     * 
     *@param width
     *          La longitud de despazamiento del panel
     * @param time
     *          El tiempo que tardará la animación en realizarce.
     **/
    private void PaneTransition(double width, double time) {
        Timeline timeline = new Timeline();
        KeyValue kv = new KeyValue(paneMenu.prefWidthProperty(), width, Interpolator.EASE_IN);
        KeyFrame kf = new KeyFrame(Duration.millis(time), kv);
        timeline.getKeyFrames().add(kf);
        timeline.play();
    }
    
    //CARGAR ICONOS DEL CATÁLOGO
    public void loadIcons(){
        imgHome.setImage(new Image("/img/icons8-home-512.png"));
        imgUser.setImage(new Image("/img/icons8-male-user-512.png"));
        imgUsers.setImage(new Image("/img/icons8-user-groups-100.png"));
        imgBuys.setImage(new Image("/img/icons8-buy-100.png"));
        imgSells.setImage(new Image("/img/icons8-sell-100.png"));
        imgAbout.setImage(new Image("/img/icons8-info-512.png"));
        imgExit.setImage(new Image("/img/icons8-exit-512.png"));
    }
    
    /**
     * Método agrega el evento de click sobre los items del catalogo(Inicio, Usuario, Acerca de, Salir)
     * Cuando uno de estos item es clickeado se pone una línea de color azul(#3498DB) al lado izquierdo del item clickeado
     * 
     *@param catalogIndex 
     *          Recibe el indice de la ubicacion jeraquica del panel de catalogo
     **/
    private void catalogItemClikedEvent(int catalogIndex){
        ((HBox)pnCatalog.getChildren().get(catalogIndex)).addEventHandler(
                MouseEvent.MOUSE_PRESSED, (e) ->{
            String clickedStyle = "-fx-background-color: #3498DB;";
            String notClickedStyle = "-fx-background-color: #f7f7f7;";
            
            for(int i=1; i<= (pnCatalog.getChildren().size() - 2); i++){
                if(catalogIndex != i)
                    ((Pane)((HBox)pnCatalog.getChildren().get(i)).getChildren()
                            .get(0)).setStyle(notClickedStyle);
            }
            ((Pane)((HBox)pnCatalog.getChildren().get(catalogIndex)).
                    getChildren().get(0)).setStyle(clickedStyle);
            
            switch(catalogIndex){
                case 1:{
                    loadHome();
                    break;
                }
                case 2: {
                    loadUser();
                    break;
                }
                case 3:{
                      loadUsers();
                    break;
                }
                case 4:{
                    loadBuys();
                    break;
                }
                case 5:{
                    JFXOptionPane.showMessageDialog(
                            "En construcción", 
                            "Esta opción aún no se construye.", 
                            JFXOptionPane.MessageType.INFO);
                    break;
                }
                case 6:{
                    JFXOptionPane.showMessageDialog(
                            "En construcción", 
                            "Esta opción aún no se construye.", 
                            JFXOptionPane.MessageType.INFO);
                    break;
                }
                case 7:{
                    System.exit(0);
                }
            }
        });
    }
    
    private void loadHome() {
        loadPage("/Main/FXMLInicio.fxml");
    }    
    
    private void loadUser() {
        loadPage("/Main/FXMLUser.fxml");
    }  
    
    private void loadUsers() {
        loadPage("/sis/Gestion/Personal/FXMLDocument.fxml");
    }  

    private void loadBuys() {
        loadPage("/sis/Gestion/Compras/FXMLCompra.fxml");
    }
    private void loadPage(String path){
        try {
            Pane root = FXMLLoader.load(getClass().getResource(path));
            pnMain.getChildren().clear();
            pnMain.getChildren().add(root);
            HBox.setHgrow(root, Priority.ALWAYS);
        } catch (IOException ex) {
            Logger.getLogger(FXMLMainController.class.getName()
            ).log(Level.SEVERE, null, ex);
        }
    }
}

