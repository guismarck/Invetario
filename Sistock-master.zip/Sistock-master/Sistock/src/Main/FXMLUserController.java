/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Main;

import Constructores.Config;
import Constructores.Contrabajador;
import Inventario_Optiomo.ViewModel;
import Util.JFXOptionPane;
import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXPasswordField;
import com.jfoenix.controls.JFXTextField;
import com.jfoenix.controls.JFXToggleButton;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import javafx.scene.control.ToggleButton;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import produccion3.DBEmpleado;

/**
 * FXML Controller class
 *
 * @author josue
 */
public class FXMLUserController implements Initializable {

    @FXML
    private JFXTextField txtNombre, txtApellido, txtCedula, txtTelefono, txtCorreo, txtUser;
    @FXML
    private JFXPasswordField txtPassword;
    @FXML
    private ToggleButton checkPass;
    @FXML
    private ImageView img;
    @FXML
    private Label lbLastModification, lbID;
    @FXML
    private JFXToggleButton checkEdit;
    @FXML
    private JFXButton btnSave;

    private boolean isThereIMG;
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        init();
        setContrabajador(Config.getTrabajador());
    }    
    
    private void init(){
        //Elementos deshabilitados
        disableElements(true);
        //ImageView
        img.addEventHandler(MouseEvent.MOUSE_ENTERED, (e) ->{
            if(!checkEdit.isSelected()) img.setStyle("-fx-cursor: hand;");
        });
        img.addEventHandler(MouseEvent.MOUSE_CLICKED, (e) ->{
            if(checkEdit.isSelected()){
                isThereIMG = ViewModel.chooiseImage(img);
            }
        });
        ViewModel.roundImageView(img, new Image("/img/talin.JPG"));
        //Eventos de botones y checks
        checkEdit.addEventHandler(MouseEvent.MOUSE_CLICKED, (e) -> {
            disableElements(!checkEdit.isSelected());
        });
        checkPass.addEventHandler(MouseEvent.MOUSE_CLICKED, (e) -> {
            
        });
        btnSave.addEventHandler(MouseEvent.MOUSE_CLICKED, (E) ->{
            Contrabajador emp = getUsuario();
            boolean flag = false;
            if(emp != null)
                flag = DBEmpleado.updateEmpleado(emp);
            if(flag)
                JFXOptionPane.showMessageDialog("Información Actualizada", 
                    "Se ha actualizado su información.", 
                    JFXOptionPane.MessageType.OK);
        });
        
        setContrabajador(Config.getTrabajador());
    }
    
    private void disableElements(boolean value){
        txtNombre.setDisable(value);
        txtApellido.setDisable(value);
        txtCorreo.setDisable(value);
        txtCedula.setDisable(value);
        txtTelefono.setDisable(value);
        txtUser.setDisable(value);
        txtPassword.setDisable(value);
        btnSave.setVisible(!value);
        checkPass.setDisable(value);
    }
    private Contrabajador getUsuario(){
        String nom, ap, ce, co, us, cont;
        int id, tel;
        
        id = (lbID.getText().isEmpty()) ? 0 : Integer.parseInt(lbID.getText());
        tel = (txtTelefono.getText().isEmpty()) ? 0 : Integer.parseInt(txtTelefono.getText());
        nom = txtNombre.getText(); ap= txtApellido.getText();
        ce = txtCedula.getText();  tel = Integer.parseInt(txtTelefono.getText());
        co = txtCorreo.getText();  us = txtUser.getText();
        cont = txtPassword.getText();
        
        //Esta parte es temporal ya que los usuarios deben tener ID
        Contrabajador user = null;
        if (!nom.isEmpty() && !ap.isEmpty() && !ce.isEmpty() || tel != 0 && !co.isEmpty())
            user = new Contrabajador(id, nom, ap, 0, ce, co, tel, us, cont);
        else
            JFXOptionPane.showMessageDialog("Formulario incompleto", 
                    "Falta llenar algunos campos", 
                    JFXOptionPane.MessageType.INFO);
        return user;
    }
    
    private void setContrabajador(Contrabajador user){
        lbID.setText(user.getIdtrabajador() + "");
        txtNombre.setText(user.getNombre());
        txtApellido.setText(user.getApellido());
        txtCorreo.setText(user.getCorreo());
        txtTelefono.setText(user.getCelular() + "");
        txtCedula.setText(user.getCedula());
        txtCorreo.setText(user.getCorreo());
        txtUser.setText(user.getUsuario());
        txtPassword.setText(user.getContraseña());
        lbLastModification.setText("Última modificación: " + user.getLastUpdate());
    }
}
