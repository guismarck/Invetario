package Main;


import Conexion.conexionbd;
import Constructores.Config;
import Constructores.Contrabajador;
import Constructores.Usuario;
import Util.JFXOptionPane;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.application.Application;
import static javafx.application.Application.launch;
import javafx.event.EventHandler;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.stage.WindowEvent;
import security.LoginServer;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author josue
 */
public class MainClass extends Application{
    
    @Override
    public void start(Stage stage) throws Exception {
        LoginServer log = new LoginServer();
        Usuario us = log.cargar();
        if (us == null) {
            us = new conexionbd().showConectionForm();
        }
            startConnection(us);
        if (conexionbd.isConnected && us != null) {
            initStage(stage);
        }
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
        System.exit(0);
    }
    
    private  static void startConnection(Usuario us){
        Config.setUser(new Usuario(us.getName(), us.getPasString()));
        Object obj = conexionbd.conectar(
                Config.getUser().getName(), 
                Config.getUser().getPasString());
        Config.setTrabajador(new Contrabajador(0, null, null, 0, null, null, 0, "eduardo09", null));
    }
    
    private void initStage(Stage stage) throws Exception{
        //Parent root = FXMLLoader.load(getClass().getResource("/Interfaces/FXMLMRPL4L.fxml"));
//        Parent root = FXMLLoader.load(getClass().getResource("/Interfaces/FXMLVenta.fxml"));
        Parent root = FXMLLoader.load(getClass().getResource("/Main/FXMLMain.fxml"));
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.setMinWidth(1050);
        stage.setMinHeight(650);
        stage.show();
        stage.centerOnScreen();
        //Evento de cierre de la ventana principal
        stage.setOnCloseRequest(new EventHandler<WindowEvent>() {
          @Override
          public void handle(WindowEvent we) {
              try {
                  Conexion.conexionbd.getSql().close();
                  System.out.println("Connection finished");
                  stage.close();
                  this.finalize();
                  System.exit(0);
              } catch (SQLException ex) {
                  ex.printStackTrace();
              } catch (Throwable ex) {
                  ex.printStackTrace();
              }
          }});
    }
}
