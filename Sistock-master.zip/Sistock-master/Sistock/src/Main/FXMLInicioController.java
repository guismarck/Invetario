/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Main;

import Util.JFXOptionPane;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.image.Image;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Pane;
import javafx.scene.layout.VBox;
import javax.swing.JOptionPane;

/**
 * FXML Controller class
 *
 * @author josue
 */
public class FXMLInicioController implements Initializable {

    @FXML
    private Pane pn1, pn2, pn3, pn4, pn5, pn6;
    @FXML
    private VBox pnCentral;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        try {
            //Cargan los items
            loadItems();
        } catch (IOException ex) {
            Logger.getLogger(FXMLMainController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }    
    
    private void loadItems() throws IOException{
        //Los 6 items del panel central y sus respectivos controladores.
        FXMLLoader loader1, loader2, loader3, loader4, loader5, loader6;
        FXMLItemButtonController cont1, cont2, cont3, cont4, cont5, cont6;
        
        //Cargan los paneles
        String loadPath = "/Main/FXMLItemButton.fxml";
        loader1 = loadResource(loadPath);
        loader2 = loadResource(loadPath);
        loader3 = loadResource(loadPath);
        loader4 = loadResource(loadPath);
        loader5 = loadResource(loadPath);
        loader6 = loadResource(loadPath);
        
        //Se agregan los items al panel principal.
        pn1.getChildren().add((Pane)loader1.load());
        pn2.getChildren().add((Pane)loader2.load());
        pn3.getChildren().add((Pane)loader3.load());
        pn4.getChildren().add((Pane)loader4.load());
        pn5.getChildren().add((Pane)loader5.load());
        pn6.getChildren().add((Pane)loader6.load());
        
        //Eventos de click
        pn1.getChildren().get(0).addEventHandler(MouseEvent.MOUSE_PRESSED, (e) ->{
            showPage("/sis/Gestion/Inventario/FXMLGestionInventario.fxml");
        });
        pn2.getChildren().get(0).addEventHandler(MouseEvent.MOUSE_PRESSED, (e) ->{
            JFXOptionPane.showMessageDialog("En construcción", "Esta parte aun no se termina!", JFXOptionPane.MessageType.INFO);
        });
        pn3.getChildren().get(0).addEventHandler(MouseEvent.MOUSE_PRESSED, (e) ->{
            JFXOptionPane.showMessageDialog("En construcción", "Esta parte aun no se termina!", JFXOptionPane.MessageType.INFO);
        });
        pn4.getChildren().get(0).addEventHandler(MouseEvent.MOUSE_PRESSED, (e) ->{
            showPage("/Inventario_Optiomo/FXMLInventarioOptimo.fxml");
//            JFXOptionPane.showMessageDialog(
//                            "En reparación", 
//                            "Existen algunos problemas con esta área, y no esta disponible.", 
//                            JFXOptionPane.MessageType.INFO);
        });
        pn5.getChildren().get(0).addEventHandler(MouseEvent.MOUSE_PRESSED, (e) ->{
            JFXOptionPane.showMessageDialog("En construcción", "Esta parte aun no se termina!", JFXOptionPane.MessageType.INFO);
        });
        pn6.getChildren().get(0).addEventHandler(MouseEvent.MOUSE_PRESSED, (e) ->{
            JFXOptionPane.showMessageDialog("En construcción", "Esta parte aun no se termina!", JFXOptionPane.MessageType.INFO);
        });
        
        //Cargan los controladores
        cont1 = loader1.<FXMLItemButtonController>getController();
        cont2 = loader2.<FXMLItemButtonController>getController();
        cont3 = loader3.<FXMLItemButtonController>getController();
        cont4 = loader4.<FXMLItemButtonController>getController();
        cont5 = loader5.<FXMLItemButtonController>getController();
        cont6 = loader6.<FXMLItemButtonController>getController();
        
        //Se establecen los valores
        cont1.setContent(new Image("/img/icons8-product-512.png"), "Inventario de productos terminados", "La bodega esta casi llena.");
        cont2.setContent(new Image("/img/manufacturing.png"), "Inventario de productos en proceso", "La producción a nivel normal.");
        cont3.setContent(new Image("/img/icons8-layers-480.png"), "Inventario de materiales", "Inventario a nivel crítico.");
        cont4.setContent(new Image("/img/icons8-line-chart-500.png"), "Inventario Óptimo", "Cantidad óptima de inventario, Número de pedidos, Tiempo de entrega");
        cont5.setContent(new Image("/img/icons8-cost-480.png"), "Costo de inventario", "Costo total del inventario");
        cont6.setContent(new Image("/img/icons8-statistics-500.png"), "Diagramas", "Historial de pedidos.");
    }
    
    private FXMLLoader loadResource(String fileName) throws IOException{
        return new FXMLLoader(getClass().getResource(fileName));
    }
    
    private void showPage(String file){
        try {
                Pane root = (Pane)loadResource(file).load();
                pnCentral.getChildren().clear();
                pnCentral.getChildren().add(root);
            } catch (IOException ex) {
                Logger.getLogger(FXMLInicioController.class.getName()).log(Level.SEVERE, null, ex);
            }
    }
}
