package Conexion;

import Constructores.Usuario;
import Util.JFXOptionPane;
import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.stage.StageStyle;

/**
 *
 * @author Oscar Pereira
 */
public class conexionbd {

    public static Connection sql;
    public static boolean isConnected = false;
    private static boolean isConfiguring = true;
    private static  Usuario us;
    
    public static Connection conectar(String user, String pass)  {
        try {
            if (!isConnected) {
                Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
                String databaseURL = "jdbc:sqlserver://;databaseName=Producción";

                sql = java.sql.DriverManager.getConnection(databaseURL, user, pass);

                System.out.println("correcto");
                setIsConnected(true);
                us = new Usuario(user, pass);
            }
        } catch (ClassNotFoundException | SQLException e) {
            if (e.getMessage().contains("Login failed")) {
                if (isConfiguring) {
                    int opc = JFXOptionPane.showMessageDialog("No se inicio sesión con el gestor.", 
                        "No se logró iniciar sesión.\nDesea configurar la conexion?", 
                        JFXOptionPane.MessageType.ERROR);
                    if (opc == 1){
                        isConfiguring = false;
                        new conexionbd().showConectionForm();
                    }
                }
            }else if(e.getMessage().contains("Connection refused (Connection refused).")){
                JFXOptionPane.showMessageDialog("El gestor SQL no esta corriendo.", 
                        "Al parecer no esta ejecutandose el gestor.\nVerifique que se este ejecutando", 
                        JFXOptionPane.MessageType.ERROR);
            }else{
                e.printStackTrace();
            }
            setIsConnected(false);
        }
        return sql;
    }

    public static Connection getSql() {
        return sql;
    }

    public static void setIsConnected(boolean isConnected) {
        conexionbd.isConnected = isConnected;
    }
    
    public Usuario showConectionForm(){
        try {
            Parent root = FXMLLoader.load(getClass().getResource("/Util/FXMLConnectionConf.fxml"));
            Scene scene = new Scene(root);
            Stage stage = new Stage();
            stage.setScene(scene);
            stage.setMaxWidth(415);
            stage.setMaxHeight(540);
            stage.initModality(Modality.APPLICATION_MODAL);
            stage.initStyle(StageStyle.UTILITY);
            stage.showAndWait();
            isConfiguring = false;
        } catch (IOException ex) {
            Logger.getLogger(conexionbd.class.getName()).log(Level.SEVERE, null, ex);
        }
        return us;
    }
    
}
