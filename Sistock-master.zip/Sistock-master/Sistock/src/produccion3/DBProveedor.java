/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package produccion3;

import sis.Gestion.Personal.FXMLDocumentController;
import Conexion.conexionbd;
import Constructores.Contrabajador;
import Constructores.Proveedor;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

/**
 *
 * @author josue
 */
public class DBProveedor {
    
    private static final ObservableList<Proveedor> 
            dato = FXCollections.observableArrayList();
    private static PreparedStatement pst;
    private static ResultSet rs = null;
    
    public static ObservableList<Proveedor> loadProveedores() {
        dato.clear();
        try {

            pst = conexionbd.getSql().prepareStatement("Select * From Proveedor;");
            rs = pst.executeQuery();

            while (rs.next()) {
                dato.add(new Proveedor(rs.getInt(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5)));
            }
        } catch (SQLException ex) {
            Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
        }
        return dato;
    }
    
    public static boolean insertProveedor(Proveedor p){
        boolean flag = false;
        try {
            String query = "Insert Into Proveedor Values(?, ?, ?, ?);";
            pst = conexionbd.getSql().prepareStatement(query);
            pst.setString(1, p.getNombre());
            pst.setString(2, p.getDireccion());
            pst.setString(3, p.getCorreo());
            pst.setString(4, p.getTelefono());
            flag = (pst.executeUpdate() == 1);
        } catch (SQLException ex) {
            Logger.getLogger(DBProveedor.class.getName()).log(Level.SEVERE, null, ex);
        }
        return flag;
    }
    
    
    public static boolean updateProveedor(Proveedor p){
        boolean flag = false;
        try {
            String query = "Update Proveedor Set Nombre=?,Dirección=?, "
                    + "Correo_Electronico=?, Telefono=? Where IdProveedor=?";
            pst = conexionbd.getSql().prepareStatement(query);
            pst.setString(1, p.getNombre());
            pst.setString(2, p.getDireccion());
            pst.setString(3, p.getCorreo());
            pst.setString(4, p.getTelefono());
            pst.setInt(5, p.getIdProveedor());

            flag = (pst.executeUpdate() == 1);
        } catch (SQLException ex) {
            Logger.getLogger(DBProveedor.class.getName()).log(Level.SEVERE, null, ex);
        }
        return flag;
    }
    
    public static boolean deleteProveedor(Proveedor p){
        boolean flag = false;
        try {
            String query = "Delete From Proveedor Where IdProveedor=?;";
            pst = conexionbd.getSql().prepareStatement(query);
            pst.setInt(1, p.getIdProveedor());
            flag = (pst.executeUpdate() == 1);
            loadProveedores();
        } catch (SQLException ex) {
            Logger.getLogger(DBProveedor.class.getName()).log(Level.SEVERE, null, ex);
        }
        return flag;
    }
}
