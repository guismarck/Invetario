/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package produccion3;

import Conexion.conexionbd;
import sis.Gestion.Personal.FXMLDocumentController;
import modelView.ModeloQView;
import Constructores.Material;
import java.sql.Blob;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

/**
 *
 * @author josue
 */
public class BDMaterial {
    private static PreparedStatement pst = null;
    private static ResultSet rs = null;    
    public BDMaterial(){}
    
    public static ObservableList<ModeloQView> loadProcedureMaterialesInfo() {
        ObservableList<ModeloQView> dato = FXCollections.observableArrayList();
        try {
            pst = conexionbd.getSql().prepareStatement("Materiales_Info");
            rs = pst.executeQuery();

            while (rs.next()) {
                Blob img = rs.getBlob("Imagen");
                int devoluciones;
                
                try{
                    devoluciones = rs.getInt("Devoluciones");
                }catch(Exception ex){devoluciones = 0;}
                
//                Material m = new Material();
//                m.setId(rs.getInt("IdMateriales"));
//                m.setMarca(rs.getString("Marca"));
//                m.setNombre(rs.getString("Nombe"));
//                m.setDescripcion(rs.getString("Descripcion"));
//                m.setPrecio(rs.getFloat("Precio"));
//                m.setCantidad(rs.getInt("Cantidad"));
//                m.setFoto(img.getBytes(1, (int)img.length()));
                
                ModeloQView detalle = new ModeloQView();
                detalle.setDemanda(rs.getInt("Cantidad") - devoluciones);
                detalle.setCostoPedir(rs.getFloat("CostoPedir"));
                detalle.setCostoAlmacenar(rs.getFloat("CostoAlmacenar"));
                detalle.setCostoProducto(rs.getFloat("Precio"));
                detalle.setTasaAlmacen(rs.getFloat("TasaAlmacen"));
                detalle.setStockSegu(rs.getInt("StocK_inicial"));//Stock mínimo
                detalle.setPlazoEnt(rs.getInt("PlazoEntrega"));
                detalle.setId(rs.getInt("IdMateriales"));
                detalle.setNombre(rs.getString("Nombre"));
                detalle.setFoto(img.getBytes(1, (int)img.length()));
                dato.add(detalle);
            }
        } catch (SQLException ex) {
            Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
        }
        return dato;
    }
    
    public static ObservableList<Material> loadMateriales(){
        ObservableList<Material> dato = FXCollections.observableArrayList();
        try {
            pst = conexionbd.getSql().prepareStatement("Select * from Materiales;");
            rs = pst.executeQuery();

            while (rs.next()) {
//                Blob img = rs.getBlob("Foto");
//                int devoluciones;
                
//                try{
//                    devoluciones = rs.getInt("Devoluciones");
//                }catch(Exception ex){devoluciones = 0;}
                
                Material m = new Material();
                m.setId(rs.getInt("IdMateriales"));
                m.setCodigo(rs.getString("Codigo"));
                m.setNombre(rs.getString("Nombre"));
                m.setDescripcion(rs.getString("Descripcion"));
                m.setDescripcion(rs.getString("Tipo"));
                //m.setFoto(img.getBytes(1, (int)img.length()));
                m.setEstado(rs.getBoolean("Estado"));
                dato.add(m);
            }
        } catch (SQLException ex) {
            Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
        }
        return dato;
    }
    
    public static Blob getMaterialImage(int materialID){
        Blob image = null;
        try {
            pst = conexionbd.getSql().prepareStatement(
                    "Select Imagen from Materiales Where IdMateriales = ?");
            pst.setInt(1, materialID);
            rs = pst.executeQuery();
            
            while (rs.next()) {
                 image = rs.getBlob("Imagen");
            }
        } catch (SQLException ex) {
            Logger.getLogger(BDMaterial.class.getName()).log(Level.SEVERE, null, ex);
        }
        return image;
    }
}
