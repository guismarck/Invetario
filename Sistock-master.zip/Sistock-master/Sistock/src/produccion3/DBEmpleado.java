/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package produccion3;

import sis.Gestion.Personal.FXMLDocumentController;
import Conexion.conexionbd;
import Constructores.Config;
import Constructores.Contrabajador;
import Util.JFXOptionPane;
import com.microsoft.sqlserver.jdbc.SQLServerException;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

/**
 *
 * @author josue
 */
public class DBEmpleado {
    
    private static ObservableList<Contrabajador> 
            dato = FXCollections.observableArrayList();
    private static PreparedStatement pst;
    private static ResultSet rs = null;
    
    public static ObservableList<Contrabajador> loadTrabajadores() {
        dato.clear();
        try {

            pst = conexionbd.getSql().prepareStatement("Select * From Empleado;");
            rs = pst.executeQuery();

            while (rs.next()) {
//                Date date = rs.getDate(10);
//                String fecha = (date == null)? "No hay fecha de modificación" : date.getDate() + "/" + date.getMonth() + "/" + date.getYear();
                dato.add(
                        new Contrabajador(
                                rs.getInt(1), 
                                rs.getString(2), 
                                rs.getString(3), 
                                rs.getInt(4), 
                                rs.getString(5), 
                                rs.getString(6), 
                                rs.getInt(7), 
                                rs.getString(8), 
                                rs.getString(9)/*,
                                fecha*/)
                        );
            }
        } catch (SQLException ex) {
            Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
        }
        return dato;
    }
    
    public static boolean insertEmpleado(Contrabajador emp){
        boolean flag  = false;
        String sql = "Insert into Empleado(Nombre,Apellido,Edad,Cedula,correo,Celular,usuario,Pass, lastUpdate) values"
                + "(?,?,?,?,?,?,?,?)";

        try {
            pst = conexionbd.getSql().prepareStatement(sql);
            pst.setString(1, emp.getNombre());
            pst.setString(2, emp.getApellido());
            pst.setInt(3, emp.getEdad());
            pst.setString(4, emp.getCedula());
            pst.setString(5, emp.getCorreo());
            pst.setInt(6, emp.getCelular());
            pst.setString(7, emp.getUsuario());
            pst.setString(8, emp.getContraseña());
            pst.setDate(9, new Date(new java.util.Date().getTime()));
            flag = (pst.executeUpdate() == 1);

        } catch (SQLException ex) {
            Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
            JFXOptionPane.showMessageDialog(
                    "Error al intentar insertar", 
                    "No se pudo insertar el registro", 
                    JFXOptionPane.MessageType.ERROR);
        } 
        return flag;
    }
    
    
    public static boolean updateEmpleado(Contrabajador emp){
        boolean flag = false;
        
        String sql = "update Empleado set Nombre=?,Apellido=?,Edad=?,Cedula=?,correo=?,Celular=?,usuario=?,Pass=?, lastUpdate=? "
                + "where Idempleado=?";

        try {
            LocalDateTime locaDate = LocalDateTime.now();
            int day  = locaDate.getDayOfMonth();
            int month = locaDate.getMonth().getValue();
            int year = locaDate.getYear();
            pst = conexionbd.getSql().prepareStatement(sql);
            pst.setString(1, emp.getNombre());
            pst.setString(2, emp.getApellido());
            pst.setInt(3, emp.getEdad());
            pst.setString(4, emp.getCedula());
            pst.setString(5, emp.getCorreo());
            pst.setInt(6, emp.getCelular());
            pst.setString(7, emp.getUsuario());
            pst.setString(8, emp.getContraseña());
            pst.setDate(9, new Date(year, month, day));
            pst.setInt(10, emp.getIdtrabajador());
            
            flag = (pst.executeUpdate() == 1);
        } catch (SQLException ex) {
            Logger.getLogger(DBEmpleado.class.getName()).log(Level.SEVERE, null, ex);
            JFXOptionPane.showMessageDialog(
                    "Error al intentar actualizar", 
                    "No se pudo actualizar el registro", 
                    JFXOptionPane.MessageType.ERROR);
        } 
        return flag;
    }
    
    public static boolean deleteEmpleado(Contrabajador emp){
        boolean flag = false;
        String sql = "delete from Empleado where Idempleado=?";
        int id = emp.getIdtrabajador();

        try {

            pst = conexionbd.getSql().prepareStatement(sql);
            pst.setInt(1, id);

            int i = pst.executeUpdate();

        } catch (SQLException e) {
            Logger.getLogger(DBEmpleado.class.getName()).log(Level.SEVERE, null, e);
            JFXOptionPane.showMessageDialog(
                    "Error al intentar eliminar", 
                    "No se pudo eliminar el registro", 
                    JFXOptionPane.MessageType.ERROR);
        }
        return flag;
    }
    
    public static String logIn(Contrabajador emp){
        String msj = "", nombrePro = "Comprobar_Credenciales ?, ?";
        try {
            pst = conexionbd.getSql().prepareStatement(nombrePro);
            pst.setString(1, emp.getUsuario());
            pst.setString(1, emp.getContraseña());
        }catch (SQLServerException ex){
            JFXOptionPane.showMessageDialog(
                    "Error al intentar ejecutar un SP", 
                    "No se pudo ejecutar el procedimiento: " + nombrePro, 
                    JFXOptionPane.MessageType.ERROR);
            Logger.getLogger(DBEmpleado.class.getName()).log(Level.SEVERE, null, ex);
        }catch (SQLException ex) {
            Logger.getLogger(DBEmpleado.class.getName()).log(Level.SEVERE, null, ex);
        }
        return msj;
    }
    
    public static void loadCurrentEmployee() {
        try {
            pst = conexionbd.getSql().prepareStatement(
                    "select * from Empleado WHERE Empleado.usuario"
                            + " = ?;");
            pst.setString(1, Config.getTrabajador().getUsuario());
            rs = pst.executeQuery();
            while (rs.next()) {
//                Date date = rs.getDate(10);
                dato.add(new Contrabajador(
                        rs.getInt(1), 
                        rs.getString(2), 
                        rs.getString(3), 
                        rs.getInt(4), 
                        rs.getString(5), 
                        rs.getString(6), 
                        rs.getInt(7), 
                        rs.getString(8), 
                        rs.getString(9)/*,
                        (date.getDate() + "/" + date.getMonth() + "/" + date.getYear())*/)
                        );
            }
            pst.close();
        } catch (SQLException ex) {
            Logger.getLogger(FXMLDocumentController.class.getName()
            ).log(Level.SEVERE, null, ex);
        }
        if (dato.size() > 0)
            Config.setTrabajador(new Contrabajador(
                    dato.get(0).getIdtrabajador(), 
                    dato.get(0).getNombre(), 
                    dato.get(0).getApellido(), 
                    dato.get(0).getEdad(), 
                    dato.get(0).getCedula(), 
                    dato.get(0).getCorreo(), 
                    dato.get(0).getCelular(), 
                    dato.get(0).getUsuario(), 
                    dato.get(0).getContraseña(),
                    dato.get(0).getLastUpdate()));
        System.out.println("Se ha cargado el usuario....");
    }
}
