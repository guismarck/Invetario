/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package produccion3;

import sis.Gestion.Personal.FXMLDocumentController;
import Conexion.conexionbd;
import Constructores.Compra;
import Constructores.Proveedor;
import Util.JFXOptionPane;
import com.microsoft.sqlserver.jdbc.SQLServerException;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

/**
 *
 * @author josue
 */
public class DBCompra {
    
    private static final ObservableList<Compra> 
            dato = FXCollections.observableArrayList();
    private static PreparedStatement pst;
    private static ResultSet rs = null;
    
    public static ObservableList<Compra> loadCompras() {
        dato.clear();
        String namePro = "Compras_Proveedor;";
        try {

            pst = conexionbd.getSql().prepareStatement(namePro);
            rs = pst.executeQuery();

            while (rs.next()) {
                dato.add(new Compra(
                        rs.getInt(1), 
                        new Proveedor(rs.getInt(2), rs.getString(3)), 
                        rs.getDate(4), 
                        rs.getFloat(5)));
            }
        } catch (SQLServerException ex) {
            JFXOptionPane.showMessageDialog("Error en la base de datos", 
                    "No se encontro el precedimiento almacenado : " + namePro, 
                    JFXOptionPane.MessageType.ERROR);
//            Logger.getLogger(DBCompra.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(DBCompra.class.getName()).log(Level.SEVERE, null, ex);
        }
        return dato;
    }
    
    public static boolean insertCompra(Compra p){
        boolean flag = false;
        try {
            String query = "Insert Into Compra Values(?, ?);";
            pst = conexionbd.getSql().prepareStatement(query);
            pst.setInt(1, (p.getProveedor().getIdProveedor()));
            pst.setDate(2, p.getFechaCompra());
            flag = (pst.executeUpdate() == 1);
        } catch (SQLException ex) {
            Logger.getLogger(DBCompra.class.getName()).log(Level.SEVERE, null, ex);
        }
        return flag;
    }
    
    
    public static boolean updateProveedor(Compra p){
        boolean flag = false;
        try {
            String query = "Update Compra Set idProveedor=?,Fecha_Compra=? "
                    + "Where IdCompra=?";
            pst = conexionbd.getSql().prepareStatement(query);
            pst.setInt(1, (p.getProveedor().getIdProveedor()));
            pst.setDate(2, p.getFechaCompra());
            pst.setInt(5, p.getIdCompra());

            flag = (pst.executeUpdate() == 1);
        } catch (SQLException ex) {
            Logger.getLogger(DBCompra.class.getName()).log(Level.SEVERE, null, ex);
        }
        return flag;
    }
    
    public static boolean deleteProveedor(Compra p){
        boolean flag = false;
        try {
            String query = "Delete From Compra Where IdCompra=?;";
            pst = conexionbd.getSql().prepareStatement(query);
            pst.setInt(1, p.getIdCompra());
            flag = (pst.executeUpdate() == 1);
            loadCompras();
        } catch (SQLException ex) {
            Logger.getLogger(DBCompra.class.getName()).log(Level.SEVERE, null, ex);
        }
        return flag;
    }
    
    public static Compra loadLastCompra() {
        Compra c = null;
        String query = "select top 1 * from Compra order by IdCompra desc;";
        try {

            pst = conexionbd.getSql().prepareStatement(query);
            rs = pst.executeQuery();

            while (rs.next()) {
                c = new Compra(rs.getInt("IdCompra"), null, rs.getDate("Fecha_Compra"));
            }
        } catch (SQLException ex) {
            Logger.getLogger(DBCompra.class.getName()).log(Level.SEVERE, null, ex);
        }
        return c;
    }
}
