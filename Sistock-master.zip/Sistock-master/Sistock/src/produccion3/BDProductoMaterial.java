/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package produccion3;

import Conexion.conexionbd;
import sis.Gestion.Personal.FXMLDocumentController;
import Constructores.ProductoMaterial;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author josue
 */
public class BDProductoMaterial {
    private static PreparedStatement pst = null;
    private static ResultSet rs = null;    
    public BDProductoMaterial(){}
   
    
    public static boolean insert(ProductoMaterial producMat){
        boolean flag = false;
        try {
            pst = conexionbd.getSql().prepareStatement("insert into Producto_Material Values(?, ?, ?);");
            pst.setInt(1, producMat.getProducto().getID());
            pst.setInt(2, producMat.getMaterial().getId());
            pst.setInt(3, producMat.getCantidad());
            flag = (pst.executeUpdate() > 0);
        }catch (SQLException ex) {
            Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
        }
        return flag;
    }
    
    public static boolean update(ProductoMaterial oldProdMal, ProductoMaterial newProdMal){
        boolean flag = false;
        try {
            pst = conexionbd.getSql().prepareStatement("update Producto_Material Set idProducto=? , idMaterial=?, cantidadMaterial=? Where idProducto=? and idMaterial=?;");
            pst.setInt(1, newProdMal.getProducto().getID());
            pst.setInt(2, newProdMal.getMaterial().getId());
            pst.setInt(3, newProdMal.getCantidad());
            pst.setInt(4, oldProdMal.getProducto().getID());
            pst.setInt(5, oldProdMal.getMaterial().getId());
            flag = (pst.executeUpdate() > 0);
        }catch (SQLException ex) {
            Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
        }
        return flag;
    }
    
    public static boolean delete(ProductoMaterial producMat){
        boolean flag = false;
        try {
            pst = conexionbd.getSql().prepareStatement("delete from Producto_Material Where idProducto=? and idMaterial=?;");
            pst.setInt(1, producMat.getProducto().getID());
            pst.setInt(2, producMat.getMaterial().getId());
            flag = (pst.executeUpdate() > 0);
        }catch (SQLException ex) {
            Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
        }
        return flag;
    }
}
