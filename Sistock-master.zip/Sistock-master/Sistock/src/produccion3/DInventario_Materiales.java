/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package produccion3;

import Conexion.conexionbd;
import Constructores.InventarioMateriales;
import Constructores.Material;
import sis.Gestion.Personal.FXMLDocumentController;
import Constructores.Proveedor;
import Util.JFXOptionPane;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

/**
 *
 * @author josue
 */
public class DInventario_Materiales {
    private static PreparedStatement pst = null;
    private static ResultSet rs = null;
    private static ObservableList<InventarioMateriales> dato = FXCollections.observableArrayList();
    
    public DInventario_Materiales(){}
    
    public static ObservableList<InventarioMateriales> loadInventarioMateriales(Proveedor o) {
        dato.clear();
        String namePro = "Material_Proveedor ?";
        try {
            pst = conexionbd.getSql().prepareStatement(namePro);
            pst.setInt(1, o.getIdProveedor());
            rs = pst.executeQuery();

            while (rs.next()) {
                
                Material m = new Material();
                m.setId(rs.getInt("IdMateriales"));
                m.setCodigo(rs.getString("Código Material"));
                m.setNombre(rs.getString("Nombre Material"));
                
                Proveedor p = new Proveedor();
                p.setIdProveedor(rs.getInt("IdProveedor"));
                p.setNombre(rs.getString("Proveedor"));
                
                dato.add(
                        new InventarioMateriales( p, m));
            }
            pst.close();
        } catch (SQLException ex) {
            Logger.getLogger(FXMLDocumentController.class.getName()).log(
                    Level.SEVERE, null, ex);
        }
        return dato;
    }
    
//    public boolean insert(Producto p){
//        boolean flag = false;
//        String query = "INSERT INTO dbo.Producto(Nombre, codigo, Imagen) "+
//                "VALUES(?, ?, ?);";
//        try {
//            pst = con.prepareStatement(query);
//            pst.setString(1, p.getNombre());
//            pst.setString(2, p.getCodigo());
//            pst.setBlob(3, p.getFoto());
//
//            flag = (pst.executeUpdate() == 1);
//            pst.close();loadMaterialProductos();
//        } catch (SQLException ex) {
//            Logger.getLogger(DInventario_Materiales.class.getName()).log(
//                    Level.SEVERE, null, ex);
//             JFXOptionPane.showMessageDialog("Error al agregar", "No se agregó" 
//                     +" el producto\n" + ex.getMessage(), 
//                     JFXOptionPane.MessageType.ERROR);
//        } 
//        return flag;
//    }
//
    public static boolean updateStockMinimo(InventarioMateriales inv){
        boolean flag = false;
        String query = "update Inventario_materiales "
                + "set StocK_inicial = ? where IdMateriales = ?;";
        try {
            pst = conexionbd.getSql().prepareStatement(query);
            pst.setFloat(1, inv.getStockInicial());
            pst.setInt(2, inv.getMaterial().getId());

            flag = (pst.executeUpdate() == 1);
            pst.close();
        } catch (SQLException ex) {
             JFXOptionPane.showMessageDialog("Error al actualizar",
                     "No se actualizo el producto\n" + ex.getMessage(), 
                     JFXOptionPane.MessageType.ERROR);
             ex.printStackTrace();
        } 
        return flag;
    }
//    
//    public static boolean delete(Producto p){
//        boolean flag = false;
//        String query = "DELETE FROM dbo.Producto WHERE dbo.Producto.IdProducto "
//                + "= ?;";
//        try {
//            pst = con.prepareStatement(query);
//            pst.setInt(1, p.getID());
//
//            flag = (pst.executeUpdate() == 1);
//            pst.close();
//            loadMaterialProductos();
//        } catch (SQLException ex) {
//            Logger.getLogger(DInventario_Materiales.class.getName()).log(Level.SEVERE, null, ex);
//             JFXOptionPane.showMessageDialog("Error al eliminar",
//                     "No se eliminó el producto\n" + ex.getMessage(), 
//                     JFXOptionPane.MessageType.ERROR);
//        } 
//        return flag;
//    }
    
//    public static InventarioMateriales loadInventarioMaterialesById(InventarioMateriales o) {
//        InventarioMateriales im = null;
//        String namePro = "select * from Inventario_materiales where IdInventario = ?;";
//        try {
//            pst = conexionbd.getSql().prepareStatement(namePro);
//            pst.setInt(1, o.getIdInventario());
//            rs = pst.executeQuery();
//
//            while (rs.next()) {
//                
//                Material m = new Material();
//                m.setId(rs.getInt("IdMateriales"));
//                m.setCodigo(rs.getString("Código Material"));
//                m.setNombre(rs.getString("Nombre Material"));
//                
//                Proveedor p = new Proveedor();
//                p.setIdProveedor(rs.getInt("IdProveedor"));
//                p.setNombre(rs.getString("Proveedor"));
//                
//                dato.add(
//                        new InventarioMateriales( p, m));
//            }
//            pst.close();
//        } catch (SQLException ex) {
//            Logger.getLogger(FXMLDocumentController.class.getName()).log(
//                    Level.SEVERE, null, ex);
//        }
//        return im;
//    }
    
}
