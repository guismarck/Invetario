/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package produccion3;

import sis.Gestion.Personal.FXMLDocumentController;
import Conexion.conexionbd;
import Constructores.Compra;
import Constructores.DetalleCompra;
import Constructores.Material;
import Constructores.Proveedor;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

/**
 *
 * @author josue
 */
public class DBDetalleCompra {
    
    private static final ObservableList<DetalleCompra> 
            dato = FXCollections.observableArrayList();
    private static PreparedStatement pst;
    private static ResultSet rs = null;
    
    public static ObservableList<DetalleCompra> loadDetalleCompra(Compra c) {
        dato.clear();
        try {

            pst = conexionbd.getSql().prepareStatement("Detalle_Compras ?;");
            pst.setInt(1, c.getIdCompra());
            rs = pst.executeQuery();

            while (rs.next()) {
                dato.add(new DetalleCompra(
                        rs.getInt(4), 
                        new Compra(
                                rs.getInt(1), 
                                new Proveedor(rs.getInt(2), rs.getString(5)), rs.getDate(11)),
                        
                        new Material(rs.getString(6), rs.getInt(3)), 
                        rs.getString(7),
                        rs.getString(8),
                        rs.getFloat(9),
                        rs.getFloat(10)
                ));
            }
        } catch (SQLException ex) {
            Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
        }
        return dato;
    }
    
    public static boolean insertDetalleCompra(DetalleCompra p){
        boolean flag = false;
        try {
            String query = "Insert Into Detalle_Compra Values(?, ?, ?);";
            pst = conexionbd.getSql().prepareStatement(query);
            pst.setInt(1, (p.getCompra().getIdCompra()));
            pst.setInt(2, p.getMaterial().getId());
            pst.setFloat(3, p.getCantidad());
            flag = (pst.executeUpdate() == 1);
        } catch (SQLException ex) {
            Logger.getLogger(DBDetalleCompra.class.getName()).log(Level.SEVERE, null, ex);
        }
        return flag;
    }
    
    
    public static boolean updateDetalleCompra(DetalleCompra p){
        boolean flag = false;
        try {
            String query = "Update Detalle_Compra Set idCompra=?, idMateriales=?"
                    + ", Cantidad=? Where IdDetalleCompra=?";
            pst = conexionbd.getSql().prepareStatement(query);
            pst.setInt(1, (p.getCompra().getIdCompra()));
            pst.setInt(2, p.getMaterial().getId());
            pst.setFloat(3, p.getCantidad());
            pst.setInt(4, (p.getIdDetalle()));
            flag = (pst.executeUpdate() == 1);
        } catch (SQLException ex) {
            Logger.getLogger(DBDetalleCompra.class.getName()).log(Level.SEVERE, null, ex);
        }
        return flag;
    }
    
    public static boolean deleteDetalleCompra(DetalleCompra p){
        boolean flag = false;
        try {
            String query = "Delete From Detalle_Compra Where IdDetalleCompra=?;";
            pst = conexionbd.getSql().prepareStatement(query);
            pst.setInt(1, p.getIdDetalle());
            flag = (pst.executeUpdate() == 1);
        } catch (SQLException ex) {
            Logger.getLogger(DBDetalleCompra.class.getName()).log(Level.SEVERE, null, ex);
        }
        return flag;
    }
}
