/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package produccion3;

import Conexion.conexionbd;
import sis.Gestion.Personal.FXMLDocumentController;
import Constructores.Producto;
import Util.JFXOptionPane;
import java.sql.Blob;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

/**
 *
 * @author josue
 */
public class BDProducto {
    private static PreparedStatement pst = null;
    private static ResultSet rs = null;
    private static ObservableList<Producto> dato;
    
    public BDProducto(){dato = FXCollections.observableArrayList();}
    
    public static ObservableList<Producto> loadProductos() {
        dato.clear();
        try {
            pst = conexionbd.getSql().prepareStatement("select * from Producto");
            rs = pst.executeQuery();

            while (rs.next()) {
                Blob img = rs.getBlob("Imagen");
                dato.add(
                        new Producto(
                                rs.getInt("Idproducto"), 
                                rs.getString("Codigo"), 
                                rs.getString("Nombre"), 
                                img));
            }
            pst.close();
        } catch (SQLException ex) {
            Logger.getLogger(FXMLDocumentController.class.getName()).log(
                    Level.SEVERE, null, ex);
        }
        return dato;
    }
    
    public boolean insert(Producto p){
        boolean flag = false;
        String query = "INSERT INTO dbo.Producto(Nombre, codigo, Imagen) "+
                "VALUES(?, ?, ?);";
        try {
            pst = conexionbd.getSql().prepareStatement(query);
            pst.setString(1, p.getNombre());
            pst.setString(2, p.getCodigo());
            pst.setBlob(3, p.getFoto());

            flag = (pst.executeUpdate() == 1);
            pst.close();loadProductos();
        } catch (SQLException ex) {
            Logger.getLogger(BDProducto.class.getName()).log(
                    Level.SEVERE, null, ex);
             JFXOptionPane.showMessageDialog("Error al agregar", "No se agregó" 
                     +" el producto\n" + ex.getMessage(), 
                     JFXOptionPane.MessageType.ERROR);
        } 
        return flag;
    }

    public boolean update(Producto p){
        boolean flag = false;
        String query = "UPDATE dbo.Producto SET Nombre = ?, codigo = ?, "
                + "Imagen = ? WHERE dbo.Producto.IdProducto = ?;";
        try {
            pst = conexionbd.getSql().prepareStatement(query);
            pst.setString(1, p.getNombre());
            pst.setString(2, p.getCodigo());
            pst.setBlob(3, p.getFoto());
            pst.setInt(4, p.getID());

            flag = (pst.executeUpdate() == 1);
            pst.close();loadProductos();
        } catch (SQLException ex) {
            Logger.getLogger(BDProducto.class.getName()).log(
                    Level.SEVERE, null, ex);
             JFXOptionPane.showMessageDialog("Error al actualizar",
                     "No se actualizo el producto\n" + ex.getMessage(), 
                     JFXOptionPane.MessageType.ERROR);
        } 
        return flag;
    }
    
    public static boolean delete(Producto p){
        boolean flag = false;
        String query = "DELETE FROM dbo.Producto WHERE dbo.Producto.IdProducto "
                + "= ?;";
        try {
            pst = conexionbd.getSql().prepareStatement(query);
            pst.setInt(1, p.getID());

            flag = (pst.executeUpdate() == 1);
            pst.close();
            loadProductos();
        } catch (SQLException ex) {
            Logger.getLogger(BDProducto.class.getName()).log(Level.SEVERE, null, ex);
             JFXOptionPane.showMessageDialog("Error al eliminar",
                     "No se eliminó el producto\n" + ex.getMessage(), 
                     JFXOptionPane.MessageType.ERROR);
        } 
        return flag;
    }
}
