package Constructores;

import java.sql.Date;

/**
 *
 * @author nesto
 */
public class ContDttvt {

    public int IdVt;
    public Date Fecha;
    public int Cantidad;
    public double Total;

    public ContDttvt() {
    }

    public ContDttvt(int IdVt,Date Fecha, int Cantidad, double Total) {
        this.IdVt = IdVt;
        this.Fecha = Fecha;
        this.Cantidad = Cantidad;
        this.Total = Total;
    }

    public int getIdVt() {
        return IdVt;
    }

    public void setIdVt(int IdVt) {
        this.IdVt = IdVt;
    }

    public int getCantidad() {
        return Cantidad;
    }

    public void setCantidad(int Cantidad) {
        this.Cantidad = Cantidad;
    }

    public double getTotal() {
        return Total;
    }

    public void setTotal(double Precio) {
        this.Total = Precio;
    }

    public Date getFecha() {
        return Fecha;
    }

    public void setFecha(Date Fecha) {
        this.Fecha = Fecha;
    }
}
