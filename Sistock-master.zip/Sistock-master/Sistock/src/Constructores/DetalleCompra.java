/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Constructores;

/**
 *
 * @author josue
 */
public class DetalleCompra {
    private int idDetalle;
    private Compra compra;
    private Material material;
    private String tipoMaterial, unidadMedida;
    private float cantidad, monto;

    public DetalleCompra() {
    }

    public DetalleCompra(Compra compra, Material material, float cantidad) {
        this.compra = compra;
        this.material = material;
        this.cantidad = cantidad;
    }
    
    
    public DetalleCompra(Compra compra, Material material) {
        this.compra = compra;
        this.material = material;
    }

    public DetalleCompra(int idDetalle, Compra compra, Material material, float cantidad) {
        this.idDetalle = idDetalle;
        this.compra = compra;
        this.material = material;
        this.cantidad = cantidad;
    }

    public DetalleCompra(int idDetalle, Compra compra, Material material) {
        this.idDetalle = idDetalle;
        this.compra = compra;
        this.material = material;
    }

    public DetalleCompra(int idDetalle, Compra compra, Material material, String tipoMaterial, String unidadMedida, float cantidad, float monto) {
        this.idDetalle = idDetalle;
        this.compra = compra;
        this.material = material;
        this.tipoMaterial = tipoMaterial;
        this.unidadMedida = unidadMedida;
        this.cantidad = cantidad;
        this.monto = monto;
    }

    
    public int getIdDetalle() {
        return idDetalle;
    }

    public void setIdDetalle(int idDetalle) {
        this.idDetalle = idDetalle;
    }

    public Compra getCompra() {
        return compra;
    }

    public void setCompra(Compra compra) {
        this.compra = compra;
    }

    public Material getMaterial() {
        return material;
    }

    public void setMaterial(Material material) {
        this.material = material;
    }

    public String getTipoMaterial() {
        return tipoMaterial;
    }

    public void setTipoMaterial(String tipoMaterial) {
        this.tipoMaterial = tipoMaterial;
    }

    public String getUnidadMedida() {
        return unidadMedida;
    }

    public void setUnidadMedida(String unidadMedida) {
        this.unidadMedida = unidadMedida;
    }

    public float getCantidad() {
        return cantidad;
    }

    public void setCantidad(float cantidad) {
        this.cantidad = cantidad;
    }

    public float getMonto() {
        return monto;
    }

    public void setMonto(float monto) {
        this.monto = monto;
    }
    
    
}
