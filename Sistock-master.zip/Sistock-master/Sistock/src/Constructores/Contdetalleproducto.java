package Constructores;

/**
 *
 * @author nesto
 */
public class Contdetalleproducto {

    public String material;
    public int cantidad;

    public Contdetalleproducto() {
    }

    public Contdetalleproducto(String material, int cantidad) {
        this.material = material;
        this.cantidad = cantidad;
    }

    public String getMaterial() {
        return material;
    }

    public void setMaterial(String material) {
        this.material = material;
    }

    public int getCantidad() {
        return cantidad;
    }

    public void setCantidad(int cantidad) {
        this.cantidad = cantidad;
    }

}
