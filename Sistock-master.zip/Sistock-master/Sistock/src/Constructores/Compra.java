/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Constructores;

import java.sql.Date;

/**
 *
 * @author josue
 */
public class Compra {
    private int idCompra;
    private Proveedor proveedor;
    private Date fechaCompra;
    private float monto;

    public Compra() {
    }

    public Compra(Proveedor proveedor, Date fechaCompra) {
        this.proveedor = proveedor;
        this.fechaCompra = fechaCompra;
    }

    public Compra(int idCompra, Proveedor proveedor, Date fechaCompra) {
        this.idCompra = idCompra;
        this.proveedor = proveedor;
        this.fechaCompra = fechaCompra;
    }

    public Compra(int idCompra, Proveedor proveedor, Date fechaCompra, float monto) {
        this.idCompra = idCompra;
        this.proveedor = proveedor;
        this.fechaCompra = fechaCompra;
        this.monto = monto;
    }

    public int getIdCompra() {
        return idCompra;
    }

    public void setIdCompra(int idCompra) {
        this.idCompra = idCompra;
    }

    public Proveedor getProveedor() {
        return proveedor;
    }

    public void setProveedor(Proveedor proveedor) {
        this.proveedor = proveedor;
    }

    public Date getFechaCompra() {
        return fechaCompra;
    }

    public void setFechaCompra(Date fechaCompra) {
        this.fechaCompra = fechaCompra;
    }

    public float getMonto() {
        return monto;
    }

    public void setMonto(float monto) {
        this.monto = monto;
    }
    
    @Override
    public String toString(){return this.getIdCompra() + "";}
}
