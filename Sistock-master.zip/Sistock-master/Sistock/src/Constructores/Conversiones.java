/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Constructores;

import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.embed.swing.SwingFXUtils;
import javafx.scene.image.Image;
import javax.imageio.ImageIO;

/**
 *
 * @author josue
 */
public class Conversiones {
    
    //Convierte una imagen a un arreglo de bytes
    public static byte[] extraxtBytes (File imgPath) throws IOException{
        
        byte[] imageInByte;
	BufferedImage originalImage = ImageIO.read(imgPath);

	// convert BufferedImage to byte array
	ByteArrayOutputStream baos = new ByteArrayOutputStream();
	ImageIO.write(originalImage, ((imgPath.getName().contains("jpg")) ? "jpg" : "png"), baos);
	baos.flush();
	imageInByte = baos.toByteArray();
	baos.close();
        
        return imageInByte;
    }
    
    //Convierte un arreglo de bytes pertenecientes a una imagen en Imagen
    public static InputStream extraxtImage(byte[] arr) {
        return  new ByteArrayInputStream(arr);
    }
    
    public static byte[] extraxtBytes(Image img, String formato){
        try {
            BufferedImage bImage = SwingFXUtils.fromFXImage(img, null);
            ByteArrayOutputStream s = new ByteArrayOutputStream();
            ImageIO.write(bImage, formato, s);
            byte[] res  = s.toByteArray(); 
            s.close();
            return res;
        } catch (IOException ex) {
            Logger.getLogger(Conversiones.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }
}
