/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Constructores;

/**
 *
 * @author josue
 */
public class Material {
    
    protected String nombre, descripcion, tipo;
    protected String codigo;
    protected int id;
    protected byte[] foto;
    protected boolean estado;

    public Material() {
    }

    public Material(String nombre, int id) {
        this.nombre = nombre;
        this.id = id;
    }

    public Material(String codigo, String nombre, String descripcion, String tipo, byte[] foto, boolean estado) {
        this.codigo = codigo;
        this.nombre = nombre;
        this.descripcion = descripcion;
        this.tipo = tipo;
        this.foto = foto;
        this.estado = estado;
    }

    public Material(String codigo, String nombre, String descripcion, String tipo, int id, byte[] foto, boolean estado) {
        this.codigo = codigo;
        this.nombre = nombre;
        this.descripcion = descripcion;
        this.tipo = tipo;
        this.id = id;
        this.foto = foto;
        this.estado = estado;
    }
    
    @Override
    public String toString(){return this.getNombre();}

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public byte[] getFoto() {
        return foto;
    }

    public void setFoto(byte[] foto) {
        this.foto = foto;
    }

    public boolean isEstado() {
        return estado;
    }

    public void setEstado(boolean estado) {
        this.estado = estado;
    }
    
    public String getCodigo() {
        return codigo;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }
}
