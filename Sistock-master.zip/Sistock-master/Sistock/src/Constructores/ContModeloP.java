package Constructores;

import java.sql.Date;

/**
 *
 * @author nesto
 */
public class ContModeloP {

    public int IdMP;
    public int Idproducto;
    public String producto;
    public double Inventarioactual;
    public Date fecha;
    public double nivelservicio;
    public int tiemporevision;
    public int tiempoentrega;
    public int demanda;
    public double ss;
    public double Q;
    public String Tipo;

    public ContModeloP() {
    }

    public ContModeloP(int IdMP, int Idproducto, String producto, double Inventarioactual, Date fecha, double nivelservicio, int tiemporevision, int tiempoentrega, int demanda, double ss, double Q, String Tipo) {
        this.IdMP = IdMP;
        this.Idproducto = Idproducto;
        this.producto = producto;
        this.Inventarioactual = Inventarioactual;
        this.fecha = fecha;
        this.nivelservicio = nivelservicio;
        this.tiemporevision = tiemporevision;
        this.tiempoentrega = tiempoentrega;
        this.demanda = demanda;
        this.ss = ss;
        this.Q = Q;
        this.Tipo = Tipo;
    }

    public int getIdMP() {
        return IdMP;
    }

    public void setIdMP(int IdMP) {
        this.IdMP = IdMP;
    }

    public int getIdproducto() {
        return Idproducto;
    }

    public void setIdproducto(int Idproducto) {
        this.Idproducto = Idproducto;
    }

    public String getProducto() {
        return producto;
    }

    public void setProducto(String producto) {
        this.producto = producto;
    }

    public double getInventarioactual() {
        return Inventarioactual;
    }

    public void setInventarioactual(double Inventarioactual) {
        this.Inventarioactual = Inventarioactual;
    }

    public Date getFecha() {
        return fecha;
    }

    public void setFecha(Date fecha) {
        this.fecha = fecha;
    }

    public double getNivelservicio() {
        return nivelservicio;
    }

    public void setNivelservicio(double nivelservicio) {
        this.nivelservicio = nivelservicio;
    }

    public int getTiemporevision() {
        return tiemporevision;
    }

    public void setTiemporevision(int tiemporevision) {
        this.tiemporevision = tiemporevision;
    }

    public int getTiempoentrega() {
        return tiempoentrega;
    }

    public void setTiempoentrega(int tiempoentrega) {
        this.tiempoentrega = tiempoentrega;
    }

    public int getDemanda() {
        return demanda;
    }

    public void setDemanda(int demanda) {
        this.demanda = demanda;
    }

    public double getSs() {
        return ss;
    }

    public void setSs(double ss) {
        this.ss = ss;
    }

    public double getQ() {
        return Q;
    }

    public void setQ(double Q) {
        this.Q = Q;
    }

    public String getTipo() {
        return Tipo;
    }

    public void setTipo(String Tipo) {
        this.Tipo = Tipo;
    }
}
