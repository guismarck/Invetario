/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Constructores;

/**
 *
 * @author josue
 */
public class Config {
    private static Contrabajador trabajadorActual;
    private static Usuario user;
    
    public static Contrabajador getTrabajador() { return trabajadorActual;}
    public static void setTrabajador(Contrabajador trab) {Config.trabajadorActual = trab; }
    
    public static Usuario getUser() { return user;}
    public static void setUser(Usuario user) {Config.user = user; }
    
}
