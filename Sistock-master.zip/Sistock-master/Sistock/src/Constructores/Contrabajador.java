package Constructores;

/**
 *
 * @author Oscar Pereira
 */
public class Contrabajador {
    public int Idtrabajador;
    public String Nombre;
    public String Apellido;
    public int Edad;
    public String Cedula;
    public String Correo;
    public int Celular;
    public String Usuario;
    public String Contraseña;
    private String lastUpdate;

    public Contrabajador() {
    }

    public Contrabajador(int Idtrabajador, String Nombre, String Apellido, int Edad, String Cedula, String Correo, int Celular, String Usuario, String Contraseña) {
        this.Idtrabajador = Idtrabajador;
        this.Nombre = Nombre;
        this.Apellido = Apellido;
        this.Edad = Edad;
        this.Cedula = Cedula;
        this.Correo = Correo;
        this.Celular = Celular;
        this.Usuario = Usuario;
        this.Contraseña = Contraseña;
    }
    
    public Contrabajador(int Idtrabajador, String Nombre, String Apellido, int Edad, String Cedula, String Correo, int Celular, String Usuario, String Contraseña, String lastUpdate) {
        this.Idtrabajador = Idtrabajador;
        this.Nombre = Nombre;
        this.Apellido = Apellido;
        this.Edad = Edad;
        this.Cedula = Cedula;
        this.Correo = Correo;
        this.Celular = Celular;
        this.Usuario = Usuario;
        this.Contraseña = Contraseña;
        this.lastUpdate = lastUpdate;
    }
    
    public int getIdtrabajador() {
        return Idtrabajador;
    }

    public void setIdtrabajador(int Idtrabajador) {
        this.Idtrabajador = Idtrabajador;
    }

    public String getNombre() {
        return Nombre;
    }

    public void setNombre(String Nombre) {
        this.Nombre = Nombre;
    }

    public String getApellido() {
        return Apellido;
    }

    public void setApellido(String Apellido) {
        this.Apellido = Apellido;
    }

    public int getEdad() {
        return Edad;
    }

    public void setEdad(int Edad) {
        this.Edad = Edad;
    }

    public String getCedula() {
        return Cedula;
    }

    public void setCedula(String Cedula) {
        this.Cedula = Cedula;
    }

    public String getCorreo() {
        return Correo;
    }

    public void setCorreo(String Correo) {
        this.Correo = Correo;
    }

    public int getCelular() {
        return Celular;
    }

    public void setCelular(int Celular) {
        this.Celular = Celular;
    }

    public String getUsuario() {
        return Usuario;
    }

    public void setUsuario(String Usuario) {
        this.Usuario = Usuario;
    }

    public String getContraseña() {
        return Contraseña;
    }

    public void setContraseña(String Contraseña) {
        this.Contraseña = Contraseña;
    }

    public String getLastUpdate() {
        return lastUpdate;
    }

    public void setLastUpdate(String lastUpdate) {
        this.lastUpdate = lastUpdate;
    }
    
    
}
