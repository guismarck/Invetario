package Constructores;

import java.sql.Date;

/**
 *
 * @author nesto
 */
public class Contproducto {

    public int Idinventario;
    public int Idproducto;
    public String codigo;
    public String Nombre;
    public Date Fecha;
    public Double StockI;
    public Double StockA;
    public Double Precio;

    public Contproducto() {
    }

    public Contproducto(int Idinventario, int Idproducto, String codigo, String Nombre, Date Fecha, Double StockI, Double StockA, Double Precio) {
        this.Idinventario = Idinventario;
        this.Idproducto = Idproducto;
        this.codigo = codigo;
        this.Nombre = Nombre;
        this.Fecha = Fecha;
        this.StockI = StockI;
        this.StockA = StockA;
        this.Precio = Precio;
    }

    public int getIdinventario() {
        return Idinventario;
    }

    public void setIdinventario(int Idinventario) {
        this.Idinventario = Idinventario;
    }

    public int getIdproducto() {
        return Idproducto;
    }

    public void setIdproducto(int Idproducto) {
        this.Idproducto = Idproducto;
    }

    public String getCodigo() {
        return codigo;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    public String getNombre() {
        return Nombre;
    }

    public void setNombre(String Nombre) {
        this.Nombre = Nombre;
    }

    public Date getFecha() {
        return Fecha;
    }

    public void setFecha(Date Fecha) {
        this.Fecha = Fecha;
    }

    public Double getStockI() {
        return StockI;
    }

    public void setStockI(Double StockI) {
        this.StockI = StockI;
    }

    public Double getStockA() {
        return StockA;
    }

    public void setStockA(Double StockA) {
        this.StockA = StockA;
    }

    public Double getPrecio() {
        return Precio;
    }

    public void setPrecio(Double Precio) {
        this.Precio = Precio;
    }

}
