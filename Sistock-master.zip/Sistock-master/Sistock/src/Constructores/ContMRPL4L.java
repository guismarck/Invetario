package Constructores;

/**
 *
 * @author nesto
 */
public class ContMRPL4L {

    public int Idmrpl4l;
    public int Semana;
    public Double Demanda;
    public Double Producir;
    public Double Actual;
    public Double H;
    public Double S;
    public Double ct;

    public ContMRPL4L() {
    }

    public ContMRPL4L(int Idmrpl4l, int Semana, Double Demanda, Double Producir, Double Actual, Double H, Double S, Double ct) {
        this.Idmrpl4l = Idmrpl4l;
        this.Semana = Semana;
        this.Demanda = Demanda;
        this.Producir = Producir;
        this.Actual = Actual;
        this.H = H;
        this.S = S;
        this.ct = ct;
    }

    public int getIdmrpl4l() {
        return Idmrpl4l;
    }

    public void setIdmrpl4l(int Idmrpl4l) {
        this.Idmrpl4l = Idmrpl4l;
    }

    public int getSemana() {
        return Semana;
    }

    public void setSemana(int Semana) {
        this.Semana = Semana;
    }

    public Double getDemanda() {
        return Demanda;
    }

    public void setDemanda(Double Demanda) {
        this.Demanda = Demanda;
    }

    public Double getProducir() {
        return Producir;
    }

    public void setProducir(Double Producir) {
        this.Producir = Producir;
    }

    public Double getActual() {
        return Actual;
    }

    public void setActual(Double Actual) {
        this.Actual = Actual;
    }

    public Double getH() {
        return H;
    }

    public void setH(Double H) {
        this.H = H;
    }

    public Double getS() {
        return S;
    }

    public void setS(Double S) {
        this.S = S;
    }

    public Double getCt() {
        return ct;
    }

    public void setCt(Double ct) {
        this.ct = ct;
    }



}
