/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Constructores;

import java.sql.Blob;

/**
 *
 * @author josue
 */
public class Producto {
    private int ID;
    private String codigo, nombre;
    private Blob foto;

    public Producto() {
    }

    public Producto(String nombre) {
        this.nombre = nombre;
    }
    
    public Producto(String nombre, Blob foto) {
        this.nombre = nombre;
        this.foto = foto;
    }
    
    public Producto(int ID, String nombre, Blob foto) {
        this.ID = ID;
        this.nombre = nombre;
        this.foto = foto;
    }

    public Producto(int ID, String codigo, String nombre , Blob foto) {
        this.ID = ID;
        this.codigo = codigo;
        this.nombre = nombre;
        this.foto = foto;
    }
    public int getID() {
        return ID;
    }

    public void setID(int ID) {
        this.ID = ID;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }


    public Blob getFoto() {
        return foto;
    }

    public void setFoto(Blob foto) {
        this.foto = foto;
    }

    public String getCodigo() {
        return codigo;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }
    
    
}
