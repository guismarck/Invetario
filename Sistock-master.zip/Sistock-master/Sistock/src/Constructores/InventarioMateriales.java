/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Constructores;

import java.sql.Date;

/**
 *
 * @author josue
 */
public class InventarioMateriales {
    private int idInventario;
    private Proveedor proveedor;
    private Material material;
    private Date fechaVence;
    float stockInicial;
    float stockActual;
    String unidadMedida;
    float precio;

    public InventarioMateriales() {
    }

    public InventarioMateriales(int idInventario, Proveedor proveedor, Material material, Date fechaVence, float stockInicial, float stockActual, String unidadMedida, float precio) {
        this.idInventario = idInventario;
        this.proveedor = proveedor;
        this.material = material;
        this.fechaVence = fechaVence;
        this.stockInicial = stockInicial;
        this.stockActual = stockActual;
        this.unidadMedida = unidadMedida;
        this.precio = precio;
    }

    public InventarioMateriales(Proveedor proveedor, Material material) {
        this.proveedor = proveedor;
        this.material = material;
    }

    
    public int getIdInventario() {
        return idInventario;
    }

    public void setIdInventario(int idInventario) {
        this.idInventario = idInventario;
    }

    public Proveedor getProveedor() {
        return proveedor;
    }

    public void setProveedor(Proveedor proveedor) {
        this.proveedor = proveedor;
    }

    public Material getMaterial() {
        return material;
    }

    public void setMaterial(Material material) {
        this.material = material;
    }

    public Date getFechaVence() {
        return fechaVence;
    }

    public void setFechaVence(Date fechaVence) {
        this.fechaVence = fechaVence;
    }

    public float getStockInicial() {
        return stockInicial;
    }

    public void setStockInicial(float stockInicial) {
        this.stockInicial = stockInicial;
    }

    public float getStockActual() {
        return stockActual;
    }

    public void setStockActual(float stockActual) {
        this.stockActual = stockActual;
    }

    public String getUnidadMedida() {
        return unidadMedida;
    }

    public void setUnidadMedida(String unidadMedida) {
        this.unidadMedida = unidadMedida;
    }

    public float getPrecio() {
        return precio;
    }

    public void setPrecio(float precio) {
        this.precio = precio;
    }
    
    @Override
    public String toString(){return this.getMaterial().getNombre();}
}
