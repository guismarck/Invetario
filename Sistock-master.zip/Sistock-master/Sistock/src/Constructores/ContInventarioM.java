package Constructores;

import java.sql.Date;

/**
 *
 * @author nesto
 */
public class ContInventarioM {

    public int idinventario;
    public int idproveedor;
    public String proveedor;
    public int idmaterial;
    public String material;
    public String codigo;
    public String tipo;
    public String estado;
    public String descripcion;

    public Date date;
    public double stockinical;
    public double stockactual;
    public String unidadmedida;
    public double precio;

    public ContInventarioM() {
    }

    public ContInventarioM(int idinventario, int idproveedor, String proveedor, int idmaterial, String codigo,
            String material, String descripcion, String tipo, String estado, Date date, double stockinical,
            double stockactual, String unidadmedida, double precio) {

        this.idinventario = idinventario;
        this.idproveedor = idproveedor;
        this.proveedor = proveedor;
        this.idmaterial = idmaterial;
        this.material = material;
        this.codigo = codigo;
        this.estado = estado;
        this.descripcion = descripcion;
        this.date = date;
        this.stockinical = stockinical;
        this.stockactual = stockactual;
        this.unidadmedida = unidadmedida;
        this.precio = precio;
        this.tipo = tipo;
    }

    public int getIdinventario() {
        return idinventario;
    }

    public void setIdinventario(int idinventario) {
        this.idinventario = idinventario;
    }

    public int getIdproveedor() {
        return idproveedor;
    }

    public void setIdproveedor(int idproveedor) {
        this.idproveedor = idproveedor;
    }

    public String getProveedor() {
        return proveedor;
    }

    public void setProveedor(String proveedor) {
        this.proveedor = proveedor;
    }

    public int getIdmaterial() {
        return idmaterial;
    }

    public void setIdmaterial(int idmaterial) {
        this.idmaterial = idmaterial;
    }

    public String getMaterial() {
        return material;
    }

    public void setMaterial(String material) {
        this.material = material;
    }

    public double getStockinical() {
        return stockinical;
    }

    public void setStockinical(double stockinical) {
        this.stockinical = stockinical;
    }

    public double getStockactual() {
        return stockactual;
    }

    public void setStockactual(double stockactual) {
        this.stockactual = stockactual;
    }

    public String getUnidadmedida() {
        return unidadmedida;
    }

    public void setUnidadmedida(String unidadmedida) {
        this.unidadmedida = unidadmedida;
    }

    public double getPrecio() {
        return precio;
    }

    public void setPrecio(double precio) {
        this.precio = precio;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public String getCodigo() {
        return codigo;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

}
