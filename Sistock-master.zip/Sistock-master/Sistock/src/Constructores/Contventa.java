package Constructores;

/**
 *
 * @author nesto
 */
public class Contventa {

    public int IdDtt;
    public int IdVt;
    public int IdProducto;
    public String Producto;
    public int Cantidad;
    public double Precio;

    public Contventa() {
    }

    public Contventa(int IdDtt, int IdVt, int IdProducto, String Producto, int Cantidad, double Precio) {
        this.IdDtt = IdDtt;
        this.IdVt = IdVt;
        this.IdProducto = IdProducto;
        this.Producto = Producto;
        this.Cantidad = Cantidad;
        this.Precio = Precio;
    }

    public int getIdDtt() {
        return IdDtt;
    }

    public void setIdDtt(int IdDtt) {
        this.IdDtt = IdDtt;
    }

    public int getIdVt() {
        return IdVt;
    }

    public void setIdVt(int IdVt) {
        this.IdVt = IdVt;
    }

    public int getIdProducto() {
        return IdProducto;
    }

    public void setIdProducto(int IdProducto) {
        this.IdProducto = IdProducto;
    }

    public String getProducto() {
        return Producto;
    }

    public void setProducto(String Producto) {
        this.Producto = Producto;
    }

    public int getCantidad() {
        return Cantidad;
    }

    public void setCantidad(int Cantidad) {
        this.Cantidad = Cantidad;
    }

    public double getPrecio() {
        return Precio;
    }

    public void setPrecio(double Precio) {
        this.Precio = Precio;
    }
}
