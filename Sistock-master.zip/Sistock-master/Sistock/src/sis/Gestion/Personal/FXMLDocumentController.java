package sis.Gestion.Personal;

import Conexion.conexionbd;
import Constructores.Contrabajador;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javax.swing.JOptionPane;

/**
 *
 * @author Oscar Pereira
 */
public class FXMLDocumentController implements Initializable {

    @FXML
    private Button btnguardar;

    private ObservableList<Contrabajador> dato;
    private PreparedStatement pst = null;
    private ResultSet rs = null;

    @FXML
    private TableView<Contrabajador> Tablaempleado;
    @FXML
    private TableColumn<?, ?> Tidempleado;
    @FXML
    private TableColumn<?, ?> Tnombre;
    @FXML
    private TableColumn<?, ?> Tapellido;
    @FXML
    private TableColumn<?, ?> Tcedula;
    @FXML
    private TableColumn<?, ?> Tcorreo;
    @FXML
    private TableColumn<?, ?> Tcelular;
    @FXML
    private TableColumn<?, ?> Tusuario;
    @FXML
    private TableColumn<?, ?> Tcontraseña;

    @FXML
    private TextField txtnombre;
    @FXML
    private TextField txtusuario;
    @FXML
    private TextField txtapellido;
    @FXML
    private TextField txtcorreo;
    @FXML
    private TextField txtcontraseña;
    @FXML
    private TextField txtedad;
    @FXML
    private TextField txtcedula;
    @FXML
    private TextField txtcelular;

    @FXML
    private TableColumn<?, ?> Tedad;
    @FXML
    private Label errornombre;

    @FXML
    private void actionguardar(ActionEvent event) throws Exception {

        String sql = "Insert into Empleado(Nombre,Apellido,Edad,Cedula,correo,Celular,usuario,Pass) values"
                + "(?,?,?,?,?,?,?,?)";

        String Nombre = txtnombre.getText();
        String Apellido = txtapellido.getText();
        int Edad = Integer.parseInt(txtedad.getText());
        String Cedula = txtcedula.getText();
        String Correo = txtcorreo.getText();
        int Celular = Integer.parseInt(txtcelular.getText());
        String Usuario = txtusuario.getText();
        String Contraseña = txtcontraseña.getText();

        try {

            pst = conexionbd.getSql().prepareStatement(sql);
            pst.setString(1, Nombre);
            pst.setString(2, Apellido);
            pst.setInt(3, Edad);
            pst.setString(4, Cedula);
            pst.setString(5, Correo);
            pst.setInt(6, Celular);
            pst.setString(7, Usuario);
            pst.setString(8, Contraseña);

            int i = pst.executeUpdate();

            if (i == 1) {
                JOptionPane.showMessageDialog(null, "Datos insertados correctamente");
                setCellTable();
                loadDatetable();
            }

        } catch (SQLException ex) {
            Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
             JOptionPane.showMessageDialog(null, ex);
        } finally {
            pst.close();
        }

    }

    @Override
    public void initialize(URL url, ResourceBundle rb) {

        try {
            dato = FXCollections.observableArrayList();
            setCellTable();
            loadDatetable();

        } catch (Exception ex) {
            Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    private void setCellTable() {

        Tidempleado.setCellValueFactory(new PropertyValueFactory<>("Idtrabajador"));
        Tnombre.setCellValueFactory(new PropertyValueFactory<>("Nombre"));
        Tapellido.setCellValueFactory(new PropertyValueFactory<>("Apellido"));
        Tedad.setCellValueFactory(new PropertyValueFactory<>("Edad"));
        Tcedula.setCellValueFactory(new PropertyValueFactory<>("Cedula"));
        Tcorreo.setCellValueFactory(new PropertyValueFactory<>("correo"));
        Tcelular.setCellValueFactory(new PropertyValueFactory<>("Celular"));
        Tusuario.setCellValueFactory(new PropertyValueFactory<>("usuario"));
        Tcontraseña.setCellValueFactory(new PropertyValueFactory<>("Contraseña"));

    }

    private void loadDatetable() {

        dato.clear();
        
        try {
            
            pst = conexionbd.getSql().prepareStatement("select * from Empleado");
            rs = pst.executeQuery();

            while (rs.next()) {
                dato.add(new Contrabajador(rs.getInt(1), rs.getString(2), rs.getString(3), rs.getInt(4), rs.getString(5), rs.getString(6), rs.getInt(7), rs.getString(8), rs.getString(9)));
            }
        } catch (SQLException ex) {

            Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
        }

        Tablaempleado.setItems(dato);
    }
}
