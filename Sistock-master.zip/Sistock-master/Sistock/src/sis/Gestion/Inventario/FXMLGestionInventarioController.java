/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sis.Gestion.Inventario;

import Constructores.Conversiones;
import Constructores.Producto;
import Inventario_Optiomo.ViewModel;
import Util.JFXOptionPane;
import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXTextField;
import impl.org.controlsfx.autocompletion.AutoCompletionTextFieldBinding;
import impl.org.controlsfx.autocompletion.SuggestionProvider;
import java.net.URL;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import produccion3.BDProducto;
import sis.Gestion.Personal.FXMLDocumentController;
import java.io.IOException;
import java.sql.Blob;
import java.sql.SQLException;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.stage.StageStyle;

/**
 * FXML Controller class
 *
 * @author josue
 */
public class FXMLGestionInventarioController implements Initializable {

    @FXML
    private TableView<Producto> tableView;
    @FXML
    private JFXTextField txtNombre, txtTipo;
    @FXML
    private ImageView img;
    @FXML
    private JFXButton btnAdd, btnEdit, btnDelete, btnRecharge;

    //Columnas
    private TableColumn<Producto, String> colID, colCod, colNom, colFoto;

    //Variables
    private BDProducto mod;
    private boolean isThereIMG = false;
    private Conversiones conv;
    private boolean haveId;
//    public static Producto currentProducto = null;
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        //Inicializando
        conv = new Conversiones();
        mod = new BDProducto();
        initTable();
        loadData();
        init();
    }

    @FXML
    private void actionOnMouseClicked(MouseEvent event) {
        int row = tableView.getSelectionModel().getSelectedIndex();
        if (row > -1) {
            btnDelete.setDisable(false);
            btnEdit.setDisable(false);
            Producto p = new Producto();
            p.setCodigo(tableView.getColumns().get(1).getCellData(row).toString());
            p.setNombre(tableView.getColumns().get(2).getCellData(row).toString());
            p.setFoto((Blob) tableView.getColumns().get(3).getCellData(row));
            isThereIMG = true;
            setProducto(p);
        }
    }

    private void init() {
        //Imagen
        img.addEventHandler(MouseEvent.MOUSE_CLICKED, (e) -> {
            isThereIMG = ViewModel.chooiseImage(img);
        });
        //Eventos de botones
        btnAdd.addEventHandler(MouseEvent.MOUSE_CLICKED, (e) -> {
            haveId = false;
            Producto p = getProducto();
            if (p != null) {
                loadWindows("/Gestion_Inventario/FXMLProductoMaterial.fxml");
                if (FXMLProductoMaterialController.wasSelected) {
                    mod.insert(p);
                    reset();
                    JFXOptionPane.showMessageDialog(
                        "Transacción ejecutada",
                        "Todo ha ido muy bien.",
                        JFXOptionPane.MessageType.OK);
                }else{
                    JFXOptionPane.showMessageDialog(
                        "Transacción ejecutada",
                        "Todo ha ido muy mal.",
                        JFXOptionPane.MessageType.ERROR);
                }
            }

        });

        btnDelete.addEventHandler(MouseEvent.MOUSE_CLICKED, (e) -> {
            haveId = true;
            Producto p = getProducto();
            
            if (p != null) {
                int result = JFXOptionPane.showMessageDialog(
                        "Confirmación",
                        "Seguro que desea eliminar este producto.",
                        JFXOptionPane.MessageType.OK);
                if (result == 1) {
                     BDProducto.delete(p);
                }
            }

        });

        btnEdit.addEventHandler(MouseEvent.MOUSE_CLICKED, (e) -> {
            haveId = true;
            Producto p = getProducto();
            if (p != null) {
                mod.update(p);
                reset();
            }
        });

        btnRecharge.addEventHandler(MouseEvent.MOUSE_CLICKED, (e) -> {
            loadData();
            reset();
        });

        txtTipo.textProperty().addListener((arg, oldValue, newValue) -> {
            if (txtTipo.getText().length() > 0) {
                new AutoCompletionTextFieldBinding<>((TextField) txtTipo, SuggestionProvider.create(advise(newValue)));
            }
        });
    }

    //Se inicializan las columnas
    private void initTable() {
        //Inicializan las columnas
        colID = new TableColumn("ID");
        colCod = new TableColumn("codigo");
        colNom = new TableColumn("Nombre");
        colFoto = new TableColumn("Foto");
        colFoto.setVisible(false);

        //Agrega las columnas
        tableView.getColumns().clear();
        tableView.getColumns().add(colID);
        tableView.getColumns().add(colCod);
        tableView.getColumns().add(colNom);
        tableView.getColumns().add(colFoto);
    }

    //Setear los nombres de las variables en la tabla
    private void setCellTable() {

        colID.setCellValueFactory(new PropertyValueFactory<>("ID"));
        colCod.setCellValueFactory(new PropertyValueFactory<>("Codigo"));
        colNom.setCellValueFactory(new PropertyValueFactory<>("Nombre"));
        colFoto.setCellValueFactory(new PropertyValueFactory<>("Foto"));
    }

    private void loadData() {
        try {
            setCellTable();
            tableView.setItems(BDProducto.loadProductos());
        } catch (Exception ex) {
            Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    private Producto getProducto() {
        Image image = img.getImage();
        byte[] buf = null;
        if (image != null) {
           buf = conv.extraxtBytes(image, "jpg");
        }

        String nombre, tipo;
        nombre = txtNombre.getText();
        tipo = txtTipo.getText();
        Producto p = null;
        if (!nombre.trim().isEmpty() && !tipo.trim().isEmpty() && isThereIMG) {
            p = new Producto();
            p.setNombre(nombre);
            p.setCodigo(tipo);
            try {
                p.setFoto(new javax.sql.rowset.serial.SerialBlob(buf));
            } catch (SQLException ex) {
                Logger.getLogger(FXMLGestionInventarioController.class.getName()).log(Level.SEVERE, null, ex);
            }

            if (haveId) {
                int row = tableView.getSelectionModel().getSelectedIndex();
                int id = Integer.parseInt(tableView.getColumns().get(0).getCellData(row).toString());
                p.setID(id);
            }
        } else {
            JFXOptionPane.showMessageDialog("Campos Vacios", "Aún hay campos vacios.", JFXOptionPane.MessageType.INFO);
        }
        return p;
    }

    private void setProducto(Producto p) {
        if (isThereIMG) {
            try {
                img.setImage(new Image(conv.extraxtImage(p.getFoto().getBytes(1, (int)p.getFoto().length()))));
            } catch (SQLException ex) {
                Logger.getLogger(FXMLGestionInventarioController.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        txtNombre.setText(p.getNombre());
        txtTipo.setText(p.getCodigo());
    }

    private void reset() {
        img.setImage(new Image("/img/icons8-product-512-plus.png"));
        txtNombre.setText("");
        txtTipo.setText("");
        btnDelete.setDisable(true);
        btnEdit.setDisable(true);
        isThereIMG = false;
    }

    private ObservableList<String> advise(String value) {
        ObservableList<String> items = FXCollections.observableArrayList();
        ObservableList<Producto> sr = tableView.getItems();
        for (Producto tem : sr) {
            if (!isIt(items, tem.getCodigo())) {
                items.add(tem.getCodigo());
            }
        }
        return items;
    }

    private boolean isIt(ObservableList<String> items, String element) {
        for (String item : items) {
            if (item.equalsIgnoreCase(element)) {
                return true;
            }
        }
        return false;
    }
    
    private void loadWindows(String path){
        try {
            Parent root = FXMLLoader.load(getClass().getResource(path));
            Scene scene = new Scene(root);
            Stage stage = new Stage();
            stage.setScene(scene);
            stage.initModality(Modality.APPLICATION_MODAL);
            stage.initStyle(StageStyle.UNIFIED);
            stage.showAndWait();
        } catch (IOException ex) {
            Logger.getLogger(FXMLGestionInventarioController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
