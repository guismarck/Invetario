/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sis.Gestion.Compras;

import Util.Cargarcombo;
import java.awt.Desktop;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.URL;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import javax.swing.JOptionPane;

/**
 * FXML Controller class
 *
 * @author nesto
 */
public class FXMLMaterialesController implements Initializable {

    private FileChooser filechoose;
    private File file;
    private Stage stage;
    private Image image;
    private FileInputStream fls;

    private final Desktop deskTop = Desktop.getDesktop();
    private Connection con = null;

    private PreparedStatement pst = null;
    private ResultSet rs = null;

    private PreparedStatement pst2 = null;
    private ResultSet rs2 = null;

    private ObservableList<String> cbx = FXCollections.observableArrayList();
    private ObservableList<String> cbx2 = FXCollections.observableArrayList();
    private ObservableList<String> cbx3 = FXCollections.observableArrayList();

    @FXML
    private AnchorPane anchorPane;
    @FXML
    public TextField idmaterial;
    @FXML
    public TextField txtcodigo;
    @FXML
    public TextField txtnombre;
    @FXML
    public TextArea txtdescripcion;
    @FXML
    public ImageView imagenview;
    @FXML
    public ComboBox cbproveedor;
    @FXML
    public DatePicker dtpiker;
    @FXML
    public ComboBox<String> cbestado;
    @FXML
    public ComboBox cbmedida;
    @FXML
    public TextField txtprecio;
    @FXML
    public ComboBox<String> cbtipo;
    @FXML
    public TextField txtinical;
    @FXML
    public TextField txtactual;
    @FXML
    public TextField txtiddetalle;
    @FXML
    private RadioButton btnbuscarimagen;
    @FXML
    private Button btnguardar;
    @FXML
    private Button btneditar;
    @FXML
    private Button btneliminar;
    @FXML
    private Button btncancelar;

    Cargarcombo cb = new Cargarcombo();

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        filechoose = new FileChooser();
        filechoose.setTitle("LALO");
        filechoose.getExtensionFilters().addAll(
                new FileChooser.ExtensionFilter("All Files", "*.*"),
                new FileChooser.ExtensionFilter("Image Files", "*.png", "*.jpg", "*.gif"),
                new FileChooser.ExtensionFilter("Text File", "*txt"));

        try {
            con = Conexion.conexionbd.conectar("Eduardo23", "1234");
            cb.consultar_proveedor(cbproveedor);
            cbx.addAll("Existencia", "Agotado");
            cbestado.setItems(cbx);
            cbx2.addAll("Lt", "Kg");
            cbmedida.setItems(cbx2);
            cbx3.addAll("Lacteo", "Fruta");
            cbtipo.setItems(cbx3);

        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, ex);
            Logger.getLogger(FXMLMaterialesController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @FXML
    private void actionimagen(ActionEvent event) {
        stage = (Stage) anchorPane.getScene().getWindow();
        file = filechoose.showOpenDialog(stage);

        if (file != null) {
            System.out.println("" + file.getAbsolutePath());
            image = new Image(file.getAbsoluteFile().toURI().toString(), imagenview.getFitWidth(), imagenview.getFitHeight(), true, true);
            imagenview.setImage(image);
            imagenview.setPreserveRatio(true);
        }
    }

    @FXML
    private void actionguardar(ActionEvent event) throws SQLException {

        String sql = "Insert into Materiales(Codigo, Nombre, Descripcion,"
                + " Imagen, Estado) values"
                + "(?,?,?,?,?)";

        String codigo = txtcodigo.getText();
        String Nombre = txtnombre.getText();
        String descripcion = txtdescripcion.getText();
        String estado = cbestado.getSelectionModel().getSelectedItem();

        int idproveedor = cbproveedor.getSelectionModel().getSelectedIndex();

        java.sql.Date Picker = java.sql.Date.valueOf(dtpiker.getValue());

        Double incial = Double.parseDouble(txtinical.getText());
        Double actual = Double.parseDouble(txtactual.getText());

        String unidad = (String) cbmedida.getSelectionModel().getSelectedItem();
        Double precio = Double.parseDouble(txtprecio.getText());

        try {

            fls = new FileInputStream(file);

            pst = con.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
            pst.setString(1, codigo);
            pst.setString(2, Nombre);
            pst.setString(3, descripcion);
            pst.setBinaryStream(4, fls, file.length());
            pst.setString(5, estado);

            int i = pst.executeUpdate();
            rs = pst.getGeneratedKeys();
            rs.next();

            Object key = rs.getObject(1);

            String sql2 = "Insert into Inventario_materiales(IdProveedor , IdMateriales, Fecha_vencimiento,"
                    + " StocK_inicial, Stock_actual ,Unidad_medida ,Precio) values"
                    + "(?,?,?,?,?,?,?)";
            pst2 = con.prepareStatement(sql2);
            pst2.setInt(1, idproveedor);
            pst2.setInt(2, Integer.parseInt(String.valueOf(key)));
            pst2.setDate(3, Picker);
            pst2.setDouble(4, incial);
            pst2.setDouble(5, actual);
            pst2.setString(6, unidad);
            pst2.setDouble(7, precio);

            int j = pst2.executeUpdate();
            if (i == 1 && j == 1) {
                JOptionPane.showMessageDialog(null, "Datos insertados correctamente");
            }

        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, ex);
            Logger.getLogger(FXMLMaterialesController.class.getName()).log(Level.SEVERE, null, ex);
        } catch (FileNotFoundException ex) {
            JOptionPane.showMessageDialog(null, ex);
            Logger.getLogger(FXMLMaterialesController.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            pst.close();
        }
    }

    @FXML
    private void actioneditar(ActionEvent event) throws SQLException {

        String sql = "update Materiales set Codigo=?, Nombre=?, Descripcion =?,"
                + " Imagen=?, Estado=? where IdMateriales=?";

        int idmateriall = Integer.parseInt(idmaterial.getText());
        String codigo = txtcodigo.getText();
        String Nombre = txtnombre.getText();
        String descripcion = txtdescripcion.getText();
        String estado = cbestado.getPromptText();

        int idinventario = Integer.parseInt(txtiddetalle.getText());
        int idproveedor = cbproveedor.getSelectionModel().getSelectedIndex();

        java.sql.Date Picker = java.sql.Date.valueOf(dtpiker.getValue());

        Double incial = Double.parseDouble(txtinical.getText());
        Double actual = Double.parseDouble(txtactual.getText());

        String unidad = (String) cbmedida.getPromptText();
        Double precio = Double.parseDouble(txtprecio.getText());

        try {

            fls = new FileInputStream(file);
            pst = con.prepareStatement(sql);
            pst.setString(1, codigo);
            pst.setString(2, Nombre);
            pst.setString(3, descripcion);
            pst.setBinaryStream(4, fls, file.length());
            pst.setString(5, estado);
            pst.setInt(6, idmateriall);

            int i = pst.executeUpdate();

            String sql2 = "update Inventario_materiales set IdProveedor=?, IdMateriales=?, Fecha_vencimiento=?,"
                    + " StocK_inicial=?, Stock_actual=? ,Unidad_medida=? ,Precio=? where IdInventario=?";
            pst2 = con.prepareStatement(sql2);
            pst2.setInt(1, idproveedor);
            pst2.setInt(2, idmateriall);
            pst2.setDate(3, Picker);
            pst2.setDouble(4, incial);
            pst2.setDouble(5, actual);
            pst2.setString(6, unidad);
            pst2.setDouble(7, precio);
            pst2.setInt(8, idinventario);
            int j = pst2.executeUpdate();

            if (i == 1 && j == 1) {
                JOptionPane.showMessageDialog(null, "Datos insertados correctamente");
            }

        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, ex);
            Logger.getLogger(FXMLMaterialesController.class.getName()).log(Level.SEVERE, null, ex);
        } catch (FileNotFoundException ex) {
            Logger.getLogger(FXMLMaterialesController.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            pst.close();
        }
    }

    @FXML
    private void actioneliminar(ActionEvent event) {

        String sql = "delete Inventario_materiales  where IdInventario=?";
        int id = Integer.parseInt(txtiddetalle.getText());

        try {

            pst = con.prepareStatement(sql);
            pst.setInt(1, id);

            int i = pst.executeUpdate();

            if (i == 1) {
                JOptionPane.showMessageDialog(null, "Datos eliminados correctamente");
            }

        } catch (Exception e) {
            Logger.getLogger(FXMLMaterialesController.class.getName()).log(Level.SEVERE, null, e);
        }
    }

    @FXML
    private void actioncancelar(ActionEvent event) throws IOException {

        Parent root = FXMLLoader.load(getClass().getResource("/produccion3/FXMLTablamaterial.fxml"));
        Stage stage = new Stage();
        Scene scene = new Scene(root);

        stage.setScene(scene);
        stage.show();

    }

    @FXML
    public void llenardatos(String iddetalle, String proveedor, String idmateria, String codigo,
            String nombre, String descripcion, String tipo, String estado,
            LocalDate fecha, String inical, String actual, String unidad, String precio) throws SQLException {
        try {

            txtiddetalle.setText(iddetalle);
            cbproveedor.setPromptText(proveedor);
            idmaterial.setText(idmateria);
            txtcodigo.setText(codigo);
            txtnombre.setText(nombre);
            txtdescripcion.setText(descripcion);
            cbtipo.setPromptText(tipo);
            dtpiker.setValue(fecha);
            cbestado.setPromptText(estado);
            txtinical.setText(inical);
            txtactual.setText(actual);
            cbmedida.setPromptText(unidad);
            txtprecio.setText(precio);

            pst = con.prepareStatement("Select Imagen from Materiales where Nombre =?");
            pst.setString(1, nombre);
            rs = pst.executeQuery();

            if (rs.next()) {
                InputStream ls = rs.getBinaryStream(1);
                OutputStream os = new FileOutputStream(new File("photo.jpg"));
                byte[] contents = new byte[1024];
                int size = 0;

                while ((size = ls.read(contents)) != -1) {
                    os.write(contents, 0, size);
                }

                image = new Image("file:photo.jpg", imagenview.getFitWidth(), imagenview.getFitHeight(), true, true);
                imagenview.setImage(image);

            }
        } catch (Exception e) {
            Logger.getLogger(FXMLMaterialesController.class.getName()).log(Level.SEVERE, null, e);
        }

    }

}
