/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sis.Gestion.Compras;

import Constructores.Compra;
import Constructores.DetalleCompra;
import Constructores.InventarioMateriales;
import Constructores.Material;
import Util.JFXOptionPane;
import com.jfoenix.controls.JFXButton;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.layout.HBox;
import Util.Tabla;
import Util.Validacion;
import com.jfoenix.controls.JFXComboBox;
import com.jfoenix.controls.JFXTextField;
import java.util.Arrays;
import java.util.List;
import javafx.collections.ObservableList;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;
import produccion3.BDMaterial;
import produccion3.DBDetalleCompra;
import produccion3.DInventario_Materiales;
/**
 * FXML Controller class
 *
 * @author josue
 */
public class FXMLDetalleCompraController extends Tabla<DetalleCompra> implements Initializable {

    @FXML
    private HBox pnTable;
     @FXML
    private JFXTextField txtIdDetalle, txtIdCompra, cbCantidad;
    @FXML
    private JFXComboBox<InventarioMateriales> cbMaterial;
    @FXML
    private JFXButton btnAdd, btnEdit, btnDelete, btnRecharge;

    public static Compra compra;
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        initTable(pnTable);
        Validacion.ValidacionNumérica(cbCantidad);
        //Llena el combobox que contiene la lista de materiales
        ObservableList<InventarioMateriales> dataMat = DInventario_Materiales.loadInventarioMateriales(compra.getProveedor());
        cbMaterial.setItems(dataMat);
        
        //Evento del combobox
        cbMaterial.setOnAction(new EventHandler(){
            @Override
            public void handle(Event event) {
                isEmpty();
            }
        });
        
        //Evento de la caja de texto
        cbCantidad.addEventHandler(KeyEvent.KEY_RELEASED, (e) -> {
            isEmpty();
        });
        
        //Eventos de los botones
        btnAdd.addEventHandler(MouseEvent.MOUSE_CLICKED, (e) -> {
            txtIdDetalle.clear();
            boolean flag = DBDetalleCompra.insertDetalleCompra(getDetalleCompra());
            dataBaseAction(
                    flag, 
                    "No se logró insertar el registro", 
                    "Huvo un problema con la inserción del registro."
            );
        });
        
        btnEdit.addEventHandler(MouseEvent.MOUSE_CLICKED, (e) -> {
            boolean flag = DBDetalleCompra.updateDetalleCompra(getDetalleCompra());
            dataBaseAction(
                    flag, 
                    "No se logró actualizar el registro", 
                    "Huvo un problema con la actualización del registro."
            );
        });
        
        btnDelete.addEventHandler(MouseEvent.MOUSE_CLICKED, (e) -> {
            boolean flag = DBDetalleCompra.deleteDetalleCompra(getDetalleCompra());
            dataBaseAction(
                    flag, 
                    "No se logró eliminar el registro", 
                    "Huvo un problema con la eliminación del registro."
            );
        });
        
        btnRecharge.addEventHandler(MouseEvent.MOUSE_CLICKED, (e) -> {
            setDisable(true);
        });
        
        setEditFields(true);
        btnAdd.setDisable(true);
        txtIdCompra.setText(compra.getIdCompra() + "");
    }    

    private void dataBaseAction(boolean flag, String title, String msg) {
        if (flag) {
            setDisable(true);
            setEditFields(false);
            tableView.setItems(dataTable());
            clearForm(true);
        }else{
            JFXOptionPane.showMessageDialog(
                    title, msg, JFXOptionPane.MessageType.ERROR
            );
        }
    }

    @Override
    public List<String> tableHeaders() {
        return Arrays.asList(
                "idDetalle","compra", "material", "tipoMaterial", "unidadMedida",
                "cantidad", "monto"
        );
    }

    @Override
    public ObservableList<DetalleCompra> dataTable() {
        return DBDetalleCompra.loadDetalleCompra(compra);
    }
    
    @Override
    public void handle(Event event){
        int index = tableView.getSelectionModel().getSelectedIndex();
        if (index > -1) {
            DetalleCompra de = tableView.getSelectionModel().getSelectedItem();
            setDetalle(de);
            setDisable(false);
            setEditFields(true);
            btnAdd.setDisable(true);
        }
    }
    
    private void setDetalle(DetalleCompra de){
        txtIdDetalle.setText(de.getIdDetalle() + "");
        txtIdCompra.setText(de.getCompra().toString());
        cbCantidad.setText(de.getCantidad() + "");
        for(InventarioMateriales m : cbMaterial.getItems()){
            if(m.getMaterial().getNombre().equals(de.getMaterial().getNombre())){
                cbMaterial.getSelectionModel().select(m);
                break;
            }
        }
    }
    
    private void setDisable(boolean flag){
        btnDelete.setDisable(flag);
        btnEdit.setDisable(flag);
        btnAdd.setDisable(flag);
    }
    
    private void setEditFields(boolean flag){
        cbCantidad.setEditable(flag);
    }
    
    private void clearForm(boolean clearIdCompra){
        if (clearIdCompra) txtIdDetalle.clear();
        cbCantidad.setText("0.0");
        cbMaterial.getSelectionModel().clearSelection();
    }
    
    private void isEmpty(){
        if (
                (cbCantidad.getText().isEmpty() || 
                cbMaterial.getSelectionModel().getSelectedIndex() < 0) &&
                !btnEdit.isDisabled()) {
            btnAdd.setDisable(true);
        }else{
            btnAdd.setDisable(false);
        }
    }
    
    private DetalleCompra getDetalleCompra(){
        Compra c = new Compra();
        c.setIdCompra(Integer.parseInt(txtIdCompra.getText()));
        
        InventarioMateriales m = null;
        
        for(InventarioMateriales mat : cbMaterial.getItems()){
            if (mat.getMaterial().getNombre().equals(cbMaterial.getSelectionModel().getSelectedItem().getMaterial().getNombre())) {
                m = mat;break;
            }
        }
        
        DetalleCompra dc = new DetalleCompra(c, m.getMaterial());
        if(!txtIdDetalle.getText().isEmpty()) 
            dc.setIdDetalle(Integer.parseInt(txtIdDetalle.getText()));
        dc.setCantidad(Float.parseFloat(cbCantidad.getText()));
        return dc;
    }
}
