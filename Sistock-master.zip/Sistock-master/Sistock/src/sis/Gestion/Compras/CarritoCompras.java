/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sis.Gestion.Compras;

import Constructores.DetalleCompra;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

/**
 *
 * @author josue
 */
public class CarritoCompras {
    public static ObservableList<DetalleCompra> compra = FXCollections.observableArrayList();
}
