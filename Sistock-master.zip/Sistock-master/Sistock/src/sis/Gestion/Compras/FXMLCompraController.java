/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sis.Gestion.Compras;

import Constructores.Compra;
import Constructores.DetalleCompra;
import Util.JFXOptionPane;
import static Util.JFXOptionPane.stage;
import Util.Tabla;
import com.jfoenix.controls.JFXButton;
import java.io.IOException;
import java.net.URL;
import java.util.Arrays;
import java.util.List;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.collections.ObservableList;
import javafx.event.Event;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.stage.Modality;
import javafx.stage.Stage;
import produccion3.DBCompra;

/**
 * FXML Controller class
 *
 * @author josue
 */
public class FXMLCompraController extends Tabla<Compra> implements Initializable {

    @FXML
    private HBox pnTable;
    @FXML
    private JFXButton btnAdd;
    @FXML
    private JFXButton btnEdit;
    @FXML
    private JFXButton btnRecharge;

    public static Stage stage;
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        initTable(pnTable);
        
        btnAdd.addEventHandler(MouseEvent.MOUSE_CLICKED, (e) -> {
            showWindows("/sis/Compras/FXMLCompraMateriales.fxml");
        });
        
        btnRecharge.addEventHandler(MouseEvent.MOUSE_CLICKED, (e) -> {
            DBCompra.loadCompras();
        });
    }    

    @Override
    public List tableHeaders() {
        return Arrays.asList(
            "idCompra",
            "proveedor",
            "fechaCompra",
            "monto"
        );
    }

    @Override
    public ObservableList<Compra> dataTable() {
        return DBCompra.loadCompras();
    }
    
    private int idNow, idOld;
    
    @Override
    public void handle(Event evetn){
        int row = tableView.getSelectionModel().getSelectedIndex();
        if (row > -1) {
            Compra c = tableView.getSelectionModel().getSelectedItem();
            if (idNow == 0) {
                idNow = c.getIdCompra();
            }else{
                idOld = idNow; 
                idNow = c.getIdCompra();
            }
            if (idNow == idOld) {
                showDetail(c);
            }
        }
        
    }
    
    private void showDetail(Compra curr){
        FXMLDetalleCompraController.compra = curr;
        showWindows("/sis/Compras/FXMLDetalleCompra.fxml");
    }
    
    private void showWindows(String src){
        try {
            Pane pane = FXMLLoader.load(getClass().getResource(src));
            Scene scene = new Scene(pane);
            stage = new Stage();
            stage.setMinHeight(500);
            stage.setMinWidth(1100);
            stage.setScene(scene);
            stage.initModality(Modality.APPLICATION_MODAL);
            stage.showAndWait();
            stage.centerOnScreen();
        } catch (IOException ex) {
            Logger.getLogger(FXMLCompraController.class.getName()).log(Level.SEVERE, null, ex);
        }    
    }
}
