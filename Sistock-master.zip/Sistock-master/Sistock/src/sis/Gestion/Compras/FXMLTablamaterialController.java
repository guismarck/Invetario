/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sis.Gestion.Compras;

import Conexion.conexionbd;
import Constructores.Config;
import Constructores.ContInventarioM;
import Constructores.Contrabajador;
import Constructores.Usuario;
import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;
import javax.swing.JOptionPane;

/**
 * FXML Controller class
 *
 * @author nesto
 */
public class FXMLTablamaterialController implements Initializable {

    private ObservableList<ContInventarioM> dato;
    private Connection con = null;
    private PreparedStatement pst = null;
    private ResultSet rs = null;

    @FXML
    private TableView<ContInventarioM> TablainventarioM;
    @FXML
    private TableColumn<?, ?> clmidinventarioM;
    @FXML
    private TableColumn<?, ?> clmidproveedor;
    @FXML
    private TableColumn<?, ?> clmproveedor;
    @FXML
    private TableColumn<?, ?> clmidmaterial;
    @FXML
    private TableColumn<?, ?> clmmaterial;
    @FXML
    private TableColumn<?, ?> clmdescripcion;
    @FXML
    private TableColumn<?, ?> clmestado;
    @FXML
    private TableColumn<?, ?> clminicial;
    @FXML
    private TableColumn<?, ?> clmactual;
    @FXML
    private TableColumn<?, ?> clmmedida;
    @FXML
    private TableColumn<?, ?> clmprecio;
    @FXML
    private TableColumn<?, ?> clmfecha;
    @FXML
    private TableColumn<?, ?> clmfoto;
    @FXML
    private TableColumn<?, ?> clmcodigo;
    @FXML
    private TableColumn<?, ?> clmtipo;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        Config.setUser(new Usuario("Eduardo23", "1234"));
        conexionbd.conectar(
                Config.getUser().getName(),
                Config.getUser().getPasString());

        dato = FXCollections.observableArrayList();
        con = conexionbd.getSql();
        setCellTable();
        loadDatetable();

    }

    private void setCellTable() {

        clmidinventarioM.setCellValueFactory(new PropertyValueFactory<>("Idinventario"));
        clmidproveedor.setCellValueFactory(new PropertyValueFactory<>("Idproveedor"));
        clmproveedor.setCellValueFactory(new PropertyValueFactory<>("Proveedor"));
        clmidmaterial.setCellValueFactory(new PropertyValueFactory<>("Idmaterial"));
        clmcodigo.setCellValueFactory(new PropertyValueFactory<>("codigo"));
        clmmaterial.setCellValueFactory(new PropertyValueFactory<>("material"));
        clmtipo.setCellValueFactory(new PropertyValueFactory<>("tipo"));
        clmdescripcion.setCellValueFactory(new PropertyValueFactory<>("descripcion"));
        clmestado.setCellValueFactory(new PropertyValueFactory<>("estado"));
        clmfecha.setCellValueFactory(new PropertyValueFactory<>("date"));
        clminicial.setCellValueFactory(new PropertyValueFactory<>("stockinical"));
        clmactual.setCellValueFactory(new PropertyValueFactory<>("stockactual"));
        clmmedida.setCellValueFactory(new PropertyValueFactory<>("unidadmedida"));
        clmprecio.setCellValueFactory(new PropertyValueFactory<>("Precio"));

    }

    private void loadDatetable() {

        dato.clear();

        try {

            pst = con.prepareStatement("select inm.IdInventario, inm.IdProveedor, p.Nombre,"
                    + " inm.IdMateriales, mt.Codigo,mt.Nombre, mt.Descripcion,mt.Tipo, mt.Estado,"
                    + " inm.Fecha_vencimiento, inm.StocK_inicial, inm.Stock_actual, "
                    + " inm.Unidad_medida, inm.Precio from Inventario_materiales inm inner join"
                    + " Proveedor p on inm.IdProveedor=p.IdProveedor inner join Materiales mt"
                    + " on inm.IdMateriales = mt.IdMateriales");

            rs = pst.executeQuery();

            while (rs.next()) {
                dato.add(new ContInventarioM(rs.getInt(1), rs.getInt(2), rs.getString(3), rs.getInt(4),
                        rs.getString(5), rs.getString(6), rs.getString(7), rs.getString(8), rs.getString(9), rs.getDate(10),
                        rs.getDouble(11), rs.getDouble(12), rs.getString(13), rs.getDouble(14)));
            }

            TablainventarioM.setItems(dato);
        } catch (SQLException ex) {

            JOptionPane.showMessageDialog(null, ex);
        }
    }

//    private void tablatexfiel() {
//
//        TablainventarioM.setOnMouseClicked((MouseEvent event) -> {
//            try {
//
//                if (event.getClickCount() == 2) {
//                    ContInventarioM dtt = TablainventarioM.getItems().get(TablainventarioM.getSelectionModel().getSelectedIndex());
////                  mtcnt.txtiddetalle.setText(String.valueOf(dtt.getIdmaterial()));
//                    mtcnt.txtnombre.setText(dtt.getMaterial());
////                    mtcnt.txtinical.setText(String.valueOf(dt.getStockactual()));
////                    mtcnt.txtactual.setText(String.valueOf(dt.getStockactual()));
////                    mtcnt.cbmedida.setPromptText(dt.getUnidadmedida());
////                    mtcnt.txtprecio.setText(String.valueOf(dt.getPrecio()));
//                    Parent root = null;
//                    root = FXMLLoader.load(FXMLTablamaterialController.this.getClass().getResource("/Interfaces/FXMLMateriales.fxml"));
//                    Stage stage = new Stage();
//                    Scene scene = new Scene(root);
//                    stage.setScene(scene);
//                    stage.show();
//                }
//            } catch (IOException e) {
//                JOptionPane.showMessageDialog(null, e);
//            }
//        });
//    }
    @FXML
    private void passar(MouseEvent event) throws IOException {

        int id;
        String iddetalle, idmateria, provedor, codigo, nombre,
                descripcion, tipo, estado, inical, actual, unidad, precio;
        LocalDate fecha;
        Date f;

        try {

            if (event.getClickCount() == 2) {
//                ContInventarioM dtt = TablainventarioM.getItems().get(TablainventarioM.getSelectionModel().getSelectedIndex());
//                  mtcnt.txtiddetalle.setText(String.valueOf(dtt.getIdmaterial()));
//                FXMLMaterialesController.txtnombre.setText(dtt.getMaterial());
//                    mtcnt.txtinical.setText(String.valueOf(dt.getStockactual()));
//                    mtcnt.txtactual.setText(String.valueOf(dt.getStockactual()));
//                    mtcnt.cbmedida.setPromptText(dt.getUnidadmedida());
//                    mtcnt.txtprecio.setText(String.valueOf(dt.getPrecio()));
//                Parent root = null;
//                root = FXMLLoader.load(FXMLTablamaterialController.this.getClass().getResource("/Interfaces/FXMLMateriales.fxml"));
//                Stage stage = new Stage();
//                Scene scene = new Scene(root);
//                stage.setScene(scene);
//                stage.show();

                FXMLLoader loader = new FXMLLoader(getClass().getResource("/Compras/FXMLMateriales.fxml"));
                Parent p = (Parent) loader.load();

                FXMLMaterialesController fxmlpasarcontrollerin = loader.getController();

                ContInventarioM dtt = TablainventarioM.getItems().get(TablainventarioM.getSelectionModel().getSelectedIndex());

                iddetalle = String.valueOf(dtt.getIdinventario());

                idmateria = String.valueOf(dtt.getIdmaterial());
                id = dtt.getIdmaterial();
                provedor = dtt.getProveedor();
                codigo = dtt.getCodigo();
                nombre = dtt.getMaterial();
                descripcion = dtt.getDescripcion();
                tipo = dtt.getTipo();

                f = dtt.getDate();
                fecha = f.toLocalDate();

                estado = dtt.getEstado();

                inical = String.valueOf(dtt.getStockinical());
                actual = String.valueOf(dtt.getStockactual());
                unidad = dtt.getUnidadmedida();
                precio = String.valueOf(dtt.getPrecio());

                fxmlpasarcontrollerin.llenardatos(iddetalle, provedor, idmateria, codigo,
                        nombre, descripcion, tipo, estado, fecha, inical, actual, unidad, precio);

                Stage stage = new Stage();
                stage.setScene(new Scene(p));
                stage.show();
            }
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, e);
        } catch (SQLException ex) {
            Logger.getLogger(FXMLTablamaterialController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

}
