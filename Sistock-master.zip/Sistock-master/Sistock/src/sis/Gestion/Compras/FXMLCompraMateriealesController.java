/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sis.Gestion.Compras;

import Constructores.Compra;
import Constructores.DetalleCompra;
import Constructores.InventarioMateriales;
import Constructores.Material;
import Constructores.Proveedor;
import Util.JFXOptionPane;
import Util.Tabla;
import Util.Validacion;
import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXCheckBox;
import com.jfoenix.controls.JFXComboBox;
import com.jfoenix.controls.JFXDatePicker;
import com.jfoenix.controls.JFXTextField;
import java.net.URL;
import java.sql.Date;
import java.time.LocalDate;
import java.util.Arrays;
import java.util.List;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.HBox;
import javafx.scene.paint.Paint;
import modelView.CompraMaterialView;
import produccion3.DBCompra;
import produccion3.DBDetalleCompra;
import produccion3.DBProveedor;
import produccion3.DInventario_Materiales;

/**
 * FXML Controller class
 *
 * @author josue
 */
public class FXMLCompraMateriealesController extends Tabla<CompraMaterialView> implements Initializable {

    @FXML
    private HBox pnTable;
    @FXML
    private JFXButton btnHecho;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {

        //Inicializa la tabla 
        initTable(pnTable);

        //Se cargan los datos a la tabla
        //El idProveedor=0 siginifca que la consulta mostrara todos los productos de todos los proveedores
        //Y el null es simple mente para satisfacer al constructor ya que este recibe como mínimo 2 parametros.
        tableView.setItems(load(new Proveedor(0, null)));

        //Evento de boton
        btnHecho.addEventHandler(MouseEvent.MOUSE_CLICKED, (e) -> {
            boolean flag = isHecho();
            if (!flag) {
                int opc = JFXOptionPane.showMessageDialog(
                        "Desea continuar sin algunos productos?",
                        "Seguro que desea continuar sin añadir todos los\nproductos seleccionados?",
                        JFXOptionPane.MessageType.INFO);
                if (opc == 1) {
                    flag = insertar();
                    if (flag) {
                        JFXOptionPane.showMessageDialog(
                                "Compra realizada",
                                "Se ha gestionado la operación correctamente.",
                                JFXOptionPane.MessageType.OK);
                        closeThis();
                    } else {
                        JFXOptionPane.showMessageDialog(
                                "Carrito Vacio",
                                "No ha llenado todos los campos correspondoentes a los materiales.",
                                JFXOptionPane.MessageType.INFO);
                    }
                }
            } else {
                flag = insertar();
                if (flag) {
                    JFXOptionPane.showMessageDialog(
                            "Compra realizada",
                            "Se ha gestionado la operación correctamente.",
                            JFXOptionPane.MessageType.OK);
                    closeThis();
                }
            }
        });
    }

    private void closeThis() {
        try {
            this.finalize();
            FXMLCompraController.stage.close();
        } catch (Throwable ex) {
            Logger.getLogger(FXMLCompraMateriealesController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @Override
    public List<String> tableHeaders() {
        return Arrays.asList(
                "Check", "material", "proveedor", "vence", "cantidad", "precio"
        );
    }

    @Override
    public ObservableList<CompraMaterialView> dataTable() {
//        return load(cbProvedores.getSelectionModel().getSelectedItem());
        return null;
    }

    @Override
    public void handle(Event event) {
        int row = tableView.getSelectionModel().getSelectedIndex();
        if (row > -1) {
            JFXCheckBox check = tableView.getSelectionModel().getSelectedItem().getCheck();
            if (check.isSelected()) {
                btnHecho.setDisable(false);
            }
        }
    }

    private boolean insertar() {
        boolean flag = false;
        if (CarritoCompras.compra.size() > 0) {
            LocalDate localDate = LocalDate.now();
            int day = localDate.getDayOfMonth();
            int month = localDate.getMonth().getValue() - 1;
            int year = (month == 12) ? localDate.getYear() - 1901 : localDate.getYear() - 1900;
//            Proveedor p = cbProvedores.getSelectionModel().getSelectedItem();
            Proveedor p = null;

            Compra c = new Compra(p, new Date(year, month, day));
            flag = DBCompra.insertCompra(c);

            if (flag) {
                c = DBCompra.loadLastCompra();
                for (DetalleCompra detalle : CarritoCompras.compra) {
                    detalle.setCompra(c);
                    boolean flag2 = DBDetalleCompra.insertDetalleCompra(detalle);
                    flag = (flag2) ? flag : flag2;
                }
            }
        }
        return flag;
    }

    private ObservableList<CompraMaterialView> load(Proveedor p) {
        ObservableList<InventarioMateriales> mat = DInventario_Materiales.loadInventarioMateriales(p);//Materiales de la base de datos
        ObservableList<CompraMaterialView> list = FXCollections.observableArrayList();//Lista que almacenará los datos de la tableview

        for (InventarioMateriales inv : mat) {
            list.add(generateAMaterialView(inv));
        }
        return list;
    }

    private CompraMaterialView generateAMaterialView(InventarioMateriales inv) {
        Paint paint = Paint.valueOf("#3498DB");
        Paint paint2 = Paint.valueOf("#FFF");

        JFXCheckBox check1 = new JFXCheckBox();
        check1.setCheckedColor(paint);
        check1.addEventHandler(MouseEvent.MOUSE_CLICKED, (e) -> {
            if (check1.isSelected()) {
                btnHecho.setDisable(false);
            } else {
                boolean flag = false;
                for (CompraMaterialView object : tableView.getItems()) {
                    if (object.getCheck().isSelected()) {
                        flag = true;
                    }
                }
                btnHecho.setDisable(!flag);
            }
        });

        JFXDatePicker date = new JFXDatePicker();
        date.setDefaultColor(paint2);
        date.setPrefWidth(130);
        date.setValue(LocalDate.now());

        JFXTextField txtCant = new JFXTextField("0.0");
        txtCant.setFocusColor(paint);
        Validacion.ValidacionNumérica(txtCant);

        JFXTextField txtPrice = new JFXTextField("0.0");
        txtPrice.setFocusColor(paint);
        Validacion.ValidacionNumérica(txtPrice);

        return new CompraMaterialView(check1, inv.getMaterial(), inv.getProveedor(), date, txtCant, txtPrice);
    }

    private boolean isHecho() {
        boolean flag = false;
        CarritoCompras.compra.clear();
        String msg = "No se agregarón los articulos: \n";

        for (CompraMaterialView obj : tableView.getItems()) {
            if (obj.getCheck().isSelected()) {
                float can = Float.parseFloat(obj.getCantidad().getText());
                float price = Float.parseFloat(obj.getPrecio().getText());

                if (can == 0.0 || price == 0.0) {
                    msg += obj.getMaterial().getNombre() + ", ";
                } else {
                    Material mat = obj.getMaterial();
                    DetalleCompra detalle = new DetalleCompra();
                    detalle.setMaterial(mat);
                    detalle.setCantidad(can);
                    detalle.setMonto(can);
                    CarritoCompras.compra.add(detalle);
                }
            }
        }

        if (!msg.equals("No se agregarón los articulos: \n")) {
            JFXOptionPane.showMessageDialog("No se agregarón algunos productos porque faltan campos",
                    msg,
                    JFXOptionPane.MessageType.INFO);
        } else {
            flag = true;
        }
        return flag;
    }
}
