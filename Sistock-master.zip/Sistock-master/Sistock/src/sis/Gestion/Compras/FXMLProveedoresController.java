/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sis.Gestion.Compras;

import Constructores.Proveedor;
import Util.JFXOptionPane;
import Util.JFXOptionPaneController;
import Util.Tabla;
import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXTextField;
import java.net.URL;
import java.util.Arrays;
import java.util.List;
import java.util.ResourceBundle;
import javafx.collections.ObservableList;
import javafx.event.Event;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.layout.HBox;
import produccion3.DBProveedor;

/**
 * FXML Controller class
 *
 * @author josue
 */
public class FXMLProveedoresController extends Tabla<Proveedor> implements Initializable {

    @FXML
    private HBox pnTable;
    @FXML
    private JFXTextField txtNombre, txtDireccion, txtCorreo, txtTelefono;
    @FXML
    private JFXButton btnAdd, btnEdit, btnDelete, btnRecharge;

    public static Proveedor currentObject;
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        initTable(pnTable);
        initButtonEvent();
        
    }   
    
    @Override
    public List<String> tableHeaders() {
        return Arrays.asList("idProveedor", "nombre", "direccion","correo",
                "telefono");
    }

    @Override
    public ObservableList<Proveedor> dataTable() {
        return DBProveedor.loadProveedores();
    }
    
    //Evento de click de la tabla
    @Override
    public void handle(Event event) {
        Proveedor p = tableView.getSelectionModel().getSelectedItem();
        setProveedor(p);
        currentObject = p;
        disableElements(false);
    }
    
    private void initButtonEvent(){
        btnAdd.setOnMouseClicked((Event event) -> {
            Proveedor p = getProveedor();
            if (p != null) {
                DBProveedor.insertProveedor(p);
                tableView.setItems(DBProveedor.loadProveedores());
                clean();
            }else{
                JFXOptionPane.showMessageDialog("Campos vacios", 
                        "No se han llenado todos los campos", 
                        Util.JFXOptionPane.MessageType.INFO);
            }
        });
        
        btnEdit.setOnMouseClicked((Event event) -> {
            Proveedor p = tableView.getSelectionModel().getSelectedItem();
            Proveedor pNew = getProveedor();
            
            if (pNew != null) {
                pNew.setIdProveedor(p.getIdProveedor());
                boolean flag = DBProveedor.updateProveedor(pNew);
                if(flag) {
                    tableView.setItems(DBProveedor.loadProveedores());
                    clean();
                }
            }
        });
        
        btnDelete.setOnMouseClicked((Event event) -> {
                JFXOptionPaneController.tabla = JFXOptionPaneController.Eliminar_Tabla.Proveedor;
                JFXOptionPane.showMessageDialog(
                        "Desea eliminar a este proveedor", 
                        "Seguro desea eliminar este registro."
                        + "\nPuede que otros datos dependa de este.", 
                        JFXOptionPane.MessageType.INFO);
                clean();
        });
        
        btnRecharge.setOnMouseClicked((Event event) -> {
            tableView.setItems(DBProveedor.loadProveedores());
            clean();
        });
    }
    
    private Proveedor getProveedor(){
        Proveedor p = null;
        String nom, dir, cor, tel;
        nom = txtNombre.getText();
        dir = txtDireccion.getText();
        cor = txtCorreo.getText();
        tel = txtTelefono.getText();
        if (validate()) {
            p = new Proveedor(nom, dir, cor, tel);
        }else{
            JFXOptionPane.showMessageDialog("Campos invalidos", 
                    "Aún hay campos vacios", 
                    JFXOptionPane.MessageType.INFO);
        }
        return p;
    }
    
    private void setProveedor(Proveedor p){
        txtNombre.setText(p.getNombre());
        txtDireccion.setText(p.getDireccion());
        txtCorreo.setText(p.getCorreo());
        txtTelefono.setText(p.getTelefono());
    }
    
    private void disableElements(boolean isDisabled){
        btnDelete.setDisable(isDisabled);
        btnEdit.setDisable(isDisabled);
    }
    
    private void clean(){
        txtNombre.setText("");
        txtDireccion.setText("");
        txtCorreo.setText("");
        txtTelefono.setText("");
        disableElements(true);
    }
    
    private boolean validate(){
        return (!txtNombre.getText().isEmpty() 
                || !txtDireccion.getText().isEmpty()
                || !txtCorreo.getText().isEmpty()
                || !txtCorreo.getText().isEmpty());
        
    }
}