/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Interfaces;

import Conexion.conexionbd;
import Constructores.ContDttvt;
import Constructores.Contproducto;
import Constructores.Contventa;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javax.swing.JOptionPane;

/**
 * FXML Controller class
 *
 * @author nesto
 */
public class FXMLVentaController implements Initializable {

    private ObservableList<Contventa> dato;

    private PreparedStatement pst = null;
    private ResultSet rs = null;

    private PreparedStatement pst2 = null;
    private ResultSet rs2 = null;

    @FXML
    private TableView<Contventa> tableventa;
    @FXML
    private TableColumn<?, ?> clmIdDtt;
    @FXML
    private TableColumn<?, ?> clmIdVt;
    @FXML
    private TableColumn<?, ?> clmIdPd;
    @FXML
    private TableColumn<?, ?> clmProducto;
    @FXML
    private TableColumn<?, ?> clmCantidad;
    @FXML
    private TableColumn<?, ?> clmPrecio;
    @FXML
    private TextField txtempleado;
    @FXML
    private TextField txtidempleado;
    @FXML
    private TextField txtidproducto;
    @FXML
    private TextField txtproducto;
    @FXML
    private TextField txtprecio;
    @FXML
    private TextField txtcantidad;
    @FXML
    private Button btnbuscar;
    @FXML
    private DatePicker dtpicker;
    @FXML
    private Button btnguardar;
    @FXML
    private Button btneditar;
    @FXML
    private Button btneliminar;
    @FXML
    private Button btndetalle;
    private TextField idventa;
    @FXML
    private TextField txtiddtt;
    @FXML
    private TextField txtidventa;

    public static Contproducto currentProducto = null;
    public static ContDttvt currentDetalleVt = null;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        try {
            txtidventa.setText("0");

            dato = FXCollections.observableArrayList();
            tablatexfiel();
            setCellTable();

        } catch (Exception ex) {
            Logger.getLogger(FXMLVentaController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @FXML
    private void actionguardar(ActionEvent event) throws SQLException {

        int idvt = Integer.parseInt(txtidventa.getText());

        if (idvt == 0) {

            String sql = "insert into Venta(Idempleado, Fecha)\n"
                    + "values (?,?)";

            int idE = Integer.parseInt(txtidempleado.getText());

            java.sql.Date Picker = java.sql.Date.valueOf(dtpicker.getValue());

            int idP = Integer.parseInt(txtidproducto.getText());

            int cantidad = Integer.parseInt(txtcantidad.getText());

            try {

                pst = conexionbd.getSql().prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
                pst.setInt(1, idE);
                pst.setDate(2, Picker);

                int i = pst.executeUpdate();
                rs = pst.getGeneratedKeys();
                rs.next();

                Object key = rs.getObject(1);

                String sql2 = "insert into DetalleVenta(Idventa,IdInventario,Cantidad)\n"
                        + "values (?,?,?)";
                pst2 = conexionbd.getSql().prepareStatement(sql2);
                pst2.setInt(1, Integer.parseInt(String.valueOf(key)));
                pst2.setInt(2, idP);
                pst2.setInt(3, cantidad);

                int j = pst2.executeUpdate();
                if (i == 1 && j == 1) {

                    txtidventa.setText(String.valueOf(key));
                    JOptionPane.showMessageDialog(null, "Datos insertados correctamente");
                    loadDatetable(Integer.parseInt(String.valueOf(key)));
                }

            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(null, ex);
            } finally {
                pst.close();
                pst2.close();
            }

        } else {

            int idV = Integer.parseInt(txtidventa.getText());

            int idP = Integer.parseInt(txtidproducto.getText());

            int cantidad = Integer.parseInt(txtcantidad.getText());

            try {

                String sql2 = "insert into DetalleVenta(Idventa,IdInventario,Cantidad)\n"
                        + "values (?,?,?)";
                pst2 = conexionbd.getSql().prepareStatement(sql2);
                pst2.setInt(1, idV);
                pst2.setInt(2, idP);
                pst2.setInt(3, cantidad);

                int j = pst2.executeUpdate();
                if (j == 1) {

                    JOptionPane.showMessageDialog(null, "Datos insertados correctamente");
                    loadDatetable(idV);
                }

            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(null, ex);
            } finally {
                pst2.close();
            }

        }

    }

    @FXML
    private void actioneditar(ActionEvent event) throws SQLException {

        int idvt = Integer.parseInt(txtidventa.getText());

        if (idvt == 0) {

            JOptionPane.showMessageDialog(null, "Debe editar una venta valida");

        } else {

            int idvtll = Integer.parseInt(txtiddtt.getText());

            int idV = Integer.parseInt(txtidventa.getText());

            int idP = Integer.parseInt(txtidproducto.getText());

            int cantidad = Integer.parseInt(txtcantidad.getText());

            try {

                String sql2 = "update DetalleVenta set IdInventario=?,Cantidad=? where IdDetalleventa =?";
                pst2 = conexionbd.getSql().prepareStatement(sql2);
                pst2.setInt(1, idP);
                pst2.setInt(2, cantidad);
                pst2.setInt(3, idvtll);

                int j = pst2.executeUpdate();
                if (j == 1) {

                    JOptionPane.showMessageDialog(null, "Datos editados correctamente");
                    loadDatetable(idV);
                }

            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(null, ex);
            } finally {
                pst2.close();
            }

        }
    }

    @FXML
    private void actioneliminar(ActionEvent event) {

        txtidventa.clear();
        txtiddtt.clear();
        txtidproducto.clear();
        txtproducto.clear();
        txtcantidad.clear();
        txtprecio.clear();
        dato.clear();

    }

    @FXML
    private void actiondellate(ActionEvent event) throws IOException {

        FXMLLoader loader = new FXMLLoader(getClass().getResource("/Interfaces/FXMLDetalleventa.fxml"));
        Parent p = (Parent) loader.load();

        FXMLDetalleventaController productoController = loader.getController();;

        Stage stage = new Stage();
        Scene scene = new Scene(p);
        stage.setScene(scene);
        stage.show();

    }

    private void setCellTable() {

        clmIdDtt.setCellValueFactory(new PropertyValueFactory<>("IdDtt"));
        clmIdVt.setCellValueFactory(new PropertyValueFactory<>("IdVt"));
        clmIdPd.setCellValueFactory(new PropertyValueFactory<>("IdProducto"));
        clmProducto.setCellValueFactory(new PropertyValueFactory<>("Producto"));
        clmCantidad.setCellValueFactory(new PropertyValueFactory<>("Cantidad"));
        clmPrecio.setCellValueFactory(new PropertyValueFactory<>("Precio"));
    }

    public void Recibir(String id, LocalDate fecha) throws SQLException {

        txtidventa.setText(id);
        dtpicker.setValue(fecha);

        int idd = Integer.parseInt(id);

        loadDatetable(idd);
    }

    private void loadDatetable(int id) {

        dato.clear();

        try {

            pst = conexionbd.getSql().prepareStatement("select dt.IdDetalleventa,dt.idventa, pr.Idproducto , pr.Nombre, dt.Cantidad,inp.Precio from \n"
                    + "DetalleVenta dt inner join Venta vt on dt.Idventa=vt.Idventa inner join Empleado em \n"
                    + "on vt.Idempleado = em.Idempleado inner join Inventario_productos inp on dt.IdInventario = inp.Idproducto"
                    + " inner join Producto pr on inp.IdProducto = pr.IdProducto \n"
                    + "where dt.Idventa= " + id + "and em.Idempleado =1");

            rs = pst.executeQuery();

            while (rs.next()) {
                dato.add(new Contventa(rs.getInt(1), rs.getInt(2), rs.getInt(3), rs.getString(4), rs.getInt(5), rs.getDouble(6)));
            }

            tableventa.setItems(dato);
        } catch (SQLException ex) {

            JOptionPane.showMessageDialog(null, ex);
        }
    }

    public void recibirproducto(int id, String nombre, double precio) {

        String idp = String.valueOf(id);
        String preciop = String.valueOf(precio);

        txtidproducto.setText(idp);
        txtproducto.setText(nombre);
        txtprecio.setText(preciop);

    }

    @FXML
    private void actionbuscarproducto(ActionEvent event) {

        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/Interfaces/FXMLproducto.fxml"));
            Parent p = (Parent) loader.load();

            FXMLproductoController productoController = loader.getController();

            productoController.indentificar("1");

            Stage stage = new Stage();
            stage.setScene(new Scene(p));
            stage.initModality(Modality.APPLICATION_MODAL);
            stage.showAndWait();
            
            txtidproducto.setText(currentProducto.getIdproducto()+"");
            txtproducto.setText(currentProducto.getNombre());
            txtprecio.setText(currentProducto.getPrecio()+"");

        } catch (IOException ex) {
            Logger.getLogger(FXMLVentaController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    private void tablatexfiel() {

        tableventa.setOnMouseClicked(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent event) {

                Contventa dt = tableventa.getItems().get(tableventa.getSelectionModel().getSelectedIndex());
                txtiddtt.setText(String.valueOf(dt.getIdDtt()));
                txtidventa.setText(String.valueOf(dt.getIdVt()));
                txtidproducto.setText(String.valueOf(dt.getIdProducto()));
                txtproducto.setText(dt.getProducto());
                txtprecio.setText(String.valueOf(dt.getPrecio()));
                txtcantidad.setText(String.valueOf(dt.getCantidad()));
            }
        });
    }

}
