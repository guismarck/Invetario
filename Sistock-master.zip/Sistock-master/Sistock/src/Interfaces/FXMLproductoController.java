/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Interfaces;

import Constructores.Contproducto;
import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;
import javax.swing.JOptionPane;
import Inventario_Optiomo.FXMLMRPL4LController;
import Inventario_Optiomo.FXMLModeloPController;
/**
 * FXML Controller class
 *
 * @author nesto
 */
public class FXMLproductoController implements Initializable {

    private ObservableList<Contproducto> dato;
    private Connection con = null;
    private PreparedStatement pst = null;
    private ResultSet rs = null;

    @FXML
    private TableView<Contproducto> tableproducto;
    @FXML
    private TableColumn<?, ?> clmidinv;
    @FXML
    private TableColumn<?, ?> clmidp;
    @FXML
    private TableColumn<?, ?> clmcodigo;
    @FXML
    private TableColumn<?, ?> clmproducto;
    @FXML
    private TableColumn<?, ?> clmfecha;
    @FXML
    private TableColumn<?, ?> clmstocki;
    @FXML
    private TableColumn<?, ?> clmstocka;
    @FXML
    private TableColumn<?, ?> clmprecio;
    @FXML
    private TextField txtidentificar;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {

        try {
            con = Conexion.conexionbd.conectar("Eduardo23", "1234");
            dato = FXCollections.observableArrayList();
            setCellTable();
            loadDatetable();
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, ex);
        }
    }

    private void setCellTable() {

        clmidinv.setCellValueFactory(new PropertyValueFactory<>("Idinventario"));
        clmidp.setCellValueFactory(new PropertyValueFactory<>("Idproducto"));
        clmcodigo.setCellValueFactory(new PropertyValueFactory<>("codigo"));
        clmproducto.setCellValueFactory(new PropertyValueFactory<>("Nombre"));
        clmfecha.setCellValueFactory(new PropertyValueFactory<>("Fecha"));
        clmstocki.setCellValueFactory(new PropertyValueFactory<>("StockI"));
        clmstocka.setCellValueFactory(new PropertyValueFactory<>("StockA"));
        clmprecio.setCellValueFactory(new PropertyValueFactory<>("Precio"));
    }

    private void loadDatetable() {

        dato.clear();

        try {

            pst = con.prepareStatement("select inv.IdInventario, pr.Idproducto, pr.Codigo, pr.Nombre,inv.Fecha_vencimiento,\n"
                    + "inv.StocK_inicial,inv.Stock_actual, inv.Precio \n"
                    + "from Inventario_productos inv inner join Producto pr\n"
                    + "on inv.IdProducto = pr.Idproducto ");

            rs = pst.executeQuery();

            while (rs.next()) {
                dato.add(new Contproducto(rs.getInt(1), rs.getInt(2), rs.getString(3), rs.getString(4),
                        rs.getDate(5), rs.getDouble(6), rs.getDouble(7), rs.getDouble(8)));
            }

            tableproducto.setItems(dato);
        } catch (SQLException ex) {

            JOptionPane.showMessageDialog(null, ex);
        }
    }

    @FXML
    private void Pasardatos(MouseEvent event) {

        int id;
        String producto;
        Double inventario;
        Double precio;

        int comparar = Integer.parseInt(txtidentificar.getText());

        try {

            if (event.getClickCount() == 2) {

                if (comparar == 1) {

                    FXMLLoader loader = new FXMLLoader(getClass().getResource("/Interfaces/FXMLVenta.fxml"));
                    Parent p = (Parent) loader.load();

                    FXMLVentaController VController = loader.getController();

                    Contproducto dtt = tableproducto.getItems().get(tableproducto.getSelectionModel().getSelectedIndex());

                    id = dtt.getIdproducto();
                    producto = dtt.getNombre();
                    precio = dtt.getPrecio();

                    VController.recibirproducto(id, producto, precio);

                    Stage stage = new Stage();
                    stage.setScene(new Scene(p));
                    stage.show();

                } else {
                    if (comparar == 2) {
                        FXMLLoader loader = new FXMLLoader(getClass().getResource("/Interfaces/FXMLModeloP.fxml"));
                        Parent p = (Parent) loader.load();

                        FXMLModeloPController ModeloPController = loader.getController();

                        Contproducto dtt = tableproducto.getItems().get(tableproducto.getSelectionModel().getSelectedIndex());

                        id = dtt.getIdproducto();
                        producto = dtt.getNombre();
                        inventario = dtt.getStockA();

                        ModeloPController.recibir(id, producto, inventario);

                        Stage stage = new Stage();
                        stage.setScene(new Scene(p));
                        stage.show();
                    } else {

                        FXMLLoader loader = new FXMLLoader(getClass().getResource("/Interfaces/FXMLMRPL4L.fxml"));
                        Parent p = (Parent) loader.load();

                        FXMLMRPL4LController ModeloController = loader.getController();

                        Contproducto dtt = tableproducto.getItems().get(tableproducto.getSelectionModel().getSelectedIndex());

                        id = dtt.getIdproducto();

                        String enviar = String.valueOf(id);

                        ModeloController.obtenerr(enviar);

                        Stage stage = new Stage();
                        stage.setScene(new Scene(p));
                        stage.show();
                    }
                }
            }
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, e);
        }

    }

    public void indentificar(String id) {

        txtidentificar.setText(id);

    }

}
