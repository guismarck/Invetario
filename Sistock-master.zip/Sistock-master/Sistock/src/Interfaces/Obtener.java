/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Interfaces;

import Conexion.conexionbd;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javax.swing.JOptionPane;

/**
 *
 * @author nesto
 */
public class Obtener {

    private Statement pst = null;
    private ResultSet rs = null;
    private ObservableList<Double> guardar = FXCollections.observableArrayList();
    private ObservableList<Double> guarda2 = FXCollections.observableArrayList();

    public int Demandacantidad(int id, String tipo) throws Exception {

        if (tipo.equals("Mensual")) {
            try {

                int cantidad = 0;

                pst = conexionbd.getSql().createStatement();

                rs = pst.executeQuery("select  count (distinct(month(ord.Fecha))) from Venta ord \n"
                        + "inner join DetalleVenta ordtt on ord.Idventa  = ordtt.Idventa\n"
                        + "inner join Producto pr on ordtt.IdInventario=pr.Idproducto\n"
                        + "where month(ord.Fecha)  = month(ord.Fecha) and ordtt.IdInventario= " + id);

                while (rs.next()) {

                    cantidad = rs.getInt(1);
                }
                return cantidad;

            } catch (Exception e) {
                System.out.println("Obtener1");
                JOptionPane.showMessageDialog(null, e);
            }
        } else {

            if (tipo.equals("Semanal")) {
                try {

                    int cantidad = 0;

                    pst = conexionbd.getSql().createStatement();

                    rs = pst.executeQuery("select  count(distinct(datepart(wk,ord.Fecha))) from Venta ord \n"
                            + "inner join DetalleVenta ordtt on ord.Idventa  = ordtt.Idventa\n"
                            + "inner join Producto pr on ordtt.IdInventario=pr.Idproducto\n"
                            + "where datepart(wk,ord.Fecha)  = datepart(wk,ord.Fecha) and ordtt.IdInventario=" + id);

                    while (rs.next()) {

                        cantidad = rs.getInt(1);
                    }
                    return cantidad;

                } catch (Exception e) {
                    System.out.println("obtener2");
                    JOptionPane.showMessageDialog(null, e);
                }
            }

        }

        return 0;
    }

    public double Demanda(int id, String tipo) throws Exception {

        if (tipo.equals("Mensual")) {

            try {

                double cantidad = 0, cant;

                cant = Demandacantidad(id, tipo);

                ArrayList lista = new ArrayList();

                pst = conexionbd.getSql().createStatement();

                rs = pst.executeQuery("select  ordtt.Cantidad from Venta ord \n"
                        + "inner join DetalleVenta ordtt on ord.Idventa  = ordtt.Idventa\n"
                        + "inner join Producto pr on ordtt.IdInventario=pr.Idproducto\n"
                        + "where month(ord.Fecha)  = month(ord.Fecha) and ordtt.IdInventario=" + id);

                while (rs.next()) {

                    cantidad = rs.getDouble(1);

                    guardar.add(cantidad);
                    lista.add(guardar);
                }

                double suma = 0;

                for (int i = 0; i < lista.size(); i++) {

                    suma += guardar.get(i);
                }

                double Promedio = suma / cant;

                return Promedio;

            } catch (Exception e) {
                System.out.println("obtener3");
                JOptionPane.showMessageDialog(null, e);
            }
        } else {

            if (tipo.equals("Semanal")) {

                try {

                    double cantidad = 0, cant;

                    cant = Demandacantidad(id, tipo);

                    ArrayList lista = new ArrayList();

                    pst = conexionbd.getSql().createStatement();

                    rs = pst.executeQuery("select  ordtt.Cantidad from Venta ord \n"
                            + "inner join DetalleVenta ordtt on ord.Idventa  = ordtt.Idventa\n"
                            + "inner join Producto pr on ordtt.IdInventario=pr.Idproducto\n"
                            + "where datepart(wk,ord.Fecha)  = datepart(wk,ord.Fecha) and ordtt.IdInventario=" + id);

                    while (rs.next()) {

                        cantidad = rs.getDouble(1);

                        guardar.add(cantidad);
                        lista.add(guardar);
                    }

                    double suma = 0;

                    for (int i = 0; i < lista.size(); i++) {

                        suma += guardar.get(i);
                    }

                    double Promedio = suma / cant;

                    pst.close();
                    return Promedio;

                } catch (Exception e) {
                    System.out.println("obtener4");
                    JOptionPane.showMessageDialog(null, e);
                }
            }
        }

        return 0;
    }

    public double DesviacionM(int id, String tipo) throws Exception {

        if (tipo.equals("Mensual")) {

            try {

                double cantidad = 0, cant;

                cant = Demandacantidad(id, tipo);

                ArrayList lista = new ArrayList();

                pst = conexionbd.getSql().createStatement();

                rs = pst.executeQuery("select  ordtt.Cantidad from Venta ord \n"
                        + "inner join DetalleVenta ordtt on ord.Idventa  = ordtt.Idventa\n"
                        + "inner join Producto pr on ordtt.IdInventario=pr.Idproducto\n"
                        + "where month(ord.Fecha)  = month(ord.Fecha) and ordtt.IdInventario=" + id);

                while (rs.next()) {

                    cantidad = rs.getDouble(1);

                    guardar.add(cantidad);
                    lista.add(guardar);
                }

                double suma = 0;

                for (int i = 0; i < lista.size(); i++) {

                    suma += guardar.get(i);
                }

                double Promedio = suma / cant;

                double suma2 = 0;

                for (int i = 0; i < lista.size(); i++) {

                    suma2 += Math.pow((guardar.get(i) - Promedio), 2);
                }

                double raiz = Math.round(Math.sqrt(suma2 / (cant - 1)));

                pst.close();
                return raiz;

            } catch (Exception e) {
                System.out.println("obtener5");
                JOptionPane.showMessageDialog(null, e);
            }
        } else {

            if (tipo.equals("Semanal")) {

                try {

                    double cantidad = 0, cant;

                    cant = Demandacantidad(id, tipo);

                    ArrayList lista = new ArrayList();

                    pst = conexionbd.getSql().createStatement();

                    rs = pst.executeQuery("select  ordtt.Cantidad from Venta ord \n"
                            + "inner join DetalleVenta ordtt on ord.Idventa  = ordtt.Idventa\n"
                            + "inner join Producto pr on ordtt.IdInventario=pr.Idproducto\n"
                            + "where datepart(wk,ord.Fecha)  = datepart(wk,ord.Fecha) and ordtt.IdInventario=" + id);

                    while (rs.next()) {

                        cantidad = rs.getDouble(1);

                        guardar.add(cantidad);
                        lista.add(guardar);
                    }

                    double suma = 0;

                    for (int i = 0; i < lista.size(); i++) {

                        suma += guardar.get(i);
                    }

                    double Promedio = suma / cant;

                    double suma2 = 0;

                    for (int i = 0; i < lista.size(); i++) {

                        suma2 += Math.pow((guardar.get(i) - Promedio), 2);
                    }

                    double raiz = Math.round(Math.sqrt(suma2 / (cant - 1)));

                    pst.close();
                    return raiz;

                } catch (Exception e) {
                    System.out.println("obtener6");
                    JOptionPane.showMessageDialog(null, e);
                }
            }
        }

        return 0;
    }

    public String productoid(String txt) {

        try {
            int id = 0;

            pst = conexionbd.getSql().createStatement();

            rs = pst.executeQuery("select Idproducto from Producto where Nombre='" + txt + "'");

            while (rs.next()) {
                id = rs.getInt(1);
            }

            String resultado = String.valueOf(id);

            rs.close();
            return resultado;

        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, ex);
        }
        return null;
    }

    public ObservableList<Double> BuscarHs(int id, String tipo) throws Exception {

        try {

            ObservableList<Double> lista = FXCollections.observableArrayList();

            
            pst = conexionbd.getSql().createStatement();

            rs = pst.executeQuery("select s,i from L4Lproducto where IdMateriales= " + id);

            while (rs.next()) {
                
//                int l = Integer.parseInt(rs.getDouble(2)+"");
                
                lista.add(rs.getDouble(1));
            }
            return lista;

        } catch (Exception e) {
            System.out.println("Obtener1");
            JOptionPane.showMessageDialog(null, e);
        }

        return null;
    }

}
