/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Interfaces;

import Conexion.conexionbd;
import Constructores.ContDttvt;
import Constructores.Contventa;
import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;
import javax.swing.JOptionPane;

/**
 * FXML Controller class
 *
 * @author nesto
 */
public class FXMLDetalleventaController implements Initializable {

    private ObservableList<ContDttvt> dato;
    private PreparedStatement pst = null;
    private ResultSet rs = null;

    @FXML
    private TableView<ContDttvt> tableDetallevt;
    @FXML
    private TableColumn<?, ?> clmIdvt;
    @FXML
    private TableColumn<?, ?> clmfecha;
    @FXML
    private TableColumn<?, ?> clmcantidad;
    @FXML
    private TableColumn<?, ?> clmtotal;
    @FXML
    private DatePicker dtpkdtt;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        try {
            dato = FXCollections.observableArrayList();
            setCellTable();
            loadDatetable();
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, ex);
        }
    }

    private void setCellTable() {

        clmIdvt.setCellValueFactory(new PropertyValueFactory<>("IdVt"));
        clmfecha.setCellValueFactory(new PropertyValueFactory<>("Fecha"));
        clmcantidad.setCellValueFactory(new PropertyValueFactory<>("Cantidad"));
        clmtotal.setCellValueFactory(new PropertyValueFactory<>("Total"));
    }

    private void loadDatetable() {

        dato.clear();

        try {

            pst = conexionbd.getSql().prepareStatement("select dt.idventa, vt.fecha, sum(dt.Cantidad) as Cantidad, sum(dt.Cantidad*inp.Precio) from\n"
                    + "DetalleVenta dt inner join Venta vt on dt.Idventa= vt.Idventa\n"
                    + "inner join Empleado em on vt.Idempleado= em.Idempleado\n"
                    + "inner join Inventario_productos inp on dt.IdInventario = inp.IdInventario\n"
                    + "inner join Producto pr on inp.IdProducto = pr.Idproducto\n"
                    + "where dt.Idventa=vt.Idventa and vt.Idempleado=1\n"
                    + "group by dt.Idventa,vt.fecha");

            rs = pst.executeQuery();

            while (rs.next()) {
                dato.add(new ContDttvt(rs.getInt(1), rs.getDate(2), rs.getInt(3), rs.getDouble(4)));
            }

            tableDetallevt.setItems(dato);
        } catch (Exception ex) {

            JOptionPane.showMessageDialog(null, ex);
        }
    }

    @FXML
    private void passar(MouseEvent event) {

        String id;
        LocalDate fecha;
        Date f;

        try {

            if (event.getClickCount() == 2) {

//                FXMLLoader loader = new FXMLLoader(getClass().getResource("/Interfaces/FXMLVenta.fxml"));
//                Parent p = (Parent) loader.load();
//
//                FXMLVentaController fxmlpasarcontrollerin = loader.getController();
                ContDttvt dtt = tableDetallevt.getItems().get(tableDetallevt.getSelectionModel().getSelectedIndex());

//                id = String.valueOf(dtt.getIdVt());
//
//                f = dtt.getFecha();
//                fecha = f.toLocalDate();
//
//                fxmlpasarcontrollerin.Recibir(id, fecha);
//
//                Stage stage = new Stage();
//                stage.setScene(new Scene(p));
//                stage.show();
                FXMLVentaController.currentDetalleVt = dtt;
            }

        } catch (Exception e) {

            JOptionPane.showMessageDialog(null, e);
        }

    }

}
