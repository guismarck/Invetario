 /*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Inventario_Optiomo;

import Constructores.Conversiones;
import modelView.ModeloQView;
import Util.JFXOptionPane;
import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXCheckBox;
import com.jfoenix.controls.JFXTextField;
import java.net.URL;
import java.text.DecimalFormat;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import javafx.scene.control.TableView;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Pane;
import produccion3.BDMaterial;
import sis.Gestion.Personal.FXMLDocumentController;

/**
 * FXML Controller class
 *
 * @author josue
 */
public class FXMLModeloQController implements Initializable {

    @FXML
    private Label lbTitle;
    @FXML
    private TableView<ModeloQView> tableView;
    @FXML
    private JFXTextField txtDemanda,txtCostoAlmacenar, txtCostoPedir, 
            txtNumeroPedido, txtPlazo, txtStock, txtLaborales;
    @FXML
    private JFXTextField txtQ ,txtLapsoPedido, txtCostoMantener, txtCosto, 
            txtTasa, txtROP, txtNivelPro;
    @FXML
    private JFXButton btnCalManual;
    @FXML
    private JFXCheckBox check, checkH, checkSSL, checkDescuento;
    @FXML
    private ImageView img;
    @FXML
    private Label lbC, lbI, lbPlazo, lbStock, lbLaborales, lbMessage;
    @FXML
    private Pane pnAnswers, pnMessage;

    //VARIABLES 
    private double S, D, i, c, H, L, securityStock =0, dias;
    private MaterialModel materialModel;
    private BDMaterial mod;
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        init();
    }    

    
    private void init(){
        //Model view
        materialModel = new MaterialModel(tableView);
        materialModel.init();
        ViewModel.roundImageView(img, new Image("/img/icons8-product-512.png"));
        
        txtCostoAlmacenar.focusedProperty().addListener(new ChangeListener<Boolean>() {
            @Override
            public void changed(ObservableValue<? extends Boolean> observable, Boolean oldValue, Boolean newValue) {
                if(!newValue) txtCostoAlmacenar.validate();
            }
        });
        
        // Habilitar edición de los campos
        check.addEventHandler(MouseEvent.MOUSE_PRESSED, (e) ->{
            btnCalManual.setVisible(!check.isSelected());
            txtDemanda.setEditable(!check.isSelected());
            txtCostoPedir.setEditable(!check.isSelected());
            txtCostoAlmacenar.setEditable(!check.isSelected());
            if (!check.isSelected()) 
                ViewModel.MessageTransitio(221,1000,"Edición de campos Habilitada.", lbMessage, pnMessage);
            else
                ViewModel.MessageTransitio(221,1000,"Edición de campos Habilitada.", lbMessage, pnMessage);
        });
        
        //Habilita los campos para calcular H
        checkH.addEventHandler(MouseEvent.MOUSE_PRESSED, (e) ->{
            lbC.setVisible(!checkH.isSelected());
            lbI.setVisible(!checkH.isSelected());
            txtCosto.setVisible(!checkH.isSelected());
            txtTasa.setVisible(!checkH.isSelected());
            txtCosto.setEditable(!checkH.isSelected());
            txtTasa.setEditable(!checkH.isSelected());
        });
        
        //Hace visible los campos para el Stock de seguridad y el plazo de entrega
        checkSSL.addEventHandler(MouseEvent.MOUSE_PRESSED, (e) ->{
            lbPlazo.setVisible(!checkSSL.isSelected());
            txtPlazo.setVisible(!checkSSL.isSelected());
            txtPlazo.setEditable(!checkSSL.isSelected());
            lbStock.setVisible(!checkSSL.isSelected());
            txtStock.setVisible(!checkSSL.isSelected());
            txtStock.setEditable(!checkSSL.isSelected());
            lbLaborales.setVisible(!checkSSL.isSelected());
            txtLaborales.setVisible(!checkSSL.isSelected());
            txtLaborales.setEditable(!checkSSL.isSelected());
        });
        
        checkDescuento.addEventHandler(MouseEvent.MOUSE_PRESSED, (e) ->{
            txtQ.setEditable(!checkDescuento.isSelected());
        });
        
        //Click en el evento de cálculo manual
        btnCalManual.addEventHandler(MouseEvent.MOUSE_PRESSED, (e) -> {
            calcular();
        });
        
        ViewModel.MessageTransitio(221,1000,"Edición de campos Deshabilitada.", lbMessage, pnMessage);
        
        
        //Carga de los Productos
        mod = new BDMaterial();
        try {
            tableView.setItems(BDMaterial.loadProcedureMaterialesInfo());
        } catch (Exception ex) {
            Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    /*Evento de click de la tabla*/
    @FXML
    private void actionOnMouseClicked(MouseEvent event) {
        int row = tableView.getSelectionModel().getSelectedIndex();
        if (row > -1) {
            byte fot[] = (byte[])tableView.getColumns().get(9).getCellData(row);
            img.setImage(new Image(Conversiones.extraxtImage(fot)));
            txtDemanda.setText(tableView.getColumns().get(2).getCellData(row).toString());
            txtCostoPedir.setText(tableView.getColumns().get(3).getCellData(row).toString());
            txtCostoAlmacenar.setText(tableView.getColumns().get(4).getCellData(row).toString());
            txtCosto.setText(tableView.getColumns().get(5).getCellData(row).toString());
            txtTasa.setText(tableView.getColumns().get(6).getCellData(row).toString());
            txtStock.setText(tableView.getColumns().get(7).getCellData(row).toString());
            txtPlazo.setText(tableView.getColumns().get(8).getCellData(row).toString());
            calcular();
        }
    }
    
    /*Método que ejecuta una serie de instrucciones para realizae los cálculos*/
    private void calcular(){
        //Obtenemos los datos de la Demanda(D) y el costo de pedir(S) de la interfaz.
            try {
                D = Double.parseDouble(txtDemanda.getText().trim());
                S = Double.parseDouble(txtCostoPedir.getText().trim());
            } catch (NumberFormatException e) {
                if (txtDemanda.getText().length()==0 || txtCostoPedir.getText().length()==0) {
                    JFXOptionPane.showMessageDialog("Campos Vacios", "Faltan camois por llenar", JFXOptionPane.MessageType.INFO);
                }else{
                    JFXOptionPane.showMessageDialog("Valores Invalidos", "Solo se debe ingresar valores numéricos", JFXOptionPane.MessageType.INFO);
                }
                return;
            }
            //Se valida la entrada del costo(C), la tasa de almacén (i) y se calcula H
            //Porque es posible que estos campos esten vacios.
            try{
                c = Double.parseDouble(txtCosto.getText().trim());
                i = Double.parseDouble(txtTasa.getText().trim());
                H = i * c;
            }catch(NumberFormatException nfe){}
            //Si se lanzo una excepción en el bloque anterior significa que no 
            //Se logro cálcular H, por ende procedemos a ver si este valor el usuario
            //Lo ha ingresado en el campo de texto que le pertenece.
            if ((txtCostoAlmacenar.getText().trim().length() > 0) && ((c==0 && i==0) || (c != 0 && H == 0))) {
                H = Double.parseDouble(txtCostoAlmacenar.getText().trim());
            }
            if (H == 0) {
                JFXOptionPane.showMessageDialog("Campos Vacios", "Debe ingresar el costo de mantener(H).", JFXOptionPane.MessageType.INFO);
                return;
            }
            ModeloQ qModel = new ModeloQ(D, S, H);
            //DecimalFormat sirve para dar un determinado formato.
            DecimalFormat df1 = new DecimalFormat("#.0");
            DecimalFormat df2 = new DecimalFormat("#.00");
            
            //Se setea la información al los campos de texto.
            if (!checkDescuento.isSelected()) {
                txtQ.setText(df1.format(qModel.getQOptimo("ceil")) + "");
            }
            
            txtNumeroPedido.setText(qModel.getNoPedidos("ceil") + "");
            txtLapsoPedido.setText(df2.format(qModel.getTiempoEntrePedido("ceil")) + "");
            
            if (c != 0) {
                if (checkDescuento.isSelected()) {
                    int Q = Integer.parseInt(txtQ.getText().trim());
                    txtCostoMantener.setText(df2.format(qModel.costoTotal(c, Q, "ceil")) + "");
                }else{
                    txtCostoMantener.setText(df2.format(qModel.costoTotal(c, "ceil")) + "");
                }
            }
            
            try {
                securityStock = Double.parseDouble(txtStock.getText().trim());
                dias = Double.parseDouble(txtLaborales.getText().trim());
                L = Double.parseDouble(txtPlazo.getText().trim());
            } catch (NumberFormatException e) {}
            
            if (securityStock!=0) {
                txtNivelPro.setText(qModel.getNivelPromedioInventario(i, c, (int)securityStock, "ceil") + "");
                if (dias != 0 && L != 0) {
                    txtROP.setText(df2.format(qModel.getROP(dias, L, (int)securityStock)) + "");
                    ViewModel.PaneTransition(10, 1000,pnMessage);
                }else{
                    ViewModel.MessageTransitio(221, 1000,"ROP necesita de L y Días de labor", lbMessage, pnMessage);
                }
            }
            
            pnAnswers.setVisible(true);
            D=0; H =0; S=0; i=0; c=0;
    }
    
    
}
