/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Inventario_Optiomo;

import modelView.ModeloQView;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;

/**
 *
 * @author josue
 */
public class MaterialModel {
    //Tabla
    private TableView<ModeloQView> tableView;
    //Columnas
    private TableColumn<ModeloQView, String> colID, colNom, colDem, colCP, colCA, colPre, colTas, colSto, colPla, colFoto;
    
    public MaterialModel(TableView<ModeloQView> tableView) {this.tableView = tableView;}
    
//    Inicializa la clase
    public void init(){
        initTable();
        addColumns();
        setCellTable();
    }
    
    //Inicializa las columnas
    private void initTable(){
        //Inicializan las columnas
        colID = new TableColumn("ID");
        colNom = new TableColumn("Nombre");
        colDem = new TableColumn("Demanda");
        colCP = new TableColumn("C Pedir");
        colCA = new TableColumn("C Almacenar");
        colPre = new TableColumn("Costo Prod");
        colTas = new TableColumn("Tasa Alm");
        colSto = new TableColumn("Stock Mín");
        colPla = new TableColumn("Plazo Ent");
        colFoto = new TableColumn("Foto");
        colFoto.setVisible(false);
    }
    
    private void addColumns(){
        //Agrega las columnas
        tableView.getColumns().clear();
        tableView.getColumns().add(colID);
        tableView.getColumns().add(colNom);
        tableView.getColumns().add(colDem);
        tableView.getColumns().add(colCP);
        tableView.getColumns().add(colCA);
        tableView.getColumns().add(colPre);
        tableView.getColumns().add(colTas);
        tableView.getColumns().add(colSto);
        tableView.getColumns().add(colPla);
        tableView.getColumns().add(colFoto);
    }
    
    private void setCellTable() {
        colID.setCellValueFactory(new PropertyValueFactory<>("id"));
        colNom.setCellValueFactory(new PropertyValueFactory<>("nombre"));
        colDem.setCellValueFactory(new PropertyValueFactory<>("demanda"));
        colCP.setCellValueFactory(new PropertyValueFactory<>("costoPedir"));
        colCA.setCellValueFactory(new PropertyValueFactory<>("costoAlmacenar"));
        colPre.setCellValueFactory(new PropertyValueFactory<>("costoProducto"));
        colTas.setCellValueFactory(new PropertyValueFactory<>("tasaAlmacen"));
        colSto.setCellValueFactory(new PropertyValueFactory<>("StockSegu"));
        colPla.setCellValueFactory(new PropertyValueFactory<>("plazoEnt"));
        colFoto.setCellValueFactory(new PropertyValueFactory<>("foto"));
    }
}
