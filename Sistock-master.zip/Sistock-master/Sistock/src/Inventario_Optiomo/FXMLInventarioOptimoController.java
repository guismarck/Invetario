/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Inventario_Optiomo;

import com.jfoenix.controls.JFXTabPane;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.event.Event;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.control.Label;
import javafx.scene.control.Tab;
import javafx.scene.layout.VBox;

/**
 * FXML Controller class
 *
 * @author josue
 */
public class FXMLInventarioOptimoController implements Initializable {

    @FXML
    private Label lbTitle;
    @FXML
    private JFXTabPane tabPane;
    @FXML
    private Tab tabQ, tabQServi, tabP, tabRPM;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        try {
            String path = "/Inventario_Optiomo/";
            VBox root1 = (VBox)FXMLLoader.load(getClass().getResource(path + "FXMLModeloQ.fxml"));
            tabQ.setContent(root1);
            
            VBox root2 = (VBox)FXMLLoader.load(getClass().getResource(path + "FXMLModeloQNivelServ.fxml"));
            tabQServi.setContent(root2);
            
            Parent root3 = FXMLLoader.load(getClass().getResource(path + "FXMLModeloP.fxml"));
            tabP.setContent(root3);
            
            Parent root4 = FXMLLoader.load(getClass().getResource(path + "FXMLMRPL4L.fxml"));
            tabRPM.setContent(root4);
        } catch (IOException ex) {
            Logger.getLogger(FXMLInventarioOptimoController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }    

    @FXML
    private void onSelectionChange(Event event) {
//        
    }
    
}
