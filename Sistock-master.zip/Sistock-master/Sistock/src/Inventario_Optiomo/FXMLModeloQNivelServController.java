/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Inventario_Optiomo;

import Constructores.Conversiones;
import Constructores.InventarioMateriales;
import Constructores.Material;
import modelView.ModeloQView;
import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXCheckBox;
import com.jfoenix.controls.JFXComboBox;
import com.jfoenix.controls.JFXTextField;
import java.net.URL;
import java.text.DecimalFormat;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import javafx.scene.control.TableView;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Pane;
import produccion3.BDMaterial;
import sis.Gestion.Personal.FXMLDocumentController;
import Util.JFXOptionPane;
import produccion3.DInventario_Materiales;

/**
 * FXML Controller class
 *
 * @author josue
 */
public class FXMLModeloQNivelServController implements Initializable {

    @FXML
    private TableView<ModeloQView> tableView;
    @FXML
    private Pane pnMessage, pnAnswers;
    @FXML
    private Label lbMessage;
    @FXML
    private JFXCheckBox checkManual, checkRound;
    @FXML
    private JFXButton btnSetData, btnCalManual;
    @FXML
    private JFXTextField txtStock, txtROP, txtDesviacion, txtDemanda;
    @FXML
    private JFXComboBox<Float> cbNivel;
    @FXML
    private ImageView img;

    //Variables
    private MaterialModel materialModel;
    private DecimalFormat format;
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        init();
    }    
    
    private void init(){
        //Model View
        materialModel = new MaterialModel(tableView);
        materialModel.init();
        ViewModel.roundImageView(img, new Image("/img/icons8-product-512.png"));
        
        //Formato numerico
         format = new DecimalFormat("#.00");
         
        try {
            tableView.setItems(BDMaterial.loadProcedureMaterialesInfo());
        } catch (Exception ex) {
            Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        //Check para habilitar el calculo manual
        checkManual.addEventHandler(MouseEvent.MOUSE_PRESSED, (e) ->{
            pnAnswers.setVisible(!checkManual.isSelected());
            if (!checkManual.isSelected()) 
                ViewModel.MessageTransitio(221,1000,"Edición de campos Habilitada.", lbMessage, pnMessage);
            else
                ViewModel.MessageTransitio(221,1000,"Edición de campos Habilitada.", lbMessage, pnMessage);
        });
        
        //Botón que calcula manualmente 
        btnCalManual.addEventHandler(MouseEvent.MOUSE_PRESSED, (e) -> {
            calcular();
        });
        //Botón que setea los datos calculados a la base de datos
        btnSetData.addEventHandler(MouseEvent.MOUSE_PRESSED, (e) -> {
            int idMaterial = tableView.getSelectionModel().getSelectedItem().getId();
            int demanda=0;
            double desvi=0, nivel=0;
            String round = (checkRound.isSelected())? "ceil" : "no";
            try{
                demanda = (int)Double.parseDouble(txtDemanda.getText());
                desvi = Double.parseDouble(txtDesviacion.getText());
                nivel = Double.parseDouble(format.format(cbNivel.getItems().get(cbNivel.getSelectionModel().getSelectedIndex())));   

            }catch(NumberFormatException nfe){

            }
        
            ModeloQ modeloq = new ModeloQ();
            modeloq.setD((demanda/360));
            InventarioMateriales inv = new InventarioMateriales(null, new Material(null, idMaterial));
            inv.setStockInicial((float) modeloq.getSecurityStock(nivel, desvi, round));
            boolean flag = DInventario_Materiales.updateStockMinimo(inv);
            
            if(flag)
                JFXOptionPane.showMessageDialog("Guardado", 
                        "Se actualizó el stock de seguridad", 
                        JFXOptionPane.MessageType.OK);
        });
        
        ViewModel.MessageTransitio(221,1000,"Edición de campos Deshabilitada.", lbMessage, pnMessage);
//        
//        //Panel de mensaje
//        pnMessage.addEventHandler(MouseEvent.MOUSE_ENTERED, (e) -> {
//            if (pnMessage.getWidth() < 20) {
//                ViewModel.PaneTransition(221,200, pnMessage);
//            }
//        });
//        
//        pnMessage.addEventHandler(MouseEvent.MOUSE_EXITED, (e) -> {
//            if (pnMessage.getWidth() > 20) {
//                ViewModel.PaneTransition(15,200,pnMessage);
//            }
//        });
        
        ObservableList<Float> comboList = FXCollections.observableArrayList();
        DecimalFormat format = new DecimalFormat("#.00");
        for (float i = 0.01f; i < 1.00f; i+= 0.01) {
            comboList.add(Float.parseFloat(format.format(i)));
        }
        cbNivel.setItems(comboList);
        cbNivel.getSelectionModel().select(94);
        txtDesviacion.setText("3");
    }

    @FXML
    private void actionOnMouseClicked(MouseEvent event) {
        int row = tableView.getSelectionModel().getSelectedIndex();
        if (row > -1) {
            byte fot[] = (byte[])tableView.getColumns().get(9).getCellData(row);
            img.setImage(new Image(Conversiones.extraxtImage(fot)));
            txtDemanda.setText(tableView.getColumns().get(2).getCellData(row).toString());
            calcular();
        }
    }
    
    private void calcular(){
        int demanda=0;
        double desvi=0, nivel=0;
        String round = (checkRound.isSelected())? "ceil" : "no";
        try{
            demanda = (int)Double.parseDouble(txtDemanda.getText());
            desvi = Double.parseDouble(txtDesviacion.getText());
            nivel = Double.parseDouble(format.format(cbNivel.getItems().get(cbNivel.getSelectionModel().getSelectedIndex())));   
            
        }catch(NumberFormatException nfe){
            
        }
        
        ModeloQ modeloq = new ModeloQ();
        modeloq.setD((demanda/360));
        txtStock.setText(modeloq.getSecurityStock(nivel, desvi, round) + "");
        txtROP.setText(modeloq.getROP(nivel, desvi, round) + ""); 
    }
}
