/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Inventario_Optiomo;

import Conexion.conexionbd;
import Constructores.ContMRPL4L;
import Constructores.Contdetalleproducto;
import Interfaces.Obtener;
import Util.Cargarcombo;
import Util.JFXOptionPane;
import com.jfoenix.controls.JFXComboBox;
import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;


/**
 * FXML Controller class
 *
 * @author nesto
 */
public class FXMLMRPL4LController implements Initializable {

    private PreparedStatement pst = null;
    private ResultSet rs = null;

    ObservableList<Contdetalleproducto> dato;
    ObservableList<Integer> guardarsemana = FXCollections.observableArrayList();

    Cargarcombo cb = new Cargarcombo();

    @FXML
    private TableView<ContMRPL4L> tableMRPLL;

    ObservableList<ContMRPL4L> lista;

    @FXML
    private TableColumn<?, ?> clmidL4L;
    @FXML
    private TableColumn<?, ?> clmsemana;
    @FXML
    private TableColumn<?, ?> clmdemanda;
    @FXML
    private TableColumn<?, ?> clmproducir;
    @FXML
    private TableColumn<?, ?> clminvfinal;
    @FXML
    private TableColumn<?, ?> clmh;
    @FXML
    private TableColumn<?, ?> clms;
    @FXML
    private TableColumn<?, ?> clmct;
    @FXML
    private Button btnbuscar;
    @FXML
    private TextField txtidproducto;
    @FXML
    private JFXComboBox<?> cbxproducto;
    @FXML
    private TableView<Contdetalleproducto> tabledetalle;
    @FXML
    private TableColumn<?, ?> clmmateriales;
    @FXML
    private TableColumn<?, ?> clmcantidad;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {

        try {
            dato = FXCollections.observableArrayList();
            cb.consultar_producto(cbxproducto);

            this.cell();
            setCelldetalle();

            final ObservableList<ContMRPL4L> tablaPersonaSel = tableMRPLL.getSelectionModel().getSelectedItems();
        } catch (Exception ex) {
            JFXOptionPane.showMessageDialog("Error", ex.getMessage(), JFXOptionPane.MessageType.ERROR);
            ex.printStackTrace();
        }
    }

    @FXML
    private void actionbuscar(ActionEvent event) {

//        try {
//            FXMLLoader loader = new FXMLLoader(getClass().getResource("/Interfaces/FXMLproducto.fxml"));
//            Parent p = (Parent) loader.load();
//
//            FXMLproductoController productoController = loader.getController();
//
//            productoController.indentificar("4");
//
//            Stage stage = new Stage();
//            Scene scene = new Scene(p);
//            stage.setScene(scene);
//            stage.show();
//        } catch (IOException ex) {
//            JOptionPane.showMessageDialog(null, ex);
//        }
    }

    public void cell() {

        clmidL4L.setCellValueFactory(new PropertyValueFactory<>("Idmrpl4l"));
        clmsemana.setCellValueFactory(new PropertyValueFactory<>("Semana"));
        clmdemanda.setCellValueFactory(new PropertyValueFactory<>("Demanda"));
        clmproducir.setCellValueFactory(new PropertyValueFactory<>("Producir"));
        clminvfinal.setCellValueFactory(new PropertyValueFactory<>("Actual"));
        clmh.setCellValueFactory(new PropertyValueFactory<>("H"));
        clms.setCellValueFactory(new PropertyValueFactory<>("S"));
        clmct.setCellValueFactory(new PropertyValueFactory<>("ct"));

        lista = FXCollections.observableArrayList();
        tableMRPLL.setItems(lista);
    }

    public void obtenerr(String id) {
        txtidproducto.setText(id);
    }

    @FXML
    private void actionproducto(ActionEvent event) {

        if ((cbxproducto.getSelectionModel().getSelectedIndex() != -1)) {

            Obtener obt = new Obtener();

            String seleccion = (String) cbxproducto.getValue();

            txtidproducto.setText(obt.productoid(seleccion));
            cargardetalle();

        }
    }

    private void setCelldetalle() {

        clmmateriales.setCellValueFactory(new PropertyValueFactory<>("material"));
        clmcantidad.setCellValueFactory(new PropertyValueFactory<>("cantidad"));
    }

    public void cargardetalle() {

        dato.clear();

        try {

//            pst = con.prepareStatement("select mt.Nombre,\n"
//                    + "prdt.Cantidad from Venta ord \n"
//                    + "inner join DetalleVenta ordtt on ord.Idventa  = ordtt.Idventa\n"
//                    + "inner join Producto pr on ordtt.IdInventario=pr.Idproducto\n"
//                    + "inner join Producto_necesidad prnc on prnc.IdProducto = pr.Idproducto\n"
//                    + "inner join Producto_detalle prdt on prdt.Idprnc = prnc.Idprnc\n"
//                    + "inner join Materiales mt on mt.IdMateriales = prdt.IdMateriales\n"
//                    + "inner join Inventario_materiales mtin on mtin.IdMateriales = mt.IdMateriales\n"
//                    + "where datepart(wk,ord.Fecha)  = datepart(wk,ord.Fecha) and ordtt.IdInventario=1\n"
//                    + "group by ordtt.IdInventario, pr.Nombre, mt.Nombre, prdt.Cantidad");
            pst = conexionbd.getSql().prepareStatement(
                    "select mt.Nombre,prdt.Cantidad from Producto pr\n"
                    + "inner join Producto_necesidad prnc on prnc.IdProducto = pr.Idproducto\n"
                    + "inner join Producto_detalle prdt on prdt.Idprnc = prnc.Idprnc\n"
                    + "inner join Materiales mt on prdt.IdMateriales= mt.IdMateriales\n"
                    + "where pr.Idproducto=1");

            rs = pst.executeQuery();

            while (rs.next()) {
                dato.add(new Contdetalleproducto(rs.getString(1), rs.getInt(2)));
                tabledetalle.setItems(dato);
            }
        } catch (SQLException ex) {
            JFXOptionPane.showMessageDialog("Error", ex.getMessage(), JFXOptionPane.MessageType.ERROR);
            ex.printStackTrace();
        }
    }

    @FXML
    private void Tablecalcular(MouseEvent event) {

        int semana;
        double demanda;

        ArrayList listasemana = new ArrayList();

        try {

            pst = conexionbd.getSql().prepareStatement("select datepart(wk,ord.Fecha) as semana,\n"
                    + "sum(ordtt.Cantidad)*prdt.Cantidad as Demanda from Venta ord \n"
                    + "inner join DetalleVenta ordtt on ord.Idventa  = ordtt.Idventa\n"
                    + "inner join Producto pr on ordtt.IdInventario=pr.Idproducto\n"
                    + "inner join Producto_necesidad prnc on prnc.IdProducto = pr.Idproducto\n"
                    + "inner join Producto_detalle prdt on prdt.Idprnc = prnc.Idprnc\n"
                    + "where datepart(wk,ord.Fecha)  = datepart(wk,ord.Fecha) \n"
                    + "and ordtt.IdInventario=1 and prdt.IdMateriales=1\n"
                    + "group by datepart(wk,ord.Fecha),ordtt.IdInventario,prdt.Cantidad\n"
                    + "order by datepart(wk,ord.Fecha)");

            rs = pst.executeQuery();

            while (rs.next()) {

                ContMRPL4L cont = new ContMRPL4L();

                cont.setSemana(rs.getInt(1));
                cont.setDemanda(rs.getDouble(2));
                lista.add(cont);
            }

            Obtener obb = new Obtener();
           listasemana.add(obb.BuscarHs(1, ""));
        } catch (Exception ex) {
            JFXOptionPane.showMessageDialog("Error", ex.getMessage(), JFXOptionPane.MessageType.ERROR);
            ex.printStackTrace();
        }
    }
}
