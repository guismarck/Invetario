/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Inventario_Optiomo;

import Util.TablaDistribución;

/**
 *
 * @author josue
 */
public class ModeloQ {
    private double D;//Costo de manterner
    private double S;//Costo de pedir
    private double H;//Costo de almacenar
    public ModeloQ() {
    }

    /**
     * Inicializa las variables locales y necesarias para realizar los calculos del Q Óptimo
     * @param D
     *  Demanda aunal.
     * @param S 
     *  Costo de pedir
     * @param H
     *  Costo de almacenar
     */
    public ModeloQ(double D, double S, double H) {
        this.D = D;
        this.S = S;
        this.H = H;
    }
    
    /**
     * Inicializa las variables locales y necesarias para realizar los calculos del Q Óptimo
     * @param D
     *  Demanda aunal.
     * @param S 
     *  Costo de pedir
     */
    public ModeloQ(double D, double S) {
        this.D = D;
        this.S = S;
    }

    public double getD() {
        return D;
    }

    public void setD(double D) {
        this.D = D;
    }

    public double getS() {
        return S;
    }

    public void setS(double S) {
        this.S = S;
    }
    
    public double getH() {
        return H;
    }

    public void setH(double H) {
        this.H = H;
    }
    
    public void setH(double i, double c) {
        this.H = getCostoMantener(i, c);
    }
    
    /**
     * Cálcula el costo de mantener un determinado producto
     * @param i
     *  Es la tasa de almacen.
     * @param c
     *  Costo unitario del producto
     * @return 
     *  Costo de mantener el producto
     */
    public double getCostoMantener(double i, double c){
        this.H = (c * i);
        return getH();
    }
    
    /**
     * Cálculo del Q Óptimo
     * @param i
     *  Tasa de almacen
     * @param c
     *  Costo de mantener un producto
     * @return 
     *  Retorna la cantidad óptima del producto
     */
    public double getQOptimo(double i, double c, String roundNext){
        double qOptimo = Math.sqrt(((2 * getD() * getS()) / getCostoMantener(i, c)));
        if(roundNext.equalsIgnoreCase("ceil"))
            return Math.ceil(qOptimo);              //Retorna un decimal al entero superior mas cercano
        else if(roundNext.equalsIgnoreCase("floor"))
            return Math.floor(qOptimo);             //Retorna un decimal al entero inferior mas cercano
        else
            return Math.round(qOptimo);             //Retorna un decimal al entero mas cercano.
    }
    
    /**
     * @return 
     *  Retorna la cantidad óptima del producto
     */
    public double getQOptimo(String roundNext){
        double qOptimo = Math.sqrt((2 * getD() * getS()) / getH());
        if(roundNext.equalsIgnoreCase("ceil"))
            return Math.ceil(qOptimo);              //Retorna un decimal al entero superior mas cercano
        else if(roundNext.equalsIgnoreCase("floor"))
            return Math.floor(qOptimo);             //Retorna un decimal al entero inferior mas cercano
        else
            return Math.round(qOptimo);             //Retorna un decimal al entero mas cercano.
    }
    
    /**
     * @param i
     *  Tasa de almacen
     * @param c
     * Costo de mantener un producto
     * @param roundNext
     *  Parametro que establece si el resultado será redondeado al número mayor, menor o al mas cercano
     *  este puede recibir dos parámetros: 'ceil' para redondear al entero superior, floor para redondear
     *  al entero inferior y round para redondear al entero mas cercano. Si este campo es vacio se utilizara round.
     * @return 
     * Retorna el número de pedidos
     */
    public double getNoPedidos(double i, double c, String roundNext){
        double noPedidps = (getD() / getQOptimo(i, c, roundNext));
        if(roundNext.equalsIgnoreCase("ceil"))
            return Math.ceil(noPedidps);
        else if(roundNext.equalsIgnoreCase("floor"))
            return Math.floor(noPedidps);
        else
            return Math.round(noPedidps);
    }
    
    /**
     * @param roundNext
     *  Parametro que establece si el resultado será redondeado al número mayor, menor o al mas cercano
     *  este puede recibir dos parámetros: 'ceil' para redondear al entero superior, floor para redondear
     *  al entero inferior y round para redondear al entero mas cercano. Si este campo es vacio se utilizara round.
     * @return 
     * Retorna el número de pedidos
     */
    public double getNoPedidos(String roundNext){
        return (roundNext.equalsIgnoreCase("ceil"))? Math.ceil((getD() / getQOptimo(roundNext))) : Math.ceil((getD() / getQOptimo(roundNext)));
    }
    
    /**
     * @param i
     *  Tasa de almacen
     * @param c
     * Costo de mantener un producto
     * @param roundNext
     *  Parametro que establece si el resultado será redondeado al número mayor, menor o al mas cercano
     *  este puede recibir dos parámetros: 'ceil' para redondear al entero superior, floor para redondear
     *  al entero inferior y round para redondear al entero mas cercano. Si este campo es vacio se utilizara round.
     * @return 
     * Retorna el número de pedidos
     */
    public double getTiempoEntrePedido(double i, double c, String roundNext){
        return (getQOptimo(i, c, roundNext) / getD());
    }
    
    /**
     * @param roundNext
     *  Parametro que establece si el resultado será redondeado al número mayor, menor o al mas cercano
     *  este puede recibir dos parámetros: 'ceil' para redondear al entero superior, floor para redondear
     *  al entero inferior y round para redondear al entero mas cercano. Si este campo es vacio se utilizara round.
     * @return 
     * Retorna el número de pedidos
     */
    public double getTiempoEntrePedido(String roundNext){
        return  getQOptimo(roundNext)/ getD();
    }
    /**
     * ROP
     * @param dias
     *  Dias habiles
     * @param L
     *  Plazo de entrega en días
     * @param securutyStock
     *  Inventario(stock) de seguridad. 
     * @return 
     *  Retorna el ROP
     */
    public double getROP(double dias, double L, int securutyStock){
        return (D / dias) * L + securutyStock;
    }
    
    //Se calcula ROP y se calcula la demanda promedio
    public double getROP(double dias, double nivelServicio, double desviacion, String roundNext){
        return (D / dias)  + getSecurityStock(nivelServicio, desviacion, roundNext);
    }
    
    //SE TOMA 'D' como la demanda promedio
    public double getROP(double nivelServicio, double desviacion, String roundNext){
        return (D)  + getSecurityStock(nivelServicio, desviacion, roundNext);
    }
    /**
     * Costo total de mantener el inventario
     * @param i
     *  Tasa de almacen
     * @param c
     *  Cosot de mantener el producto
     * @param roundNext
     *  Parametro que establece si el resultado será redondeado al número mayor, menor o al mas cercano
     *  este puede recibir dos parámetros: 'ceil' para redondear al entero superior, floor para redondear
     *  al entero inferior y round para redondear al entero mas cercano. Si este campo es vacio se utilizara round.
     * @return 
     */
    public double costoTotal(double i, double c, String roundNext){
        double costoT = ((D * S) / getQOptimo(i, c, roundNext)) + ((getQOptimo(i, c, roundNext) * (i / 100) * c) / 2) + (D * c);
        if(roundNext.equalsIgnoreCase("ceil"))
            return Math.ceil(costoT);              //Retorna un decimal al entero superior mas cercano
        else if(roundNext.equalsIgnoreCase("floor"))
            return Math.floor(costoT);             //Retorna un decimal al entero inferior mas cercano
        else
            return Math.round(costoT);             //Retorna un decimal al entero mas cercano.
    }
    
    public double costoTotal(double i, double c,int Q, String roundNext){
        double costoT = ((D * S) / Q) + ((Q * (i / 100) * c) / 2) + (D * c);
        if(roundNext.equalsIgnoreCase("ceil"))
            return Math.ceil(costoT);              //Retorna un decimal al entero superior mas cercano
        else if(roundNext.equalsIgnoreCase("floor"))
            return Math.floor(costoT);             //Retorna un decimal al entero inferior mas cercano
        else
            return Math.round(costoT);             //Retorna un decimal al entero mas cercano.
    }
    
    /**
     * Costo total de mantener el inventario
     * @param c
     *  Cosot de mantener el producto
     * @param roundNext
     *  Parametro que establece si el resultado será redondeado al número mayor, menor o al mas cercano
     *  este puede recibir dos parámetros: 'ceil' para redondear al entero superior, floor para redondear
     *  al entero inferior y round para redondear al entero mas cercano. Si este campo es vacio se utilizara round.
     * @return 
     */
    public double costoTotal(double c, String roundNext){
        return (((D * S) / getQOptimo(roundNext))) + ((getQOptimo(roundNext) * getH() / 2) + (D * c));
    }
    
    public double costoTotal(double c, int Q, String roundNext){
        return (((D * S) / Q)) + ((Q * getH() / 2) + (D * c));
    }
    
    /**
     * @param i
     *  Tasa de almacen
     * @param c
     *  Cosot de mantener el producto
     * @param securityStock
     *  Inventario(stock) de seguridad. 
     * @param roundNext 
     *  Parametro que establece si el resultado será redondeado al número mayor, menor o al mas cercano
     *  este puede recibir dos parámetros: 'ceil' para redondear al entero superior, floor para redondear
     *  al entero inferior y round para redondear al entero mas cercano. Si este campo es vacio se utilizara round.
     * @return 
     *  Retorna el ROP
     */
    public double getNivelPromedioInventario(double i, double c, int securityStock, String roundNext){
        return Math.round((getQOptimo(i, c, roundNext) + securityStock)/2);
    }
    
    public double getSecurityStock(double nivelServicio, double desviación, String roundNext){
        double ss = TablaDistribución.getZNormal(nivelServicio) * desviación;
        if(roundNext.equalsIgnoreCase("ceil"))
            return (int)Math.ceil(ss);              //Retorna un decimal al entero superior mas cercano
        else if(roundNext.equalsIgnoreCase("floor"))
            return (int)Math.floor(ss);             //Retorna un decimal al entero inferior mas cercano
        else if (roundNext.equalsIgnoreCase("round"))
            return (int)Math.round(ss);
        else
            return ss;
    }
}
