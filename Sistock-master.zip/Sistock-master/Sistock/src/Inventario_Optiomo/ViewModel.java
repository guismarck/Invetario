/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Inventario_Optiomo;

import Constructores.Conversiones;
import modelView.ModeloQView;
import sis.Gestion.Inventario.FXMLGestionInventarioController;
import Util.JFXOptionPane;
import java.io.File;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.animation.Interpolator;
import javafx.animation.KeyFrame;
import javafx.animation.KeyValue;
import javafx.animation.Timeline;
import javafx.scene.SnapshotParameters;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.image.WritableImage;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.stage.FileChooser;
import javafx.util.Duration;

/**
 *
 * @author josue
 */
public class ViewModel {

    public static void roundImageView(ImageView iv, Image i){
        double w = iv.getFitWidth(), h = iv.getFitHeight();
        iv.setImage(i);
        
        Rectangle clip = new Rectangle(w, h);
        clip.setArcWidth(w);
        clip.setArcHeight(h);
        iv.setClip(clip);
        
        SnapshotParameters parameters = new SnapshotParameters();
        parameters.setFill(Color.TRANSPARENT);
        WritableImage image = iv.snapshot(parameters, null);
        
        iv.setClip(null);
        iv.setImage(image);
    }
    
    public static boolean chooiseImage(ImageView img){
        FileChooser fileChooser = new FileChooser();
            fileChooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("Imagenes (*.jpg)", "*.jpg"));
            File file = fileChooser.showOpenDialog(null);
            if (file != null) {
                if (file.getName().contains(".jpg")) {
                    try{
                        try{
                            byte foto[] = Conversiones.extraxtBytes(file);
                            Image image = new Image(Conversiones.extraxtImage(foto));
                            roundImageView(img, image);
                            return true;
                        }catch (IOException ex){
                            Logger.getLogger(FXMLGestionInventarioController.class.getName()).log(Level.SEVERE, null, ex);
                            JFXOptionPane.showMessageDialog("Error al cargar", "La imagen no se pudo leer\nLa direccion obtenida fue: " + file.getAbsolutePath(), JFXOptionPane.MessageType.ERROR);
                        }
                    }catch (IllegalArgumentException ex){
                        Logger.getLogger(FXMLGestionInventarioController.class.getName()).log(Level.SEVERE, null, ex);
                        JFXOptionPane.showMessageDialog("Imagen Corrupta", "La imagen está dañada\nUbicación: " + file.getAbsolutePath(), JFXOptionPane.MessageType.ERROR);
                    }
                }
            }
        return false;
    }
//    public void imagenMovil(ImageView img){
//        //Image circular
//        Circle clip = new Circle(70, 70, 100);
//        img.setClip(clip);
//        ObjectProperty<Point2D> mouseAnchor = new SimpleObjectProperty<>();
//        img.setOnMousePressed(new EventHandler<MouseEvent>() {
//            @Override
//            public void handle(MouseEvent event) {
//                mouseAnchor.set(new Point2D(event.getSceneX(), event.getSceneY()));
//            }
//        });
//        //Imagen mobible
//        img.setOnMouseDragged(new EventHandler<MouseEvent>() {
//            @Override
//            public void handle(MouseEvent event) {
//                double deltaX = event.getSceneX() - mouseAnchor.get().getX();
//                double deltaY = event.getSceneY() - mouseAnchor.get().getY();
//                img.setLayoutX(img.getLayoutX() + deltaX);
//                img.setLayoutY(img.getLayoutY() + deltaY);
//                clip.setCenterX(clip.getCenterX() - deltaX);
//                clip.setCenterY(clip.getCenterY() - deltaY);
//                mouseAnchor.set(new Point2D(event.getSceneX(), event.getSceneY()));
//            }
//        });
//    }
    
    /**
     * Método que realiza una animación de trancición vertical, de izquierda a derecha.
     * 
     *@param width
     *          La longitud de despazamiento del panel
     * @param time
     *          El tiempo que tardará la animación en realizarce.
     **/
    public static void PaneTransition(double width, double time, Pane pnMessage) {
        Timeline timeline = new Timeline();
        KeyValue kv = new KeyValue(pnMessage.prefWidthProperty(), width, Interpolator.EASE_IN);
        KeyFrame kf = new KeyFrame(Duration.millis(time), kv);
        timeline.getKeyFrames().add(kf);
        timeline.play();
    }
    
    public static void MessageTransitio(int width, int time, String message, Label lbMessage, Pane pnMessage){
        //Mensaje 
        lbMessage.setText(message);
        pnMessage.prefWidthProperty().set(0);
        PaneTransition(width,time, pnMessage);
    }
}
