/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Inventario_Optiomo;

import Conexion.conexionbd;
import Constructores.ContModeloP;
import Constructores.Contproducto;
import Interfaces.FXMLproductoController;
import Interfaces.Obtener;
import Util.TablaDistribución;
import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javax.swing.JOptionPane;

/**
 * FXML Controller class
 *
 * @author nesto
 */
public class FXMLModeloPController implements Initializable {

    private ObservableList<ContModeloP> dato;
    private PreparedStatement pst = null;
    private ResultSet rs = null;
    private ObservableList<Double> guardar = FXCollections.observableArrayList();
    private ObservableList<String> cbx = FXCollections.observableArrayList();

    @FXML
    private TableView<ContModeloP> clmtablemetodop;
    @FXML
    private TableColumn<?, ?> clmidp;
    @FXML
    private TableColumn<?, ?> clminventario;
    @FXML
    private TableColumn<?, ?> clmrevision;
    @FXML
    private TableColumn<?, ?> clmentrega;
    @FXML
    private TableColumn<?, ?> clmservicio;
    @FXML
    private TableColumn<?, ?> clmss;
    @FXML
    private TableColumn<?, ?> clmq;
    @FXML
    private TextField txtmaterial;
    @FXML
    private TextField txtidm;
    @FXML
    private Button btnbuscar;
    @FXML
    private TextField txtinventario;
    @FXML
    private TextField txtrevision;
    @FXML
    private TextField txtentrega;
    @FXML
    private TextField txtservicio;
    @FXML
    private TextField txtdemanda;
    @FXML
    private Button btnagregar;
    @FXML
    private Button btneditar;
    @FXML
    private Button btneliminar;
    @FXML
    private Button btngraficar;
    @FXML
    private ComboBox<String> cbxopcion;
    @FXML
    private Button Calcular;
    @FXML
    private TableColumn<?, ?> clmidproducto;
    @FXML
    private TableColumn<?, ?> clmproducto;
    @FXML
    private TableColumn<?, ?> clmfecha;
    @FXML
    private TableColumn<?, ?> clmdemanda;
    @FXML
    private TextField txtidp;
    @FXML
    private TableColumn<?, ?> clmtipo;

    public static Contproducto currentProducto = null;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        try {
            dato = FXCollections.observableArrayList();
            llenar();
            setCellTable();
            loadDatetable();
            tablatexfiel();
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, ex);
        }
    }

    @FXML
    private void Actionbuscarmaterial(ActionEvent event) throws IOException {

        FXMLLoader loader = new FXMLLoader(getClass().getResource("/Interfaces/FXMLproducto.fxml"));
        Parent p = (Parent) loader.load();

        FXMLproductoController productoController = loader.getController();

        productoController.indentificar("2");
        
        Stage stage = new Stage();
        stage.setScene(new Scene(p));
        stage.initModality(Modality.APPLICATION_MODAL);
        stage.showAndWait();

        txtidm.setText(currentProducto.getIdproducto()+"");
        txtmaterial.setText(currentProducto.getNombre());
        txtinventario.setText(currentProducto.getStockA()+"");

    }

    @FXML
    private void Actioncalcular(ActionEvent event) throws Exception {
    }

    @FXML
    private void actionagregar(ActionEvent event) throws SQLException, Exception {

        int id = Integer.parseInt(txtidm.getText());
        String opcion = cbxopcion.getSelectionModel().getSelectedItem();

        double porcentaje = Double.parseDouble(txtservicio.getText());
        double z = TablaDistribución.getZNormal(porcentaje);
        double Promedio = Double.parseDouble(txtdemanda.getText());

        double inventario = Double.parseDouble(txtinventario.getText());

        Obtener obt = new Obtener();

        Double estandar = (obt.DesviacionM(id, opcion));

        int revision = Integer.parseInt(txtrevision.getText());
        int entrega = Integer.parseInt(txtentrega.getText());

        double D = ((revision + entrega) * (Math.pow(estandar, 2)));

        double pv = (revision + entrega) * Promedio;

        double ss = z * (Math.sqrt(D));

        double q = Math.round(pv + ss - inventario);

        java.util.Date d = new java.util.Date();
        java.sql.Date date2 = new java.sql.Date(d.getTime());

        try {

            String sql = "Insert into ModeloP(IdInventario ,Inventarioactual ,Fecha,Nivelservicio "
                    + ",Tiemporevision ,Tiempoentrega ,Demanda ,SS, Q, Tipo) values"
                    + "(?,?,?,?,?,?,?,?,?,?)";

            int idp = Integer.parseInt(txtidm.getText());

            pst = conexionbd.getSql().prepareStatement(sql);
            pst.setInt(1, idp);
            pst.setDouble(2, inventario);
            pst.setDate(3, date2);
            pst.setDouble(4, porcentaje);
            pst.setInt(5, revision);
            pst.setInt(6, entrega);
            pst.setDouble(7, Promedio);
            pst.setDouble(8, ss);
            pst.setDouble(9, q);
            pst.setString(10, opcion);

            int i = pst.executeUpdate();

            if (i == 1) {
                JOptionPane.showMessageDialog(null, "Datos insertados correctamente");
                setCellTable();
                loadDatetable();
            }

        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, ex);
        } finally {
            pst.close();
        }
    }

    @FXML
    private void actioneditar(ActionEvent event) throws SQLException, Exception {

        int idmp = Integer.parseInt(txtidp.getText());
        int id = Integer.parseInt(txtidm.getText());
        String opcion = cbxopcion.getValue();

        double porcentaje = Double.parseDouble(txtservicio.getText());
        double z = TablaDistribución.getZNormal(porcentaje);
        double Promedio = Double.parseDouble(txtdemanda.getText());

        double inventario = Double.parseDouble(txtinventario.getText());

        Obtener obt = new Obtener();

        Double estandar = (obt.DesviacionM(id, opcion));

        int revision = Integer.parseInt(txtrevision.getText());
        int entrega = Integer.parseInt(txtentrega.getText());

        double D = ((revision + entrega) * (Math.pow(estandar, 2)));

        double pv = (revision + entrega) * Promedio;

        double ss = z * (Math.sqrt(D));

        double q = Math.round(pv + ss - inventario);

        java.util.Date d = new java.util.Date();
        java.sql.Date date2 = new java.sql.Date(d.getTime());

        try {

            String sql = "update ModeloP set IdInventario=? ,Inventarioactual=? ,Fecha=?,Nivelservicio=? "
                    + ",Tiemporevision=? ,Tiempoentrega=? ,Demanda=? ,SS=?, Q=?, Tipo=? where IdMP = ?";

            int idp = Integer.parseInt(txtidm.getText());

            pst = conexionbd.getSql().prepareStatement(sql);
            pst.setInt(1, idp);
            pst.setDouble(2, inventario);
            pst.setDate(3, date2);
            pst.setDouble(4, porcentaje);
            pst.setInt(5, revision);
            pst.setInt(6, entrega);
            pst.setDouble(7, Promedio);
            pst.setDouble(8, ss);
            pst.setDouble(9, q);
            pst.setString(10, opcion);
            pst.setDouble(11, idmp);

            int i = pst.executeUpdate();

            if (i == 1) {
                JOptionPane.showMessageDialog(null, "Datos editados correctamente");
                setCellTable();
                loadDatetable();
            }

        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, ex);
        } finally {
            pst.close();
        }
    }

    @FXML
    private void actioneliminar(ActionEvent event) {

        String sql = "delete from ModeloP where IdMP=?";
        int id = Integer.parseInt(txtidp.getText());

        try {

            pst = conexionbd.getSql().prepareStatement(sql);
            pst.setInt(1, id);

            int i = pst.executeUpdate();

            if (i == 1) {
                JOptionPane.showMessageDialog(null, "Datos eliminados correctamente");
                setCellTable();
                loadDatetable();
            }

        } catch (Exception e) {
        }
    }

    @FXML
    private void actiongraficar(ActionEvent event) {
    }

    public void recibir(int id, String producto, double inventario) {

        txtdemanda.clear();
        cbxopcion.setPromptText("Seleccionar");

        String idp = String.valueOf(id);
        String inven = String.valueOf(inventario);

        txtidm.setText(idp);
        txtmaterial.setText(producto);
        txtinventario.setText(inven);

    }

    public void llenar() {

        cbx.addAll("Semanal", "Mensual");
        cbxopcion.setItems(cbx);
    }

    @FXML
    public void k() {

        if ((cbxopcion.getSelectionModel().getSelectedIndex() != -1)) {

            int id = Integer.parseInt(txtidm.getText());
            String opcion = cbxopcion.getSelectionModel().getSelectedItem();

            Obtener obt = new Obtener();

            try {

                String Promedio = String.valueOf(obt.Demanda(id, opcion));

                txtdemanda.setText(Promedio);

            } catch (Exception ex) {
                Logger.getLogger(FXMLModeloPController.class.getName()).log(Level.SEVERE, null, ex);
            }

        } else {
            txtdemanda.setText("");
            JOptionPane.showMessageDialog(null, "Error");
        }

    }

    private void setCellTable() {

        clmidp.setCellValueFactory(new PropertyValueFactory<>("IdMP"));
        clmidproducto.setCellValueFactory(new PropertyValueFactory<>("Idproducto"));
        clmproducto.setCellValueFactory(new PropertyValueFactory<>("producto"));
        clmfecha.setCellValueFactory(new PropertyValueFactory<>("fecha"));
        clminventario.setCellValueFactory(new PropertyValueFactory<>("Inventarioactual"));
        clmdemanda.setCellValueFactory(new PropertyValueFactory<>("demanda"));
        clmrevision.setCellValueFactory(new PropertyValueFactory<>("tiemporevision"));
        clmentrega.setCellValueFactory(new PropertyValueFactory<>("tiempoentrega"));
        clmservicio.setCellValueFactory(new PropertyValueFactory<>("nivelservicio"));
        clmss.setCellValueFactory(new PropertyValueFactory<>("ss"));
        clmq.setCellValueFactory(new PropertyValueFactory<>("Q"));
        clmtipo.setCellValueFactory(new PropertyValueFactory<>("Tipo"));
    }

    private void loadDatetable() {

        dato.clear();

        try {
            pst = conexionbd.getSql().prepareStatement("select mp.IdMP, mp.IdInventario, pr.Nombre, dt.Stock_actual, mp.Fecha, mp.Nivelservicio,"
                    + " mp.Tiemporevision, mp.Tiempoentrega, mp.Demanda, mp.SS, mp.Q , mp.Tipo "
                    + "from ModeloP mp inner join Inventario_productos dt "
                    + "on mp.IdInventario  = dt.IdInventario inner join producto pr "
                    + "on dt.Idproducto = pr.Idproducto");
            rs = pst.executeQuery();

            while (rs.next()) {
                dato.add(new ContModeloP(rs.getInt(1), rs.getInt(2), rs.getString(3),
                        rs.getDouble(4), rs.getDate(5), rs.getDouble(6), rs.getInt(7),
                        rs.getInt(8), rs.getInt(9), rs.getDouble(10), rs.getDouble(11), rs.getString(12)));
                clmtablemetodop.setItems(dato);
            }
        } catch (SQLException e) {

            JOptionPane.showMessageDialog(null, e);
        }
    }

    private void tablatexfiel() {

        clmtablemetodop.setOnMouseClicked(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent event) {

                ContModeloP dt = clmtablemetodop.getItems().get(clmtablemetodop.getSelectionModel().getSelectedIndex());
                txtidp.setText(String.valueOf(dt.getIdMP()));
                txtidm.setText(String.valueOf(dt.getIdproducto()));
                txtmaterial.setText(dt.getProducto());
                txtinventario.setText(String.valueOf(dt.getInventarioactual()));
                txtservicio.setText(String.valueOf(dt.getNivelservicio()));
                txtrevision.setText(String.valueOf(dt.getTiemporevision()));
                txtentrega.setText(String.valueOf(dt.getTiempoentrega()));
                txtdemanda.setText(String.valueOf(dt.getDemanda()));
                cbxopcion.setPromptText(dt.getTipo());
            }
        });
    }

}
