/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package security;

import Constructores.Usuario;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author josue
 */
public class LoginServer {
    private ObjectOutputStream oos;
    private ObjectInputStream ois;
    private InputStream is;
    private OutputStream os;
    private boolean isOpen = false;
    
    public boolean insertar(Usuario us){
        boolean flag = false;
        try {
            openWrite();
            oos.writeObject(us);
            flag =true;
            close();
        } catch (IOException ex) {
            Logger.getLogger(LoginServer.class.getName()).log(Level.SEVERE, null, ex);
        }
        return flag;
    }
    
    public Usuario cargar(){
        Usuario us = null;
        try {
            openRead();
            if (isOpen) {
                us = (Usuario) ois.readObject();
            }
            close();
        } catch (IOException | ClassNotFoundException ex) {
            Logger.getLogger(LoginServer.class.getName()).log(Level.SEVERE, null, ex);
        }
        return us;
    }
    
    public void openWrite(){
        if ( !isOpen) {
            try {
                File currentFile = new File(".");
                String path = currentFile.getCanonicalPath() + "\\src\\security\\login.dat";
                
                File file = new File(path);
                if (!file.exists()) {
                    file.createNewFile();
                }
                
                os = new FileOutputStream(file, false);
                oos = new ObjectOutputStream(os);
                isOpen = true;
            } catch (IOException ex) {
                Logger.getLogger(LoginServer.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }
    
    public void openRead(){
        if ( !isOpen) {
            try {
                File currentFile = new File(".");
                String path = currentFile.getCanonicalPath() + "\\src\\security\\login.dat";
                
                File file = new File(path);
                if (!file.exists()) {
                    file.createNewFile();
                }else{
                    if (file.length() > 0) {
                        is = new FileInputStream(file);
                        ois = new ObjectInputStream(is);
                        isOpen = true;
                    }
                }
                
            } catch (IOException ex) {
                Logger.getLogger(LoginServer.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }
    public void close(){
        if (isOpen) {
            try {
                if (oos != null) {
                    oos.close();oos = null;
                    os.close();os=null;
                }
                if (ois != null) {
                    ois.close();ois = null;
                    is.close();is =null;
                }
                isOpen = false;
            } catch (IOException ex) {
                Logger.getLogger(LoginServer.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }
    
}
