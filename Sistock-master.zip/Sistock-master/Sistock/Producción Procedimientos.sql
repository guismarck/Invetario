use Producci�n

---------------------------------------------------------------------------
--PROCEDIMIENTO QUE MUESTRA LOS MATERIALES QUE SON COMPRADOS A UN PROVEEDOR
---------------------------------------------------------------------------
go
if exists(
select * 
  from Producci�n.information_schema.routines info
 where info.routine_type = 'PROCEDURE' and info.routine_name = 'Material_Proveedor'
)
Drop Procedure Material_Proveedor;
Go

Create Procedure Material_Proveedor  @idProveedor int
as 
Select 
m.IdMateriales,
m.Codigo as [C�digo Material],  
m.Nombre as [Nombre Material],
p.IdProveedor,
p.Nombre as [Proveedor]
from Materiales m 
Inner Join Inventario_materiales im on m.IdMateriales = m.IdMateriales
Inner Join Proveedor p On im.IdProveedor = p.IdProveedor
Where p.IdProveedor = @idProveedor
group by m.IdMateriales, m.Codigo, p.IdProveedor, m.Nombre, p.Nombre
--exec Material_Proveedor 2

-------------------------------------------------------------------
--DETALLE DE UNA COMPRA ESPECIFICA
-------------------------------------------------------------------
Go
if exists(
select * 
  from Producci�n.information_schema.routines info
 where info.routine_type = 'PROCEDURE' and info.routine_name = 'Detalle_Compras'
)
Drop Procedure Detalle_Compras;
Go

Create Procedure Detalle_Compras @idCompra int
As
select 
c.IdCompra,
p.IdProveedor,
m.IdMateriales,
dc.IdDetalleCompra,
p.Nombre as [Proveedor],
m.Nombre as Insumo,
m.Tipo as [Tipo Insumo],
im.Unidad_medida [Medida],
dc.Cantidad,
(dc.Cantidad * im.Precio) [Monto],
c.Fecha_Compra
from Materiales m 
inner Join Inventario_materiales im On m.IdMateriales = im.IdMateriales
inner join Detalle_Compra dc On m.IdMateriales = dc.IdMateriales
inner join Compra c On dc.IdCompra = c.IdCompra 
Inner Join Proveedor p On c.IdProveedor = p.IdProveedor
Where c.IdCompra = @idCompra;
 --Detalle_Compras 7
Go

-------------------------------------------------------------------
--COMPRA PROEEDOR SIN FILTROS
-------------------------------------------------------------------
if exists(
select * 
  from Producci�n.information_schema.routines info
 where info.routine_type = 'PROCEDURE' and info.routine_name = 'Compras_Proveedor'
)
Drop Procedure Compras_Proveedor;
Go

Create Procedure Compras_Proveedor as
select 
c.IdCompra,
p.IdProveedor,
p.Nombre as [Proveedor],
c.Fecha_Compra,
sum(dc.Cantidad * im.Precio) [Costo de la Compra]
from Materiales m 
inner Join Inventario_materiales im On m.IdMateriales = im.IdMateriales
inner join Detalle_Compra dc On m.IdMateriales = dc.IdMateriales
inner join Compra c On dc.IdCompra = c.IdCompra 
Inner Join Proveedor p On c.IdProveedor = p.IdProveedor
Group by c.IdCompra, p.IdProveedor, p.Nombre, c.Fecha_Compra;
--exec Compras_Proveedor 

----------------------------------------------------------------------
--FUNCI�N DE TABLA QUE MUESTRA LAS VENTAS EN UNIDADES DE CADA PRODUCTO
----------------------------------------------------------------------
Go
if exists(
select * 
  from Producci�n.information_schema.routines info
 where info.routine_type = 'FUNCTION' and info.routine_name = 'fn_cantidad_vendida'
)
Drop Function fn_cantidad_vendida;

Go
Create function fn_cantidad_vendida ()
returns  Table
As
return 
Select 
p.Idproducto,
p.Nombre,
sum(dv.Cantidad) as Ventas
from Venta v 
inner join DetalleVenta dv On v.Idventa = dv.Idventa
inner join Inventario_productos inv on dv.IdInventario = inv.IdInventario
inner join Producto p On inv.IdProducto = p.Idproducto
Group by p.Idproducto,p.Nombre;

----------------------------------------------------------------------
--FUNCI�N QUE MUESTRA LA CANTIDAD DEMANDADA DE MATERIALES POR PRODUCTO
----------------------------------------------------------------------
Go
if exists(
select * 
  from Producci�n.information_schema.routines info
 where info.routine_type = 'FUNCTION' and info.routine_name = 'fn_demanda_material_producto'
)
Drop Function fn_demanda_material_producto;

Go
Create function fn_demanda_material_producto ()
returns Table
As
Return
select 
p.Idproducto, 
p.Nombre as [Nombre Producto],
m.IdMateriales,
m.Nombre as [Nombre Material],
((select sub.CantidadMaterial from Producto_Material sub where sub.IdMaterial = m.IdMateriales and sub.IdProducto = p.Idproducto) 
* 
(select cv.Ventas from fn_cantidad_vendida() cv where cv.Idproducto = p.Idproducto)) As [Demanda de Materiales Por Producto]
from Materiales m inner join Producto_Material pm On m.IdMateriales = pm.IdMaterial inner join Producto p On pm.IdProducto = p.Idproducto
group by p.Idproducto, p.Nombre,m.IdMateriales, m.Nombre

----------------------------------------------------------------------
--MUESTRA LA CANTIDAD TOTAL DEMANDADA DE CADA UNO DE LOS MATERIALES
----------------------------------------------------------------------
Go
if exists(
select * 
  from Producci�n.information_schema.routines info
 where info.routine_type = 'Function' and info.routine_name = 'fn_demanda_materiales'
)
Drop Function fn_demanda_materiales;

Go
Create Function fn_demanda_materiales()
Returns Table
As
Return
select 
demanda.IdMateriales, 
demanda.[Nombre Material], 
sum(demanda.[Demanda de Materiales Por Producto]) As [Cantidad Demandada],
im.Unidad_medida
from fn_demanda_material_producto() demanda inner join Inventario_materiales im On demanda.IdMateriales = im.IdMateriales
group by demanda.IdMateriales, demanda.[Nombre Material], im.Unidad_medida;
select * from fn_demanda_materiales();
select * from Detalleventa;
----------------------------------------------------------------------
---PROCEDIMIENTO QUE MUESTRA EL DETALLE DE LOS MATERIALES (es usada para c�lcular el modelo Q)
----------------------------------------------------------------------
Go
if exists(
select * 
  from Producci�n.information_schema.routines info
 where info.routine_type = 'PROCEDURE' and info.routine_name = 'Materiales_Info'
)
Drop Procedure Materiales_Info;
Go
Create procedure Materiales_Info
as
select 
m.IdMateriales,
m.Nombre,
m.Descripcion,
(select mat.Imagen from Materiales mat where mat.IdMateriales = m.IdMateriales) As Imagen,
(select fn.[Cantidad Demandada] from fn_demanda_materiales() fn where fn.IdMateriales = m.IdMateriales) as Cantidad,
(select sum(dev.Cantidad) from Devoluci�n_Compra dev where m.IdMateriales = dc.IdMateriales) as Devoluciones, --No estoy seguro de esto.
((select fn.[Cantidad Demandada] from fn_demanda_materiales() fn where fn.IdMateriales = m.IdMateriales) 
- 
(select sum(dev.Cantidad) from Devoluci�n_Compra dev where m.IdMateriales = dc.IdMateriales))as Demanda,
md.CostoPedir,
md.CostoAlmacenar,
iv.Precio,
md.TasaAlmacen,
iv.StocK_inicial, 
md.PlazoEntrega
from Materiales m 
inner join Detalle_Compra dc On m.IdMateriales = dc.IdMateriales
inner join ModeloQ md On md.IdMateria = m.IdMateriales
inner join Inventario_materiales iv On iv.IdMateriales = m.IdMateriales
group by m.IdMateriales,dc.IdMateriales,  
m.Nombre, m.Descripcion,
md.CostoPedir, md.CostoAlmacenar, 
iv.Precio, md.TasaAlmacen,iv.StocK_inicial, 
md.PlazoEntrega;

----------------------------------------------------------------------
---PROCEDIMIENTO QUE VERIFICA SI UN USUARIO EXISTE O NO
----------------------------------------------------------------------
Go
if exists(
select * 
  from Producci�n.information_schema.routines info
 where info.routine_type = 'PROCEDURE' and info.routine_name = 'Comprobar_Credenciales'
)
Drop Procedure Comprobar_Credenciales;
Go
Create Procedure Comprobar_Credenciales @nombreUs varchar(15), @password varchar(15)
as
Select * from Empleado emp where emp.usuario = @nombreUs and emp.Pass = @password;
--exec Comprobar_Credenciales 'eduardo09', '12345'
