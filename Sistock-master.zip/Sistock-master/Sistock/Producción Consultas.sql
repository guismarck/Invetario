Use Producci�n;


-------------------------------------------------------------------------------------------------
/*	
** MUESTRA LOS PATERIALES CON SU RESPECTIVO PROVEEDOR
**/

 select inm.IdInventario, inm.IdProveedor, p.Nombre,inm.IdMateriales,
       mt.Nombre, inm.StocK_inicial, inm.Stock_actual,inm.Unidad_medida,
	   inm.Precio  from Inventario_materiales inm inner join 
	   Proveedor p on inm.IdProveedor=p.IdProveedor inner join Materiales mt
       on inm.IdMateriales = mt.IdMateriales

-------------------------------------------------------------------------------------------------
/*	
** MUESTRA EL DETALLE DEL INVENTARIO DE PRODUCTOS
**/

select inv.IdInventario, pr.Idproducto, pr.Codigo, pr.Nombre,inv.Fecha_vencimiento,
inv.StocK_inicial,inv.Stock_actual, inv.Precio 
from Inventario_productos inv inner join Producto pr
on inv.IdProducto = pr.Idproducto 

-------------------------------------------------------------------------------------------------
/*	
** Demanda mensual hist�rica de los productos.
**/

select ordtt.IdInventario, ordtt.cantidad,month(ord.Fecha) from Venta ord 
inner join DetalleVenta ordtt on ord.Idventa  = ordtt.Idventa
inner join Producto pr on ordtt.IdInventario=pr.Idproducto
where month(ord.Fecha)  = month(ord.Fecha)
order by ordtt.IdInventario asc
go

/*	
** Cantidad total historica comprada de un producto (sin devoluciones)
**/
select 
m.Nombre,
sum(dc.Cantidad) as [Cantidad Comprada]
from Detalle_Compra dc inner join Materiales m on dc.IdMateriales =m.IdMateriales 
group by  m.Nombre

-------------------------------------------------------------------------------------------------
/*	
** A�n nose 
**/
select  count (distinct(month(ord.Fecha))) from Venta ord 
inner join DetalleVenta ordtt on ord.Idventa  = ordtt.Idventa
inner join Producto pr on ordtt.IdInventario=pr.Idproducto
where month(ord.Fecha)  = month(ord.Fecha) and ordtt.IdInventario=5
go

-------------------------------------------------------------------------------------------------
/*	
** VENTAS ANUALES
**/
select  sum(ordtt.Cantidad),year(ord.Fecha), count (distinct(year(ord.Fecha))) from Venta ord 
inner join DetalleVenta ordtt on ord.Idventa  = ordtt.Idventa
inner join Producto pr on ordtt.IdInventario=pr.Idproducto
where year(ord.Fecha)  = year(ord.Fecha) and ordtt.IdInventario=5
group by year(ord.Fecha)
go

-------------------------------------------------------------------------------------------------
/*	
** Aun no se xdxd
**/
select  count(distinct(datepart(wk,ord.Fecha))) from Venta ord 
inner join DetalleVenta ordtt on ord.Idventa  = ordtt.Idventa
inner join Producto pr on ordtt.IdInventario=pr.Idproducto
where datepart(wk,ord.Fecha)  = datepart(wk,ord.Fecha) and ordtt.IdInventario=5
go


select * from inventario_productos ivp inner join Producto p on ivp.idProducto = p.idProducto;
select* from venta;
select * from detalleventa;
select * from Producto;
select * from Materiales;
select * from Producto_Material;

-------------------------------------------------------------------------------------------------
--									MODELO P

select mp.IdMP, mp.IdInventario, pr.Nombre, dt.Stock_actual, mp.Fecha, mp.Nivelservicio,
 mp.Tiemporevision, mp.Tiempoentrega, mp.Demanda, mp.SS, mp.Q 
from ModeloP mp inner join Inventario_productos dt
on mp.IdInventario  = dt.IdInventario inner join producto pr
on dt.Idproducto = pr.Idproducto
-------------------------------------------------------------------------------------------------

-------------------------------------------------------------------------------------------------
--									MODELO Q
-------------------------------------------------------------------------------------------------