create database Producci�n
go
use Producci�n
go

create table Proveedor(
IdProveedor int identity(1,1) primary key not null,
Nombre nvarchar(25) not null,
Direcci�n nvarchar(120),
Correo_Electronico nvarchar(25),
Telefono int
)
go

create table Materiales(
IdMateriales int identity(1,1) primary key not null,
Codigo nvarchar(29) not null,
Nombre nvarchar(25) not null,
Descripcion nvarchar(120) ,
Tipo nvarchar(20) not null,
Imagen image,
Estado nvarchar(20) not null
)
go

create table Inventario_materiales(
IdInventario int identity(1,1) primary key not null,
IdProveedor int foreign key references Proveedor(IdProveedor),
IdMateriales int foreign key references Materiales(IdMateriales),
Fecha_vencimiento date,
StocK_inicial decimal(7,2) not null,
Stock_actual decimal(7,2) not null,
Unidad_medida nvarchar(10) not null,
Precio decimal(7,2) not null
)
go

create table Empleado(
Idempleado int identity(1,1) primary key not null,
Nombre nvarchar(20) not null,
Apellido nvarchar(20) not null,
Edad int not null,
Cedula nvarchar(25) not null,
correo nvarchar(25),
Celular int,
usuario nvarchar(20) not null,
Pass nvarchar(20) not null
)
go

create table Producto(
Idproducto int identity(1,1) primary key not null,
Codigo nvarchar(20) not null,
Nombre nvarchar(20) not null,
Imagen Image)
go

create table Inventario_productos(
IdInventario int identity(1,1) primary key not null,
IdProducto int foreign key references Producto(IdProducto),
Fecha_vencimiento date,
StocK_inicial decimal(7,2) not null,
Stock_actual decimal(7,2) not null,
Precio decimal(7,2) not null
)
go

create table Producto_necesidad(
Idprnc int identity(1,1) primary key not null,
IdProducto int foreign key references Producto(IdProducto)
)
go

create table Producto_detalle(
Iddtpr int identity(1,1) primary key not null,
Idprnc int foreign key references Producto_necesidad(Idprnc),
IdMateriales int foreign key references Materiales(IdMateriales),
Cantidad int
)
go

create table ModeloP(
IdMP int identity(1,1) primary key not null,
IdInventario int foreign key references Inventario_productos(IdInventario),
Inventarioactual decimal(7,2) not null,
Fecha date,
Nivelservicio decimal(7,2) not null,
Tiemporevision int not null,
Tiempoentrega int not null,
Demanda int not null,
SS decimal(7,2) not null,
Q decimal(7,2) not null,
Tipo nvarchar(29) not null
)
go

/*
select mp.IdMP, mp.IdInventario, pr.Nombre, dt.Stock_actual, mp.Fecha, mp.Nivelservicio,
 mp.Tiemporevision, mp.Tiempoentrega, mp.Demanda, mp.SS, mp.Q 
from ModeloP mp inner join Inventario_productos dt
on mp.IdInventario  = dt.IdInventario inner join producto pr
on dt.Idproducto = pr.Idproducto
*/

create table Venta(
Idventa int identity(1,1) primary key not null,
Idempleado int foreign key references Empleado(Idempleado),
Fecha date)
go

create table DetalleVenta(
IdDetalleventa int identity(1,1) primary key not null,
Idventa int foreign key references Venta(Idventa) not null,
IdInventario int foreign key references Inventario_productos(IdInventario) not null,
Cantidad int not null
)
go

create table L4Lproducto(
IdL4Lproducto int identity(1,1) primary key not null,
IdInventario int foreign key references Inventario_productos(IdInventario) not null,
C decimal(7,2) not null,
s decimal (7,2) not null,
i decimal (7,2) not null
)
go

-- Creacion del login

create login Eduardo23
with password = '1234',
default_database = Producci�n
go

--- creacion de usuario

create user Eduardo23
for login Eduardo23
with default_schema=mi_esquema
go
-- creacion de esquema

create schema mi_esquema authorization Eduardo23;
go

grant create proc,execute,create role,create table,select,insert,update,delete to Eduardo23;
go

-----------------------------------------------------------------------------------------

insert into Empleado(Nombre,Apellido,Edad,Cedula,correo,Celular,usuario,Pass)
values('Eduardo','Rivas',23,'wh23','rivas@gmail',82345678,'eduardo09','12345')
go
/*
select * from Empleado
go
*/
----------------------------------------------------------------------------------------

insert into Proveedor(Nombre,Direcci�n,Correo_Electronico,Telefono)
values('Cainsa','Km 8 carretera norte','cainsa@gmail',22342178)
go

insert into Proveedor(Nombre,Direcci�n,Correo_Electronico,Telefono)
values('Parmalat','Km 9 carretera norte','parmalat@gmail',23452149)
go

insert into Proveedor(Nombre,Direcci�n,Correo_Electronico,Telefono)
values('Monisa','Km 10 carretera norte','Monisa@gmail',23487654)
go
/*
select * from Proveedor
go
*/
--------------------------------------------------------------------------------------

insert into Materiales(Codigo,Nombre,Descripcion,Tipo,Imagen,Estado)
values('P001','Leche','Uso para pastel','Lacteo','','Existencia')
go

insert into Materiales(Codigo,Nombre,Descripcion,Tipo,Imagen,Estado)
values('P002','Masa','Uso para pan','Lacteo','','Existencia')
go

/*
select * from Materiales
go
*/

-----------------------------------------------------------------------------

insert into Inventario_materiales(IdProveedor,IdMateriales,Fecha_vencimiento,
StocK_inicial,Stock_actual,Unidad_medida,Precio)
values(2,2,'09-12-2020',34.4,20.4,'Kg',23.3)
go

insert into Inventario_materiales(IdProveedor,IdMateriales,Fecha_vencimiento,
StocK_inicial,Stock_actual,Unidad_medida,Precio)
values(2,1,'28-03-2021',28,15,'Lt',15.3)
go

/*
Select * from Inventario_materiales
go
*/

/*
select inm.IdInventario, inm.IdProveedor, p.Nombre,inm.IdMateriales,
       mt.Nombre, inm.StocK_inicial, inm.Stock_actual,inm.Unidad_medida,
	   inm.Precio  from Inventario_materiales inm inner join 
	   Proveedor p on inm.IdProveedor=p.IdProveedor inner join Materiales mt
       on inm.IdMateriales = mt.IdMateriales
go
*/

--------------------------------------------------------------------------

insert into Producto (Codigo,Nombre,Imagen)
values ('P001','Pico con queso','')
go

insert into Producto (Codigo,Nombre,Imagen)
values ('P002','Manjar','')
go

insert into Producto (Codigo,Nombre,Imagen)
values ('P003','Pan tostado','')
go

insert into Producto (Codigo,Nombre,Imagen)
values ('P004','Bolillo','')
go

insert into Producto (Codigo,Nombre,Imagen)
values ('P005','Polvoron','')
go

insert into Producto (Codigo,Nombre,Imagen)
values ('P006','Churros de queso','')
go

insert into Producto (Codigo,Nombre,Imagen)
values ('P007','Empanadas de queso','')
go

insert into Producto (Codigo,Nombre,Imagen)
values ('P008','Pan blanco','')
go

insert into Producto (Codigo,Nombre,Imagen)
values ('P009','Pan con mantequilla','')
go

insert into Producto (Codigo,Nombre,Imagen)
values ('P010','Pan de molde','')
go

insert into Producto (Codigo,Nombre,Imagen)
values ('P011','Pan frances','')
go

insert into Producto (Codigo,Nombre,Imagen)
values ('P012','Pa�uelos de pi�a','')
go

insert into Producto (Codigo,Nombre,Imagen)
values ('P013','Pudin','')
go

insert into Producto (Codigo,Nombre,Imagen)
values ('P014','Queque de chocolate','')
go

insert into Producto (Codigo,Nombre,Imagen)
values ('P015','Semita de arroz','')
go

insert into Producto (Codigo,Nombre,Imagen)
values ('P016','Cachos','')
go

insert into Producto (Codigo,Nombre,Imagen)
values ('P017','Dona','')
go

insert into Producto (Codigo,Nombre,Imagen)
values ('P018','Galleta de avena','')
go

insert into Producto (Codigo,Nombre,Imagen)
values ('P019','Pan integral','')
go

insert into Producto (Codigo,Nombre,Imagen)
values ('P020','Pastel de limon','')
go

/*
Select * from Producto
go
*/

-------------------------------------------------------------------------------------------

insert into Inventario_productos(IdProducto,Fecha_vencimiento,
StocK_inicial,Stock_actual,Precio) 
values (1,'28-03-2019',39,23,23) 
go

insert into Inventario_productos(IdProducto,Fecha_vencimiento,
StocK_inicial,Stock_actual,Precio) 
values (2,'12-03-2019',50,43,13) 
go

insert into Inventario_productos(IdProducto,Fecha_vencimiento,
StocK_inicial,Stock_actual,Precio) 
values (3,'08-03-2019',79,60,15) 
go

insert into Inventario_productos(IdProducto,Fecha_vencimiento,
StocK_inicial,Stock_actual,Precio) 
values (4,'21-03-2019',68,52,17) 
go

insert into Inventario_productos(IdProducto,Fecha_vencimiento,
StocK_inicial,Stock_actual,Precio) 
values (5,'29-04-2019',92,80,19) 
go

insert into Inventario_productos(IdProducto,Fecha_vencimiento,
StocK_inicial,Stock_actual,Precio) 
values (6,'09-05-2019',39,23,23) 
go

insert into Inventario_productos(IdProducto,Fecha_vencimiento,
StocK_inicial,Stock_actual,Precio) 
values (7,'13-09-2019',50,43,13) 
go

insert into Inventario_productos(IdProducto,Fecha_vencimiento,
StocK_inicial,Stock_actual,Precio) 
values (8,'20-03-2019',79,60,15) 
go

insert into Inventario_productos(IdProducto,Fecha_vencimiento,
StocK_inicial,Stock_actual,Precio) 
values (9,'21-01-2019',68,52,17) 
go

insert into Inventario_productos(IdProducto,Fecha_vencimiento,
StocK_inicial,Stock_actual,Precio) 
values (10,'29-11-2019',92,80,19) 
go

insert into Inventario_productos(IdProducto,Fecha_vencimiento,
StocK_inicial,Stock_actual,Precio) 
values (11,'28-03-2019',39,23,23) 
go

insert into Inventario_productos(IdProducto,Fecha_vencimiento,
StocK_inicial,Stock_actual,Precio) 
values (12,'12-04-2019',50,43,13) 
go

insert into Inventario_productos(IdProducto,Fecha_vencimiento,
StocK_inicial,Stock_actual,Precio) 
values (13,'8-06-2019',79,60,15) 
go

insert into Inventario_productos(IdProducto,Fecha_vencimiento,
StocK_inicial,Stock_actual,Precio) 
values (14,'21-01-2019',68,52,17) 
go

insert into Inventario_productos(IdProducto,Fecha_vencimiento,
StocK_inicial,Stock_actual,Precio) 
values (15,'29-11-2019',92,80,19) 
go

insert into Inventario_productos(IdProducto,Fecha_vencimiento,
StocK_inicial,Stock_actual,Precio) 
values (16,'28-03-2019',39,23,23) 
go

insert into Inventario_productos(IdProducto,Fecha_vencimiento,
StocK_inicial,Stock_actual,Precio) 
values (17,'12-04-2019',50,43,13) 
go

insert into Inventario_productos(IdProducto,Fecha_vencimiento,
StocK_inicial,Stock_actual,Precio) 
values (18,'8-06-2019',79,60,15) 
go

insert into Inventario_productos(IdProducto,Fecha_vencimiento,
StocK_inicial,Stock_actual,Precio) 
values (19,'21-01-2019',68,52,17) 
go

insert into Inventario_productos(IdProducto,Fecha_vencimiento,
StocK_inicial,Stock_actual,Precio) 
values (20,'29-11-2019',92,80,19) 
go


/*
select inv.IdInventario, pr.Idproducto, pr.Codigo, pr.Nombre,inv.Fecha_vencimiento,
inv.StocK_inicial,inv.Stock_actual, inv.Precio 
from Inventario_productos inv inner join Producto pr
on inv.IdProducto = pr.Idproducto 
*/

------------------------------------------------------------------

insert into Venta(Idempleado, Fecha)
values (1,'01-01-2019')
go

insert into Venta(Idempleado, Fecha)
values (1,'01-01-2019')
go

insert into Venta(Idempleado, Fecha)
values (1,'01-01-2019')
go

insert into Venta(Idempleado, Fecha)
values (1,'03-01-2019')
go

insert into Venta(Idempleado, Fecha)
values (1,'03-01-2019')
go

insert into Venta(Idempleado, Fecha)
values (1,'09-01-2019')
go

insert into Venta(Idempleado, Fecha)
values (1,'15-01-2019')
go

insert into Venta(Idempleado, Fecha)
values (1,'18-01-2019')
go

insert into Venta(Idempleado, Fecha)
values (1,'24-01-2019')
go

insert into Venta(Idempleado, Fecha)
values (1,'29-01-2019')
go

insert into Venta(Idempleado, Fecha)
values (1,'03-02-2019')
go

insert into Venta(Idempleado, Fecha)
values (1,'03-02-2019')
go

insert into Venta(Idempleado, Fecha)
values (1,'03-02-2019')
go

insert into Venta(Idempleado, Fecha)
values (1,'06-02-2019')
go

insert into Venta(Idempleado, Fecha)
values (1,'07-02-2019')
go

insert into Venta(Idempleado, Fecha)
values (1,'07-02-2019')
go

insert into Venta(Idempleado, Fecha)
values (1,'07-02-2019')
go

insert into Venta(Idempleado, Fecha)
values (1,'15-02-2019')
go

insert into Venta(Idempleado, Fecha)
values (1,'18-02-2019')
go

insert into Venta(Idempleado, Fecha)
values (1,'18-02-2019')
go

insert into Venta(Idempleado, Fecha)
values (1,'19-02-2019')
go

insert into Venta(Idempleado, Fecha)
values (1,'20-02-2019')
go

insert into Venta(Idempleado, Fecha)
values (1,'22-02-2019')
go

insert into Venta(Idempleado, Fecha)
values (1,'22-02-2019')
go

insert into Venta(Idempleado, Fecha)
values (1,'27-02-2019')
go

insert into Venta(Idempleado, Fecha)
values (1,'01-03-2019')
go

insert into Venta(Idempleado, Fecha)
values (1,'01-03-2019')
go

insert into Venta(Idempleado, Fecha)
values (1,'01-03-2019')
go

insert into Venta(Idempleado, Fecha)
values (1,'05-03-2019')
go

insert into Venta(Idempleado, Fecha)
values (1,'05-03-2019')
go

insert into Venta(Idempleado, Fecha)
values (1,'05-03-2019')
go

insert into Venta(Idempleado, Fecha)
values (1,'05-03-2019')
go

insert into Venta(Idempleado, Fecha)
values (1,'06-03-2019')
go

insert into Venta(Idempleado, Fecha)
values (1,'09-03-2019')
go

insert into Venta(Idempleado, Fecha)
values (1,'09-03-2019')
go

insert into Venta(Idempleado, Fecha)
values (1,'09-03-2019')
go

insert into Venta(Idempleado, Fecha)
values (1,'09-03-2019')
go

insert into Venta(Idempleado, Fecha)
values (1,'09-03-2019')
go

insert into Venta(Idempleado, Fecha)
values (1,'11-03-2019')
go

insert into Venta(Idempleado, Fecha)
values (1,'11-03-2019')
go

insert into Venta(Idempleado, Fecha)
values (1,'18-03-2019')
go

insert into Venta(Idempleado, Fecha)
values (1,'18-03-2019')
go

insert into Venta(Idempleado, Fecha)
values (1,'21-03-2019')
go

insert into Venta(Idempleado, Fecha)
values (1,'21-03-2019')
go

insert into Venta(Idempleado, Fecha)
values (1,'21-03-2019')
go

insert into Venta(Idempleado, Fecha)
values (1,'21-03-2019')
go

insert into Venta(Idempleado, Fecha)
values (1,'21-03-2019')
go

insert into Venta(Idempleado, Fecha)
values (1,'21-03-2019')
go

insert into Venta(Idempleado, Fecha)
values (1,'25-03-2019')
go

insert into Venta(Idempleado, Fecha)
values (1,'25-03-2019')
go

insert into Venta(Idempleado, Fecha)
values (1,'25-03-2019')
go

insert into Venta(Idempleado, Fecha)
values (1,'25-03-2019')
go

insert into Venta(Idempleado, Fecha)
values (1,'26-03-2019')
go

insert into Venta(Idempleado, Fecha)
values (1,'26-03-2019')
go

insert into Venta(Idempleado, Fecha)
values (1,'26-03-2019')
go

insert into Venta(Idempleado, Fecha)
values (1,'26-03-2019')
go

insert into Venta(Idempleado, Fecha)
values (1,'28-03-2019')
go

insert into Venta(Idempleado, Fecha)
values (1,'28-03-2019')
go

/*
select * from Venta
go
*/

---------------------------------------------------------------------

insert into DetalleVenta(Idventa,IdInventario,Cantidad)
values (1,1,15)
go

insert into DetalleVenta(Idventa,IdInventario,Cantidad)
values (1,3,3)
go

insert into DetalleVenta(Idventa,IdInventario,Cantidad)
values (1,5,16)
go

insert into DetalleVenta(Idventa,IdInventario,Cantidad)
values (1,2,12)
go

insert into DetalleVenta(Idventa,IdInventario,Cantidad)
values (1,6,8)
go

insert into DetalleVenta(Idventa,IdInventario,Cantidad)
values (2,13,8)
go

insert into DetalleVenta(Idventa,IdInventario,Cantidad)
values (2,17,3)
go

insert into DetalleVenta(Idventa,IdInventario,Cantidad)
values (2,12,14)
go

insert into DetalleVenta(Idventa,IdInventario,Cantidad)
values (2,15,14)
go

insert into DetalleVenta(Idventa,IdInventario,Cantidad)
values (2,9,15)
go

insert into DetalleVenta(Idventa,IdInventario,Cantidad)
values (3,3,3)
go

insert into DetalleVenta(Idventa,IdInventario,Cantidad)
values (3,5,16)
go

insert into DetalleVenta(Idventa,IdInventario,Cantidad)
values (3,20,12)
go

insert into DetalleVenta(Idventa,IdInventario,Cantidad)
values (3,8,8)
go

insert into DetalleVenta(Idventa,IdInventario,Cantidad)
values (3,18,8)
go

insert into DetalleVenta(Idventa,IdInventario,Cantidad)
values (3,17,3)
go

insert into DetalleVenta(Idventa,IdInventario,Cantidad)
values (3,6,14)
go

insert into DetalleVenta(Idventa,IdInventario,Cantidad)
values (4,2,14)
go

insert into DetalleVenta(Idventa,IdInventario,Cantidad)
values (4,5,15)
go

insert into DetalleVenta(Idventa,IdInventario,Cantidad)
values (4,9,3)
go

insert into DetalleVenta(Idventa,IdInventario,Cantidad)
values (4,10,16)
go

insert into DetalleVenta(Idventa,IdInventario,Cantidad)
values (4,12,12)
go

insert into DetalleVenta(Idventa,IdInventario,Cantidad)
values (5,4,8)
go

insert into DetalleVenta(Idventa,IdInventario,Cantidad)
values (5,12,8)
go

insert into DetalleVenta(Idventa,IdInventario,Cantidad)
values (5,15,3)
go

insert into DetalleVenta(Idventa,IdInventario,Cantidad)
values (6,13,14)
go

insert into DetalleVenta(Idventa,IdInventario,Cantidad)
values (6,19,14)
go

insert into DetalleVenta(Idventa,IdInventario,Cantidad)
values (6,18,15)
go

insert into DetalleVenta(Idventa,IdInventario,Cantidad)
values (6,13,3)
go

insert into DetalleVenta(Idventa,IdInventario,Cantidad)
values (7,11,16)
go

insert into DetalleVenta(Idventa,IdInventario,Cantidad)
values (7,4,12)
go

insert into DetalleVenta(Idventa,IdInventario,Cantidad)
values (7,5,8)
go

insert into DetalleVenta(Idventa,IdInventario,Cantidad)
values (8,8,8)
go

insert into DetalleVenta(Idventa,IdInventario,Cantidad)
values (8,17,3)
go

insert into DetalleVenta(Idventa,IdInventario,Cantidad)
values (8,4,14)
go

insert into DetalleVenta(Idventa,IdInventario,Cantidad)
values (8,1,14)
go

insert into DetalleVenta(Idventa,IdInventario,Cantidad)
values (8,3,15)
go

insert into DetalleVenta(Idventa,IdInventario,Cantidad)
values (8,9,3)
go

insert into DetalleVenta(Idventa,IdInventario,Cantidad)
values (9,19,16)
go

insert into DetalleVenta(Idventa,IdInventario,Cantidad)
values (9,17,12)
go

insert into DetalleVenta(Idventa,IdInventario,Cantidad)
values (9,3,8)
go

insert into DetalleVenta(Idventa,IdInventario,Cantidad)
values (9,15,8)
go

insert into DetalleVenta(Idventa,IdInventario,Cantidad)
values (9,16,3)
go

insert into DetalleVenta(Idventa,IdInventario,Cantidad)
values (10,4,14)
go

insert into DetalleVenta(Idventa,IdInventario,Cantidad)
values (10,5,14)
go

insert into DetalleVenta(Idventa,IdInventario,Cantidad)
values (10,4,15)
go

insert into DetalleVenta(Idventa,IdInventario,Cantidad)
values (10,9,3)
go

insert into DetalleVenta(Idventa,IdInventario,Cantidad)
values (11,5,16)
go

insert into DetalleVenta(Idventa,IdInventario,Cantidad)
values (11,13,12)
go

insert into DetalleVenta(Idventa,IdInventario,Cantidad)
values (11,18,8)
go

insert into DetalleVenta(Idventa,IdInventario,Cantidad)
values (11,14,8)
go

insert into DetalleVenta(Idventa,IdInventario,Cantidad)
values (11,15,3)
go

insert into DetalleVenta(Idventa,IdInventario,Cantidad)
values (11,20,14)
go

insert into DetalleVenta(Idventa,IdInventario,Cantidad)
values (12,5,14)
go

insert into DetalleVenta(Idventa,IdInventario,Cantidad)
values (13,1,15)
go

insert into DetalleVenta(Idventa,IdInventario,Cantidad)
values (13,9,3)
go

insert into DetalleVenta(Idventa,IdInventario,Cantidad)
values (14,5,16)
go

insert into DetalleVenta(Idventa,IdInventario,Cantidad)
values (14,2,12)
go

insert into DetalleVenta(Idventa,IdInventario,Cantidad)
values (14,8,8)
go

insert into DetalleVenta(Idventa,IdInventario,Cantidad)
values (14,12,8)
go

insert into DetalleVenta(Idventa,IdInventario,Cantidad)
values (15,18,3)
go

insert into DetalleVenta(Idventa,IdInventario,Cantidad)
values (15,17,14)
go

insert into DetalleVenta(Idventa,IdInventario,Cantidad)
values (15,19,14)
go

insert into DetalleVenta(Idventa,IdInventario,Cantidad)
values (16,14,15)
go

insert into DetalleVenta(Idventa,IdInventario,Cantidad)
values (16,3,7)
go

insert into DetalleVenta(Idventa,IdInventario,Cantidad)
values (16,12,16)
go

insert into DetalleVenta(Idventa,IdInventario,Cantidad)
values (17,7,12)
go

insert into DetalleVenta(Idventa,IdInventario,Cantidad)
values (17,5,8)
go

insert into DetalleVenta(Idventa,IdInventario,Cantidad)
values (17,4,8)
go

insert into DetalleVenta(Idventa,IdInventario,Cantidad)
values (17,2,3)
go

insert into DetalleVenta(Idventa,IdInventario,Cantidad)
values (18,18,14)
go

insert into DetalleVenta(Idventa,IdInventario,Cantidad)
values (18,5,14)
go

insert into DetalleVenta(Idventa,IdInventario,Cantidad)
values (19,1,15)
go

insert into DetalleVenta(Idventa,IdInventario,Cantidad)
values (19,6,3)
go

insert into DetalleVenta(Idventa,IdInventario,Cantidad)
values (19,5,16)
go

insert into DetalleVenta(Idventa,IdInventario,Cantidad)
values (19,2,12)
go

insert into DetalleVenta(Idventa,IdInventario,Cantidad)
values (20,9,8)
go

insert into DetalleVenta(Idventa,IdInventario,Cantidad)
values (20,19,8)
go

insert into DetalleVenta(Idventa,IdInventario,Cantidad)
values (20,17,3)
go

insert into DetalleVenta(Idventa,IdInventario,Cantidad)
values (20,4,14)
go

insert into DetalleVenta(Idventa,IdInventario,Cantidad)
values (21,5,14)
go

insert into DetalleVenta(Idventa,IdInventario,Cantidad)
values (21,1,15)
go

insert into DetalleVenta(Idventa,IdInventario,Cantidad)
values (21,20,3)
go

insert into DetalleVenta(Idventa,IdInventario,Cantidad)
values (22,5,16)
go

insert into DetalleVenta(Idventa,IdInventario,Cantidad)
values (22,2,12)
go

insert into DetalleVenta(Idventa,IdInventario,Cantidad)
values (23,5,8)
go

insert into DetalleVenta(Idventa,IdInventario,Cantidad)
values (23,1,8)
go

insert into DetalleVenta(Idventa,IdInventario,Cantidad)
values (23,2,3)
go

insert into DetalleVenta(Idventa,IdInventario,Cantidad)
values (23,4,14)
go

insert into DetalleVenta(Idventa,IdInventario,Cantidad)
values (24,5,14)
go

insert into DetalleVenta(Idventa,IdInventario,Cantidad)
values (24,1,15)
go

insert into DetalleVenta(Idventa,IdInventario,Cantidad)
values (25,3,3)
go

insert into DetalleVenta(Idventa,IdInventario,Cantidad)
values (25,5,16)
go

insert into DetalleVenta(Idventa,IdInventario,Cantidad)
values (25,8,12)
go

insert into DetalleVenta(Idventa,IdInventario,Cantidad)
values (25,15,8)
go

insert into DetalleVenta(Idventa,IdInventario,Cantidad)
values (25,1,8)
go

insert into DetalleVenta(Idventa,IdInventario,Cantidad)
values (26,2,3)
go

insert into DetalleVenta(Idventa,IdInventario,Cantidad)
values (26,4,14)
go

insert into DetalleVenta(Idventa,IdInventario,Cantidad)
values (26,8,14)
go

insert into DetalleVenta(Idventa,IdInventario,Cantidad)
values (26,20,15)
go

insert into DetalleVenta(Idventa,IdInventario,Cantidad)
values (26,11,3)
go

insert into DetalleVenta(Idventa,IdInventario,Cantidad)
values (27,5,16)
go

insert into DetalleVenta(Idventa,IdInventario,Cantidad)
values (27,2,12)
go

insert into DetalleVenta(Idventa,IdInventario,Cantidad)
values (27,16,8)
go

insert into DetalleVenta(Idventa,IdInventario,Cantidad)
values (28,6,8)
go

insert into DetalleVenta(Idventa,IdInventario,Cantidad)
values (29,2,3)
go

insert into DetalleVenta(Idventa,IdInventario,Cantidad)
values (29,4,14)
go

insert into DetalleVenta(Idventa,IdInventario,Cantidad)
values (30,13,14)
go

insert into DetalleVenta(Idventa,IdInventario,Cantidad)
values (30,5,15)
go

insert into DetalleVenta(Idventa,IdInventario,Cantidad)
values (31,3,3)
go

insert into DetalleVenta(Idventa,IdInventario,Cantidad)
values (31,20,16)
go

insert into DetalleVenta(Idventa,IdInventario,Cantidad)
values (31,2,12)
go

insert into DetalleVenta(Idventa,IdInventario,Cantidad)
values (32,5,8)
go

insert into DetalleVenta(Idventa,IdInventario,Cantidad)
values (33,1,8)
go

insert into DetalleVenta(Idventa,IdInventario,Cantidad)
values (34,2,3)
go

insert into DetalleVenta(Idventa,IdInventario,Cantidad)
values (34,7,14)
go

insert into DetalleVenta(Idventa,IdInventario,Cantidad)
values (35,7,14)
go

insert into DetalleVenta(Idventa,IdInventario,Cantidad)
values (35,8,15)
go

insert into DetalleVenta(Idventa,IdInventario,Cantidad)
values (35,3,3)
go

insert into DetalleVenta(Idventa,IdInventario,Cantidad)
values (36,19,16)
go

insert into DetalleVenta(Idventa,IdInventario,Cantidad)
values (36,14,12)
go

insert into DetalleVenta(Idventa,IdInventario,Cantidad)
values (37,5,8)
go

insert into DetalleVenta(Idventa,IdInventario,Cantidad)
values (37,1,8)
go

insert into DetalleVenta(Idventa,IdInventario,Cantidad)
values (38,2,3)
go

insert into DetalleVenta(Idventa,IdInventario,Cantidad)
values (38,6,14)
go

insert into DetalleVenta(Idventa,IdInventario,Cantidad)
values (38,17,14)
go

insert into DetalleVenta(Idventa,IdInventario,Cantidad)
values (39,18,15)
go

insert into DetalleVenta(Idventa,IdInventario,Cantidad)
values (39,11,3)
go

insert into DetalleVenta(Idventa,IdInventario,Cantidad)
values (39,12,16)
go

insert into DetalleVenta(Idventa,IdInventario,Cantidad)
values (40,2,12)
go

insert into DetalleVenta(Idventa,IdInventario,Cantidad)
values (40,5,8)
go

insert into DetalleVenta(Idventa,IdInventario,Cantidad)
values (40,7,8)
go

insert into DetalleVenta(Idventa,IdInventario,Cantidad)
values (41,3,3)
go

insert into DetalleVenta(Idventa,IdInventario,Cantidad)
values (41,2,14)
go

insert into DetalleVenta(Idventa,IdInventario,Cantidad)
values (41,6,14)
go

insert into DetalleVenta(Idventa,IdInventario,Cantidad)
values (42,18,15)
go

insert into DetalleVenta(Idventa,IdInventario,Cantidad)
values (42,14,3)
go

insert into DetalleVenta(Idventa,IdInventario,Cantidad)
values (42,13,16)
go

insert into DetalleVenta(Idventa,IdInventario,Cantidad)
values (44,11,12)
go

insert into DetalleVenta(Idventa,IdInventario,Cantidad)
values (45,5,8)
go

insert into DetalleVenta(Idventa,IdInventario,Cantidad)
values (46,16,8)
go

insert into DetalleVenta(Idventa,IdInventario,Cantidad)
values (46,9,3)
go

insert into DetalleVenta(Idventa,IdInventario,Cantidad)
values (46,2,14)
go

insert into DetalleVenta(Idventa,IdInventario,Cantidad)
values (47,5,14)
go

insert into DetalleVenta(Idventa,IdInventario,Cantidad)
values (47,7,15)
go

insert into DetalleVenta(Idventa,IdInventario,Cantidad)
values (47,4,3)
go

insert into DetalleVenta(Idventa,IdInventario,Cantidad)
values (48,20,16)
go

insert into DetalleVenta(Idventa,IdInventario,Cantidad)
values (48,5,12)
go

insert into DetalleVenta(Idventa,IdInventario,Cantidad)
values (49,3,8)
go

insert into DetalleVenta(Idventa,IdInventario,Cantidad)
values (50,3,8)
go

insert into DetalleVenta(Idventa,IdInventario,Cantidad)
values (50,16,3)
go

insert into DetalleVenta(Idventa,IdInventario,Cantidad)
values (51,17,14)
go

insert into DetalleVenta(Idventa,IdInventario,Cantidad)
values (51,18,14)
go

insert into DetalleVenta(Idventa,IdInventario,Cantidad)
values (51,14,15)
go

insert into DetalleVenta(Idventa,IdInventario,Cantidad)
values (52,13,3)
go

insert into DetalleVenta(Idventa,IdInventario,Cantidad)
values (52,5,16)
go

insert into DetalleVenta(Idventa,IdInventario,Cantidad)
values (52,13,12)
go

insert into DetalleVenta(Idventa,IdInventario,Cantidad)
values (53,8,8)
go

insert into DetalleVenta(Idventa,IdInventario,Cantidad)
values (53,19,8)
go

insert into DetalleVenta(Idventa,IdInventario,Cantidad)
values (54,11,3)
go

insert into DetalleVenta(Idventa,IdInventario,Cantidad)
values (55,4,14)
go

insert into DetalleVenta(Idventa,IdInventario,Cantidad)
values (55,1,14)
go

insert into DetalleVenta(Idventa,IdInventario,Cantidad)
values (55,8,15)
go

insert into DetalleVenta(Idventa,IdInventario,Cantidad)
values (55,15,3)
go

insert into DetalleVenta(Idventa,IdInventario,Cantidad)
values (56,7,16)
go

insert into DetalleVenta(Idventa,IdInventario,Cantidad)
values (56,4,12)
go

insert into DetalleVenta(Idventa,IdInventario,Cantidad)
values (57,20,8)
go

insert into DetalleVenta(Idventa,IdInventario,Cantidad)
values (57,11,8)
go

insert into DetalleVenta(Idventa,IdInventario,Cantidad)
values (58,2,3)
go

insert into DetalleVenta(Idventa,IdInventario,Cantidad)
values (58,16,14)
go

insert into DetalleVenta(Idventa,IdInventario,Cantidad)
values (58,12,14)
go

/*
select * from Detalleventa
*/

---------------------------------------------------------------------


insert into L4Lproducto(IdInventario,C,s,i)
values (1,12,48,0.5)
go

insert into L4Lproducto(IdInventario,C,s,i)
values (2,9,27,0.9)
go

insert into L4Lproducto(IdInventario,C,s,i)
values (3,16,55,0.6)
go

insert into L4Lproducto(IdInventario,C,s,i)
values (4,17,39,0.2)
go

insert into L4Lproducto(IdInventario,C,s,i)
values (5,19,47,0.3)
go

insert into L4Lproducto(IdInventario,C,s,i)
values (6,12,35,0.6)
go

insert into L4Lproducto(IdInventario,C,s,i)
values (7,10,47,0.5)
go

insert into L4Lproducto(IdInventario,C,s,i)
values (8,12,32,0.4)
go

insert into L4Lproducto(IdInventario,C,s,i)
values (9,18,58,0.4)
go

insert into L4Lproducto(IdInventario,C,s,i)
values (10,11,32,0.3)
go

insert into L4Lproducto(IdInventario,C,s,i)
values (11,12,48,0.5)
go

insert into L4Lproducto(IdInventario,C,s,i)
values (12,8,41,0.6)
go

insert into L4Lproducto(IdInventario,C,s,i)
values (13,14,44,0.4)
go

insert into L4Lproducto(IdInventario,C,s,i)
values (14,16,53,0.2)
go

insert into L4Lproducto(IdInventario,C,s,i)
values (15,13,50,0.7)
go

insert into L4Lproducto(IdInventario,C,s,i)
values (16,10,38,0.2)
go

insert into L4Lproducto(IdInventario,C,s,i)
values (17,8,32,0.3)
go

insert into L4Lproducto(IdInventario,C,s,i)
values (18,11,49,0.4)
go

insert into L4Lproducto(IdInventario,C,s,i)
values (19,15,52,0.6)
go

insert into L4Lproducto(IdInventario,C,s,i)
values (20,13,35,0.1)
go

/*
select dt.IdDetalleventa,dt.idventa, pr.Nombre, vt.Fecha, dt.Cantidad,pr.Precio from 
DetalleVenta dt inner join Venta vt on dt.Idventa=vt.Idventa inner join Empleado em 
on vt.Idempleado = em.Idempleado inner join Producto pr on dt.IdInventario = pr.Idproducto
where dt.Idventa=2 and em.Idempleado =1
go
*/

-------------------------------------------------------------------

/*
select dt.idventa, vt.fecha, sum(dt.Cantidad) as Cantidad, sum(dt.Cantidad*inp.Precio) from
DetalleVenta dt inner join Venta vt on dt.Idventa= vt.Idventa
inner join Empleado em on vt.Idempleado= em.Idempleado
inner join Inventario_productos inp on dt.IdInventario = inp.IdInventario
inner join Producto pr on inp.IdProducto = pr.Idproducto
where dt.Idventa=vt.Idventa and vt.Idempleado=1
group by dt.Idventa,vt.fecha
*/

---------------------------------------------------------------------

/*
select ordtt.IdInventario, ordtt.cantidad,month(ord.Fecha) from Venta ord 
inner join DetalleVenta ordtt on ord.Idventa  = ordtt.Idventa
inner join Producto pr on ordtt.IdInventario=pr.Idproducto
where month(ord.Fecha)  = month(ord.Fecha)
order by ordtt.IdInventario asc
go

select  count (distinct(month(ord.Fecha))) from Venta ord 
inner join DetalleVenta ordtt on ord.Idventa  = ordtt.Idventa
inner join Producto pr on ordtt.IdInventario=pr.Idproducto
where month(ord.Fecha)  = month(ord.Fecha) and ordtt.IdInventario=5
go

select  sum(ordtt.Cantidad),year(ord.Fecha), count (distinct(year(ord.Fecha))) from Venta ord 
inner join DetalleVenta ordtt on ord.Idventa  = ordtt.Idventa
inner join Producto pr on ordtt.IdInventario=pr.Idproducto
where year(ord.Fecha)  = year(ord.Fecha) and ordtt.IdInventario=5
group by year(ord.Fecha)
go
*/

--select  count(distinct(datepart(wk,ord.Fecha))) from Venta ord 
--inner join DetalleVenta ordtt on ord.Idventa  = ordtt.Idventa
--inner join Producto pr on ordtt.IdInventario=pr.Idproducto
--where datepart(wk,ord.Fecha)  = datepart(wk,ord.Fecha) and ordtt.IdInventario=5
--go

-----------------------------------------------------------------------------------

insert into Producto_necesidad(IdProducto) values (1)
go

insert into Producto_necesidad(IdProducto) values (5)
go

insert into Producto_detalle(Idprnc,IdMateriales,Cantidad) 
values (1,1,3)
go

insert into Producto_detalle(Idprnc,IdMateriales,Cantidad) 
values (1,2,6)
go

insert into Producto_detalle(Idprnc,IdMateriales,Cantidad) 
values (2,2,4)
go

select ordtt.IdInventario,pr.Nombre, mt.Nombre,
prdt.Cantidad, sum(ordtt.Cantidad)*(prdt.Cantidad) as Demanda from Venta ord 
inner join DetalleVenta ordtt on ord.Idventa  = ordtt.Idventa
inner join Producto pr on ordtt.IdInventario=pr.Idproducto
inner join Producto_necesidad prnc on prnc.IdProducto = pr.Idproducto
inner join Producto_detalle prdt on prdt.Idprnc = prnc.Idprnc
inner join Materiales mt on mt.IdMateriales = prdt.IdMateriales
inner join Inventario_materiales mtin on mtin.IdMateriales = mt.IdMateriales
where datepart(wk,ord.Fecha)  = datepart(wk,ord.Fecha) and ordtt.IdInventario=5
group by ordtt.IdInventario, pr.Nombre, mt.Nombre, prdt.Cantidad
go
