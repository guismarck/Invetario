Use Producci�n;
go

---------------------------------------------------------------------
--INSERCI�N DE EMPLEADO
---------------------------------------------------------------------

insert into Empleado(Nombre,Apellido,Edad,Cedula,correo,Celular,usuario,Pass, lastUpdate)
values('Eduardo','Rivas',23,'wh23','rivas@gmail',82345678,'eduardo09','12345', getDate())
go
---------------------------------------------------------------------
--INSERCI�N DE PROVEEDOR
---------------------------------------------------------------------

insert into Proveedor(Nombre,Direcci�n,Correo_Electronico,Telefono)
values('Cainsa','Km 8 carretera norte','cainsa@gmail',22342178)
go

insert into Proveedor(Nombre,Direcci�n,Correo_Electronico,Telefono)
values('Parmalat','Km 9 carretera norte','parmalat@gmail',23452149)
go

insert into Proveedor(Nombre,Direcci�n,Correo_Electronico,Telefono)
values('Monisa','Km 10 carretera norte','Monisa@gmail',23487654)
go

---------------------------------------------------------------------
--INSERCI�N DE MATERIALES
---------------------------------------------------------------------

insert into Materiales(Codigo,Nombre,Descripcion,Tipo,Imagen,Estado)
values('P001','Leche','Uso para pastel','Lacteo','','Existencia')
go

insert into Materiales(Codigo,Nombre,Descripcion,Tipo,Imagen,Estado)
values('P002','Masa','Uso para pan','Lacteo','','Existencia')
go

---------------------------------------------------------------------
--INSERCI�N DE INVENTARIO DE MATERIALES
---------------------------------------------------------------------

insert into Inventario_materiales(IdProveedor,IdMateriales,Fecha_vencimiento,
StocK_inicial,Stock_actual,Unidad_medida,Precio)
values(2,2,'09-12-2020',34.4,20.4,'Kg',23.3)
go

insert into Inventario_materiales(IdProveedor,IdMateriales,Fecha_vencimiento,
StocK_inicial,Stock_actual,Unidad_medida,Precio)
values(2,1,'03-28-2021',28,15,'Lt',15.3)
go
---------------------------------------------------------------------
--INSERCI�N DE PRODUCTOS
---------------------------------------------------------------------

insert into Producto (Codigo,Nombre,Imagen)
values ('P001','Pico con queso','')
go

insert into Producto (Codigo,Nombre,Imagen)
values ('P002','Manjar','')
go

insert into Producto (Codigo,Nombre,Imagen)
values ('P003','Pan tostado','')
go

insert into Producto (Codigo,Nombre,Imagen)
values ('P004','Bolillo','')
go

insert into Producto (Codigo,Nombre,Imagen)
values ('P005','Polboron','')
go

insert into Producto (Codigo,Nombre,Imagen)
values ('P006','Pan simple','')
go

---------------------------------------------------------------------
--INSERCI�N DE INVENTARIO DE PRODUCTOS
---------------------------------------------------------------------
insert into Inventario_productos(IdProducto,Fecha_vencimiento,
StocK_inicial,Stock_actual,Precio) 
values (1,'03-28-2019',39,23,23) 
go

insert into Inventario_productos(IdProducto,Fecha_vencimiento,
StocK_inicial,Stock_actual,Precio) 
values (2,'12-04-2020',50,43,13) 
go

insert into Inventario_productos(IdProducto,Fecha_vencimiento,
StocK_inicial,Stock_actual,Precio) 
values (3,'8-06-2021',79,60,15) 
go

insert into Inventario_productos(IdProducto,Fecha_vencimiento,
StocK_inicial,Stock_actual,Precio) 
values (4,'01-21-2021',68,52,17) 
go

insert into Inventario_productos(IdProducto,Fecha_vencimiento,
StocK_inicial,Stock_actual,Precio) 
values (5,'11-29-2022',92,80,19) 

Go
insert into Inventario_productos(IdProducto,Fecha_vencimiento,
StocK_inicial,Stock_actual,Precio) 
values (6,'07-01-2019',10,40,15) 

Go
---------------------------------------------------------------------
--INSERCI�N DE LOS MATERIALES NECESARIOS PARA LOS PRODUCTOS
----------------------------------------------------------------------
Insert into Producto_Material Values(1,2, 2);
Insert into Producto_Material Values(2,2, 3);
Insert into Producto_Material Values(3,2, 1);
Insert into Producto_Material Values(4,2, 1);
Insert into Producto_Material Values(5,1, 1);
Insert into Producto_Material Values(5,2, 2);
Insert into Producto_Material Values(6,2, 1);

---------------------------------------------------------------------
--INSERCI�N DE LAS VENTAS
----------------------------------------------------------------------

insert into Venta(Idempleado, Fecha)
values (1,'03-28-2019')
go

insert into Venta(Idempleado, Fecha)
values (1,'03-29-2019')
go

insert into Venta(Idempleado, Fecha)
values (1,'01-04-2019')
go

insert into Venta(Idempleado, Fecha)
values (1,'21-06-2019')
go

insert into Venta(Idempleado, Fecha)
values (1,'2019-06-21')
go

---------------------------------------------------------------------
--INSERCI�N DEL DETALLE DE VENTAS
---------------------------------------------------------------------

insert into DetalleVenta(Idventa,IdInventario,Cantidad,Precio)
values (1,1,15,23)
go

insert into DetalleVenta(Idventa,IdInventario,Cantidad,Precio)
values (1,3,3,15)
go

insert into DetalleVenta(Idventa,IdInventario,Cantidad,Precio)
values (1,5,16,19)
go

insert into DetalleVenta(Idventa,IdInventario,Cantidad,Precio)
values (2,2,12,13)
go

insert into DetalleVenta(Idventa,IdInventario,Cantidad,Precio)
values (2,5,8,19)
go

insert into DetalleVenta(Idventa,IdInventario,Cantidad,Precio)
values (3,1,8,23)
go

insert into DetalleVenta(Idventa,IdInventario,Cantidad,Precio)
values (3,2,3,13)
go

insert into DetalleVenta(Idventa,IdInventario,Cantidad,Precio)
values (3,4,14,17)
go

insert into DetalleVenta(Idventa,IdInventario,Cantidad,Precio)
values (3,5,14,19)
go

insert into DetalleVenta(Idventa,IdInventario,Cantidad,Precio)
values (4,6,05,15)
go

insert into DetalleVenta(Idventa,IdInventario,Cantidad,Precio)
values (6,6,03,15)
go
---------------------------------------------------------------------
--INSERCI�N COMPRAS
---------------------------------------------------------------------
Insert Into Compra Values(2, '2019-01-04'), (2, '2019-01-03');
Go
---------------------------------------------------------------------
--INSERCI�N DEL DETALLE DE COMPRA
---------------------------------------------------------------------
insert into Detalle_Compra Values (1, 1, 34.40), (1, 2, 15.5), (2, 2, 28.00)

---------------------------------------------------------------------
--Inserciones en el detalle de los materiales
insert  into ModeloQ values(1,1.0, 1.0, 0.05, 1);
insert  into ModeloQ values(2,1.5, 5.0, 0.1, 3);
---------------------------------------------------------------------
