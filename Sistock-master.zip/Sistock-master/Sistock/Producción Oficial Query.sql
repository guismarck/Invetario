use Master;

if exists(select * from sysdatabases where name = 'Producci�n')
Drop database Producci�n;
Go 
Create database Producci�n
Go
use Producci�n
Go

Create table Proveedor(
IdProveedor int identity(1,1) primary key not null,
Nombre nvarchar(25) not null,
Direcci�n nvarchar(120),
Correo_Electronico nvarchar(25),
Telefono int
)
Go

Create table Materiales(
IdMateriales int identity(1,1) primary key not null,
Codigo nvarchar(29) not null,
Nombre nvarchar(25) not null,
Descripcion nvarchar(120) ,
Tipo nvarchar(20) not null,
Imagen image,
Estado nvarchar(20) not null
)
Go

Create table Inventario_materiales(
IdInventario int identity(1,1) primary key not null,
IdProveedor int foreign key references Proveedor(IdProveedor),
IdMateriales int foreign key references Materiales(IdMateriales),
Fecha_vencimiento date,
StocK_inicial decimal(7,2) not null,
Stock_actual decimal(7,2) not null,
Unidad_medida nvarchar(10) not null,
Precio decimal(7,2) not null
)
Go


Create table ModeloP(
IdMP int identity(1,1) primary key not null,
IdInventario int foreign key references Inventario_productos(IdInventario),
Inventarioactual decimal(7,2) not null,
Fecha date,
Nivelservicio decimal(7,2) not null,
Tiemporevision int not null,
Tiempoentrega int not null,
Demanda int not null,
SS decimal(7,2) not null,
Q decimal(7,2) not null,
Tipo nvarchar(29) not null
)
Go

--Necesario para el modelo Q
/*TABLA QUE ALMACENA EL DETALLE DE PEDIDO DE PRODUCTOS*/
Create table ModeloQ(
IdDetalle int primary key not null identity(1,1),
IdMateria int foreign key references Materiales(IdMateriales),
--Demanda int  not null,
CostoPedir money not null,
CostoAlmacenar money not null,
--CostoProducto money not null,
TasaAlmacen float,
--StockSeguridad int,
PlazoEntrega int
)
go

Create table Empleado(
Idempleado int identity(1,1) primary key not null,
Nombre nvarchar(20) not null,
Apellido nvarchar(20) not null,
Edad int not null,
Cedula nvarchar(25) not null,
correo nvarchar(25),
Celular int,
usuario nvarchar(20) not null,
Pass nvarchar(20) not null,
lastUpdate date
)
Go

Create table Producto(
Idproducto int identity(1,1) primary key not null,
Codigo nvarchar(20) not null,
Nombre nvarchar(20) not null,
Imagen Image)
Go

Create table Inventario_productos(
IdInventario int identity(1,1) primary key not null,
IdProducto int foreign key references Producto(IdProducto),
Fecha_vencimiento date,
StocK_inicial decimal(7,2) not null,
Stock_actual decimal(7,2) not null,
Precio decimal(7,2) not null
)
Go

Create table Producto_Material(
IdProducto int references Producto(IdProducto) not null,
IdMaterial int references Materiales(IdMateriales) not null,
CantidadMaterial int not null
);
Go

Create table Venta(
Idventa int identity(1,1) primary key not null,
Idempleado int foreign key references Empleado(Idempleado),
Fecha date)
Go
/** ANTIGUA TABLA DE DETALLEVENTAS
Create table DetalleVenta(
IdDetalleventa int identity(1,1) primary key not null,
Idventa int foreign key references Venta(Idventa) not null,
Idproducto int foreign key references Producto(Idproducto) not null,
Cantidad int not null,
Precio decimal(7,2) not null
)**/

Create table DetalleVenta(
IdDetalleventa int identity(1,1) primary key not null,
Idventa int foreign key references Venta(Idventa) not null,
IdInventario int foreign key references Inventario_productos(IdInventario) not null,
Cantidad int not null,
Precio decimal(7,2) not null
)
Go

Create table Compra(
IdCompra int primary key identity(1,1),
IdProveedor int foreign key references Proveedor(IdProveedor) on delete set null,
Fecha_Compra date not null
)
Go

Create table Detalle_Compra(
IdDetalleCompra int primary key identity(1,1),
IdCompra int foreign key references Compra(IdCompra) not null,
IdMateriales int foreign key references Materiales(IdMateriales) not null,
Cantidad int
)
Go

Create table Devoluci�n_Compra(
IdDetalleCompra int foreign key references Detalle_Compra(IdDetalleCompra) on delete set null,
Cantidad int,
Detalle nvarchar(100),
Fecha_Compra date
)
Go

--------------------------------------------------------------------------------------------------
--USUARIOS DE LA BASE DE DATOS
--------------------------------------------------------------------------------------------------

-- Creacion del login
if not exists(select * from syslogins where name = 'Eduardo23') 
create login Eduardo23
with password = '1234',
default_database = Producci�n
go

--- creacion de usuario
if not exists (select * from sysusers where name = 'Eduardo23')
create user Eduardo23
for login Eduardo23
with default_schema=mi_esquema
go

--------------------------------------------------------------------------------------------------
--	ESQUEMA POR DEFECTO DE LA BASE DE DATOS
--------------------------------------------------------------------------------------------------
-- creacion de esquema

create schema mi_esquema authorization Eduardo23;
go

grant create proc,execute,create role,create table,select,insert,update,delete to Eduardo23;
go