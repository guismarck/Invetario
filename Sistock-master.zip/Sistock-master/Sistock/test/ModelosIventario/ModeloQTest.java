/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ModelosIventario;

import Inventario_Optiomo.ModeloQ;
import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author josue
 */
public class ModeloQTest {
    
    public ModeloQTest() {
    }
    
    private ModeloQ model1;
    
//    @Test
//    public void Pruebas1(){
//        model1 = new ModeloQ(18000, 400, 1.20);
//        //Q Optimo
//        assertEquals(3465, model1.getQOptimo("ceil"), 0.01);
//        //Costo total anual
//        assertEquals(22156.92208, model1.costoTotal(1, "ceil"), 0.01);
//        //Costo total anual
//        assertEquals(5.2, model1.getNoPedidos("ceil"), 0.01);
//        //Tiempos entre pedidos
//        assertEquals(0.19, model1.getTiempoEntrePedido("ceil"), 0.01);
//        
//    }    
//    
//    @Test
//    public void Pruebas2(){
//        model1 = new ModeloQ(1500000, 80);
//        //Q Optimo
//        assertEquals(30984, model1.getQOptimo(0.1,2.5, "ceil"), 0.09);
////        //Costo total anual
////        assertEquals(22156.92208, model1.costoTotal(0.1,2.5,  ""), 0.01);
//        //Número de pedidos al año
//        assertEquals(49, model1.getNoPedidos(0.1,2.5, "ceil"), 0.01);
//        //Tiempos entre pedidos
//        assertEquals(0.0206, model1.getTiempoEntrePedido(0.1,2.5, ""), 0.01);
//        //ROP
//        assertEquals(13333.33333, model1.getROP(360, 2, 5000), 0.01);
//        //Número promedio
//        assertEquals(17992, model1.getNivelPromedioInventario(0.1, 2.5, 5000, "ceil"), 1);
//    }  
//    
//    @Test
//    public void Pruebas3(){
//        model1 = new ModeloQ(1500000, 80);
//        //Q Optimo
//        assertEquals(30984, model1.getQOptimo(0.1,2.5, "ceil"), 0.09);
////        //Costo total anual
////        assertEquals(22156.92208, model1.costoTotal(0.1,2.5,  ""), 0.01);
//        //Número de pedidos al año
//        assertEquals(49, model1.getNoPedidos(0.1,2.5, "ceil"), 0.01);
//        //Tiempos entre pedidos
//        assertEquals(0.0206, model1.getTiempoEntrePedido(0.1,2.5, ""), 0.01);
//        //ROP
//        assertEquals(13333.33333, model1.getROP(360, 2, 5000), 0.01);
//        //Número promedio
//        assertEquals(17992, model1.getNivelPromedioInventario(0.1, 2.5, 5000, "ceil"), 1);
//    } 
    
    @Test
    public void Prueba4(){
        ModeloQ modeloq = new ModeloQ();
        modeloq.setD(60);
        double stockResult = modeloq.getSecurityStock(0.9, 7, "ceil");
        double rop = modeloq.getROP(0.9, 7, "ceil"); 
        
        System.out.println(""
                + "\nValor de stock: " + stockResult
                + "\nValor de ROP: " + rop);
        
        assertEquals(9, stockResult, 0.1);
        assertEquals(69, rop, 1);
    }
    
    @Test
    public void Prueba5(){
        ModeloQ modeloq = new ModeloQ();
        modeloq.setD(50);
        double stockResult = modeloq.getSecurityStock(0.97, 5, "no");
        double rop = modeloq.getROP(0.97, 5, "no"); 
        
        System.out.println(""
                + "\nValor de stock: " + stockResult
                + "\nValor de ROP: " + rop);
        
        assertEquals(9.4, stockResult, 0.1);
        assertEquals(59.4, rop, 1);
    }
}
